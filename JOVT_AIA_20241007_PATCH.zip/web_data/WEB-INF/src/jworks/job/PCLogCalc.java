package jworks.job;

import jworks.biz.Const;
import jworks.core.DBWorker;
import jworks.core.ResultObject;
import jworks.exception.DBWorkerException;
import jworks.exception.ResultObjectException;
import jworks.util.DateUtil;
import jworks.util.LogUtil;
import jworks.util.StringUtil;

/**
 * <pre>
 * PCLogCalc.java
 *
 * </pre>
 */
public class PCLogCalc extends DBWorker {
	public void job() throws DBWorkerException, ResultObjectException {
		String st = DateUtil.getDateAdd(DateUtil.getDate("yyyyMMdd"), "date", -3);
		String et = DateUtil.getDateAdd(DateUtil.getDate("yyyyMMdd"), "date", -1);

		job(st, et);
	}

	public void job(String st, String et) throws DBWorkerException, ResultObjectException {
		this.debugKey = "[JOB]\n";

		// #########################
		// 파라미터 설정
		// #########################
		/*
			daemon_st_tm: 시작시
			daemon_ed_tm: 종료시
			daemon_dm_nm: 데몬 클래스명
			daemon_status: 성공(1)/실패(0)
			daemon_dm_dspt: 상세 정보
		*/
		String daemon_st_tm = "";
		String daemon_ed_tm = "";
		String daemon_dm_nm = "PCLogCalc";
		String daemon_status = "1";
		String daemon_dm_dspt = "";

		/*
			calc_day: 계산일
			emp_no: 사원 코드
			dpt_cd: 부서 코드
			pos_cd: 직급 코드
			tit_cd: 직위 코드
			jik_cd: 직책 코드
			grp_seqno: 그룹 일련번호
			ot_type: 업무(0)/사전연장사용(1)/긴급연장사용(2)
			ot_type_1: 사전신청횟수
			ot_type_2: 긴급신청횟수
			holiday_yn: 휴일 여부 (0/1)
			exception_yn: 차단 예외자 여부 (0/1)
			force_blk: 강제 차단자 여부 (0/1)
			work_work_mm: 업무시간 총합 (분)
			work_idle_mm: 업무 중 IDLE 총합 (분)
			work_acpt_mm: IDLE 포함 업무 인정시간 (분)
			work_close_tm: 개인 종업시간
			over_work_mm: 연장사용 신청시간 총합 (분)
			over_acpt_mm: IDLE 포함 연장사용 인정시간 (분)
			over_idle_mm: 연장사용 중 IDLE 총합 (분)
			pc_on_dt: PC ON 시간
			pc_off_dt: PC OFF 시간
			log_on_dt: LOG ON 시간
			log_off_dt: LOG OFF 시간
		*/
		String calc_day = "";
		String emp_no = "";
		String dpt_cd = "";
		String pos_cd = "";
		String tit_cd = "";
		String jik_cd = "";
		String grp_seqno = "";
		String ot_type = "0";
		int ot_type_1 = 0;
		int ot_type_2 = 0;
		String holiday_yn = "0";
		String exception_yn = "0";
		String force_blk = "0";
		int work_work_mm = 0;
		int work_idle_mm = 0;
		int work_acpt_mm = 0;
		String work_close_tm = "";
		int over_work_mm = 0;
		int over_acpt_mm = 0;
		int over_idle_mm = 0;
		String pc_on_dt = "";
		String pc_off_dt = "";
		String log_on_dt = "";
		String log_off_dt = "";

		// #########################
		// 데이터 처리
		// #########################
		ResultObject row1 = null;
		ResultObject row2 = null;

		String log = "";
		StringBuffer sb = new StringBuffer();

		int cnt = DateUtil.getDateDiff(st, et);
		for (int add = 0; add <= cnt; add++) {
			log = "";
			sb = new StringBuffer();

			// ########## PC 사용기록 계산 ##########
			daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			calc_day = DateUtil.getDateAdd(st, "date", add);
			try {
				//openConn();
				//beginTran();

				// ########## 승인/반려/취소 이외 미승인 처리 ##########
				/* ANSI SQL */
				setVersion("2015.10.21.01");
				setComment("미승인 처리");
				setQuery("UPDATE jovt_ot_aprv SET");
				setQuery("	status = 7");
				setQuery("WHERE");
				setQuery("	status <> 7");
				setQuery("	AND ot_seqno IN (");
				setQuery("		SELECT");
				setQuery("			seqno");
				setQuery("		FROM");
				setQuery("			jovt_ot");
				setQuery("		WHERE");
				setQuery("			aprv_status NOT IN (2, 3, 6, 7)");
				setQuery("			AND work_ymd = ?)", calc_day);
				executeQuery();

				/* ANSI SQL */
				setVersion("2015.10.21.01");
				setComment("미승인 처리");
				setQuery("UPDATE jovt_ot SET");
				setQuery("	aprv_status = 7");
				setQuery("WHERE");
				setQuery("	aprv_status <> 7");
				setQuery("	AND seqno IN (");
				setQuery("		SELECT");
				setQuery("			ot_seqno");
				setQuery("		FROM");
				setQuery("			jovt_ot_aprv");
				setQuery("		WHERE");
				setQuery("			status = 7)");
				executeQuery();

				// ########## 휴일 여부 ##########
				/* ANSI SQL */
				setVersion("2015.05.28.01");
				setComment("휴일 여부");
				setQuery("SELECT");
				setQuery("	COUNT(*) AS cnt");
				setQuery("FROM");
				setQuery("	jovt_holiday");
				setQuery("WHERE");
				setQuery("	status = 1");
				setQuery("	AND hol_ymd = ?", calc_day);
				row1 = getRs();

				if (row1.getInt("cnt", 0) > 0)
					holiday_yn = "1";
				else
					holiday_yn = "0";

				// ########## 사원/부서/직급/직위/직책/그룹 코드 ##########
				/* ANSI SQL */
				setVersion("2016.01.21.01");
				setComment("사원/부서/직급/직위/직책/그룹 코드");
				setQuery("SELECT");
				setQuery("	A.emp_no, B.dpt_cd, B.pos_cd, B.tit_cd, B.jik_cd, C.grp_seqno");
				setQuery("FROM");
				setQuery("	(SELECT");
				setQuery("		DISTINCT emp_no, plg_ymd");
				setQuery("	FROM");
				setQuery("		jovt_pclog");
				setQuery("	WHERE");
				setQuery("		plg_st_dt < plg_ed_dt");
				setQuery("		AND plg_ymd = ?) A", calc_day);
				setQuery("	LEFT OUTER JOIN jovt_member_history B ON A.emp_no = B.emp_no");
				setQuery("		AND A.plg_ymd = B.his_ymd");
				setQuery("	LEFT OUTER JOIN jovt_group_list C ON A.emp_no = C.emp_no");
				setQuery("		AND C.status = 1");
				setQuery("		AND A.plg_ymd >= TO_CHAR(C.reg_dt, 'YYYYMMDD')");
				setQuery("		AND A.plg_ymd < TO_CHAR(C.cancel_dt, 'YYYYMMDD')");
				setQuery("WHERE");
				setQuery("	B.dpt_cd IS NOT NULL");
				setQuery("ORDER BY");
				setQuery("	A.emp_no ASC");
				row1 = getRs();

				for (int i = 0; i < row1.getRsCount(); i++) {
					emp_no = row1.getData("emp_no", i);
					dpt_cd = row1.getData("dpt_cd", i);
					pos_cd = row1.getData("pos_cd", i);
					tit_cd = row1.getData("tit_cd", i);
					jik_cd = row1.getData("jik_cd", i);
					grp_seqno = row1.getData("grp_seqno", i);

					ot_type = "0";
					ot_type_1 = 0;
					ot_type_2 = 0;
					work_work_mm = 0;
					work_idle_mm = 0;
					work_acpt_mm = 0;
					work_close_tm = "";
					over_work_mm = 0;
					over_acpt_mm = 0;
					over_idle_mm = 0;

					// ########## 차단 예외자 여부 ##########
					exception_yn = "0";

					if (StringUtil.isEquals(exception_yn, "0")) {
						/* ANSI SQL */
						setVersion("2015.11.18.01");
						setComment("차단 예외자 여부 (개인/고정)");
						setQuery("SELECT");
						setQuery("	COUNT(*) AS cnt");
						setQuery("FROM");
						setQuery("	vw_exception_new");
						setQuery("WHERE");
						setQuery("	status = 1");
						if (StringUtil.isEquals(holiday_yn, "1"))
							setQuery("	AND apply_holiday = 1");
						else
							setQuery("	AND apply_workday = 1");
						setQuery("	AND (db_type = 0 OR db_type = 1)");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND ? BETWEEN exp_st_ymd AND exp_ed_ymd", calc_day);
						row2 = getRs();

						if (row2.getInt("cnt", 0) > 0)
							exception_yn = "1";
					}

					if (StringUtil.isEquals(exception_yn, "0") && !StringUtil.isEmpty(grp_seqno)) {
						/* ANSI SQL */
						setVersion("2015.05.28.01");
						setComment("차단 예외자 여부 (그룹)");
						setQuery("SELECT");
						setQuery("	COUNT(*) AS cnt");
						setQuery("FROM");
						setQuery("	jovt_exception_grp A");
						setQuery("	INNER JOIN jovt_group_list B ON A.grp_seqno = B.grp_seqno");
						setQuery("WHERE");
						setQuery("	A.status = 1 AND B.status = 1");
						if (StringUtil.isEquals(holiday_yn, "1"))
							setQuery("	AND A.apply_holiday = 1");
						else
							setQuery("	AND A.apply_workday = 1");
						setQuery("	AND B.emp_no = ?", emp_no);
						setQuery("	AND ? BETWEEN A.exp_st_ymd AND A.exp_ed_ymd", calc_day);
						row2 = getRs();

						if (row2.getInt("cnt", 0) > 0)
							exception_yn = "1";
					}

					if (StringUtil.isEquals(exception_yn, "0") && !StringUtil.isEmpty(dpt_cd)) {
						/* ANSI SQL */
						setVersion("2015.05.28.01");
						setComment("차단 예외자 여부 (부서)");
						setQuery("SELECT");
						setQuery("	COUNT(*) AS cnt");
						setQuery("FROM");
						setQuery("	jovt_exception_dpt");
						setQuery("WHERE");
						setQuery("	status = 1");
						if (StringUtil.isEquals(holiday_yn, "1"))
							setQuery("	AND apply_holiday = 1");
						else
							setQuery("	AND apply_workday = 1");
						setQuery("	AND dpt_cd = ?", dpt_cd);
						setQuery("	AND ? BETWEEN exp_st_ymd AND exp_ed_ymd", calc_day);
						row2 = getRs();

						if (row2.getInt("cnt", 0) > 0)
							exception_yn = "1";
					}

					// ########## 강제 차단자 여부 ##########
					force_blk = "0";

					if (StringUtil.isEquals(force_blk, "0")) {
						/* ANSI SQL */
						setVersion("2017.03.15.01");
						setComment("강제 차단자 여부 (개인)");
						setQuery("SELECT");
						setQuery("	COUNT(*) AS cnt");
						setQuery("FROM");
						setQuery("	jovt_black_list");
						setQuery("WHERE");
						setQuery("	status = 1");
						if (StringUtil.isEquals(holiday_yn, "1"))
							setQuery("	AND apply_holiday = 1");
						else
							setQuery("	AND apply_workday = 1");
						setQuery("	AND force_blk = 1");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND ? BETWEEN exp_st_ymd AND exp_ed_ymd", calc_day);
						row2 = getRs();

						if (row2.getInt("cnt", 0) > 0)
							force_blk = "1";
					}

					if (StringUtil.isEquals(force_blk, "0") && !StringUtil.isEmpty(grp_seqno)) {
						/* ANSI SQL */
						setVersion("2017.03.15.01");
						setComment("강제 차단자 여부 (그룹)");
						setQuery("SELECT");
						setQuery("	COUNT(*) AS cnt");
						setQuery("FROM");
						setQuery("	jovt_black_list_grp A");
						setQuery("	INNER JOIN jovt_group_list B ON A.grp_seqno = B.grp_seqno");
						setQuery("WHERE");
						setQuery("	A.status = 1 AND B.status = 1");
						if (StringUtil.isEquals(holiday_yn, "1"))
							setQuery("	AND A.apply_holiday = 1");
						else
							setQuery("	AND A.apply_workday = 1");
						setQuery("	AND A.force_blk = 1");
						setQuery("	AND B.emp_no = ?", emp_no);
						setQuery("	AND ? BETWEEN A.exp_st_ymd AND A.exp_ed_ymd", calc_day);
						row2 = getRs();

						if (row2.getInt("cnt", 0) > 0)
							force_blk = "1";
					}

					if (StringUtil.isEquals(force_blk, "0") && !StringUtil.isEmpty(dpt_cd)) {
						/* ANSI SQL */
						setVersion("2017.03.15.01");
						setComment("강제 차단자 여부 (부서)");
						setQuery("SELECT");
						setQuery("	COUNT(*) AS cnt");
						setQuery("FROM");
						setQuery("	jovt_black_list_dpt");
						setQuery("WHERE");
						setQuery("	status = 1");
						if (StringUtil.isEquals(holiday_yn, "1"))
							setQuery("	AND apply_holiday = 1");
						else
							setQuery("	AND apply_workday = 1");
						setQuery("	AND force_blk = 1");
						setQuery("	AND dpt_cd = ?", dpt_cd);
						setQuery("	AND ? BETWEEN exp_st_ymd AND exp_ed_ymd", calc_day);
						row2 = getRs();

						if (row2.getInt("cnt", 0) > 0)
							force_blk = "1";
					}

					// ########## 차단시각 ##########
					String work_no = "";
					int work_st = 0;
					int work_et = 0;
					String work_blk = "";

					if (StringUtil.isEquals(holiday_yn, "1")) {
						/* ANSI SQL */
						setVersion("2015.10.20.01");
						setComment("휴일 업무시간");
						setQuery("SELECT");
						setQuery("	hol_blk");
						setQuery("	, hol_block_tm");
						setQuery("	, am_blockout_tm");
						setQuery("	, ((CAST(SUBSTR(dayaxis_tm, 1, 2) AS INT) * 60) + CAST(SUBSTR(dayaxis_tm, 3, 2) AS INT)) AS work_st");
						setQuery("	, ((CAST(SUBSTR(dayaxis_tm, 1, 2) AS INT) * 60) + CAST(SUBSTR(dayaxis_tm, 3, 2) AS INT)) AS work_et");
						setQuery("FROM");
						setQuery("	jovt_system");
						row2 = getRs();

						if (row2.getRsCount() > 0) {
							work_st = row2.getInt("work_st", 0);
							work_et = row2.getInt("work_et", 0);
							work_close_tm = row2.getData("hol_block_tm", 0);

							if (StringUtil.isEquals(force_blk, "0")) {
								if (StringUtil.isEquals(row2.getInt("hol_blk", 0), "0")) {
									work_close_tm = "";
								}
							} else {
								if (StringUtil.isEquals(row2.getInt("hol_blk", 0), "0")) {
									work_close_tm = row2.getData("am_blockout_tm", 0);
								}
							}
						}
					} else {
						// ########## 근무표 차단시각 ##########
						/* ANSI SQL */
						setVersion("2015.10.20.01");
						setComment("유연근무자");
						setQuery("SELECT");
						setQuery("	blk_hm AS work_close_tm");
						setQuery("	, ((CAST(SUBSTR(st_hm, 1, 2) AS INT) * 60) + CAST(SUBSTR(st_hm, 3, 2) AS INT)) AS work_st");
						setQuery("	, ((CAST(SUBSTR(ed_hm, 1, 2) AS INT) * 60) + CAST(SUBSTR(ed_hm, 3, 2) AS INT)) AS work_et");
						setQuery("FROM");
						setQuery("	jovt_workset_emp_flexible");
						setQuery("WHERE");
						setQuery("	status = 1");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND ? BETWEEN st_ymd AND ed_ymd", calc_day);
						setQuery("ORDER BY");
						setQuery("	seqno DESC");
						row2 = getRs();

						if (row2.getRsCount() > 0) {
							work_st = row2.getInt("work_st", 0);
							work_et = row2.getInt("work_et", 0);
							work_blk = row2.getData("work_close_tm", 0);
							work_close_tm = row2.getData("work_close_tm", 0);
						} else {
							if (StringUtil.isEmpty(work_no)) {
								/* ANSI SQL */
								setVersion("2015.05.28.01");
								setComment("유연근무표 (개인)");
								setQuery("SELECT");
								setQuery("	work_no");
								setQuery("FROM");
								setQuery("	jovt_workset_emp_daily");
								setQuery("WHERE");
								setQuery("	status = 1");
								setQuery("	AND emp_no = ?", emp_no);
								setQuery("	AND ? BETWEEN st_ymd AND ed_ymd", calc_day);
								row2 = getRs();

								if (row2.getRsCount() > 0) {
									work_no = row2.getData("work_no", 0);
								}
							}

							if (StringUtil.isEmpty(work_no) && !StringUtil.isEmpty(grp_seqno)) {
								/* ANSI SQL */
								setVersion("2015.05.28.01");
								setComment("유연근무표 (그룹)");
								setQuery("SELECT");
								setQuery("	work_no");
								setQuery("FROM");
								setQuery("	jovt_workset_grp_daily");
								setQuery("WHERE");
								setQuery("	status = 1");
								setQueryInt("	AND grp_seqno = ?", grp_seqno);
								setQuery("	AND ? BETWEEN st_ymd AND ed_ymd", calc_day);
								row2 = getRs();

								if (row2.getRsCount() > 0) {
									work_no = row2.getData("work_no", 0);
								}
							}

							if (StringUtil.isEmpty(work_no) && !StringUtil.isEmpty(dpt_cd)) {
								/* ANSI SQL */
								setVersion("2015.05.28.01");
								setComment("유연근무표 (부서)");
								setQuery("SELECT");
								setQuery("	work_no");
								setQuery("FROM");
								setQuery("	jovt_workset_dpt_daily");
								setQuery("WHERE");
								setQuery("	status = 1");
								setQuery("	AND dpt_cd = ?", dpt_cd);
								setQuery("	AND ? BETWEEN st_ymd AND ed_ymd", calc_day);
								row2 = getRs();

								if (row2.getRsCount() > 0) {
									work_no = row2.getData("work_no", 0);
								}
							}

							if (StringUtil.isEmpty(work_no)) {
								/* ANSI SQL */
								setVersion("2015.05.28.01");
								setComment("적용근무표");
								setQuery("SELECT");
								setQuery("	work_no");
								setQuery("FROM");
								setQuery("	vw_workset");
								setQuery("WHERE");
								setQuery("	status = 1");
								setQuery("	AND emp_no = ?", emp_no);
								row2 = getRs();

								if (row2.getRsCount() > 0) {
									work_no = row2.getData("work_no", 0);
								}
							}

							if (StringUtil.isEmpty(work_no))
								work_no = Integer.toString(Const.DEFAULT_BASIC_WORK_NO);

							if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
								/* POSTGRESQL */
								setVersion("2015.10.19.01");
								setComment("근무표");
								setQuery("SELECT");
								setQuery("	work_close_tm");
								setQuery("	, ((CAST(SUBSTR(work_st, 1, 2) AS INT) * 60) + CAST(SUBSTR(work_st, 3, 2) AS INT)) AS work_st");
								setQuery("	, ((CAST(SUBSTR(work_et, 1, 2) AS INT) * 60) + CAST(SUBSTR(work_et, 3, 2) AS INT)) AS work_et");
								setQuery("FROM");
								setQuery("	(SELECT");
								setQuery("		CASE DATE_PART('dow', CAST(? AS DATE))", calc_day);
								setQuery("			WHEN 0 THEN sun_st");
								setQuery("			WHEN 1 THEN mon_st");
								setQuery("			WHEN 2 THEN tue_st");
								setQuery("			WHEN 3 THEN wed_st");
								setQuery("			WHEN 4 THEN thu_st");
								setQuery("			WHEN 5 THEN fri_st");
								setQuery("			WHEN 6 THEN sat_st");
								setQuery("		END AS work_st");
								setQuery("		, CASE DATE_PART('dow', CAST(? AS DATE))", calc_day);
								setQuery("			WHEN 0 THEN sun_et");
								setQuery("			WHEN 1 THEN mon_et");
								setQuery("			WHEN 2 THEN tue_et");
								setQuery("			WHEN 3 THEN wed_et");
								setQuery("			WHEN 4 THEN thu_et");
								setQuery("			WHEN 5 THEN fri_et");
								setQuery("			WHEN 6 THEN sat_et");
								setQuery("		END AS work_et");
								setQuery("		, CASE DATE_PART('dow', CAST(? AS DATE))", calc_day);
								setQuery("			WHEN 0 THEN sun_blk_tm");
								setQuery("			WHEN 1 THEN mon_blk_tm");
								setQuery("			WHEN 2 THEN tue_blk_tm");
								setQuery("			WHEN 3 THEN wed_blk_tm");
								setQuery("			WHEN 4 THEN thu_blk_tm");
								setQuery("			WHEN 5 THEN fri_blk_tm");
								setQuery("			WHEN 6 THEN sat_blk_tm");
								setQuery("		END AS work_close_tm");
								setQuery("	FROM");
								setQuery("		jovt_workset");
								setQuery("	WHERE");
								setQueryInt("		work_no = ?", work_no);
								setQuery("	) T");
								row2 = getRs();
							} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
								/* ORACLE */
								setVersion("2015.10.19.01");
								setComment("근무표");
								setQuery("SELECT");
								setQuery("	work_close_tm");
								setQuery("	, ((CAST(SUBSTR(work_st, 1, 2) AS INT) * 60) + CAST(SUBSTR(work_st, 3, 2) AS INT)) AS work_st");
								setQuery("	, ((CAST(SUBSTR(work_et, 1, 2) AS INT) * 60) + CAST(SUBSTR(work_et, 3, 2) AS INT)) AS work_et");
								setQuery("FROM");
								setQuery("	(SELECT");
								setQuery("		CASE TO_CHAR(TO_DATE(?, 'YYYY-MM-DD'), 'd')", calc_day);
								setQuery("			WHEN '1' THEN sun_st");
								setQuery("			WHEN '2' THEN mon_st");
								setQuery("			WHEN '3' THEN tue_st");
								setQuery("			WHEN '4' THEN wed_st");
								setQuery("			WHEN '5' THEN thu_st");
								setQuery("			WHEN '6' THEN fri_st");
								setQuery("			WHEN '7' THEN sat_st");
								setQuery("		END AS work_st");
								setQuery("		, CASE TO_CHAR(TO_DATE(?, 'YYYY-MM-DD'), 'd')", calc_day);
								setQuery("			WHEN '1' THEN sun_et");
								setQuery("			WHEN '2' THEN mon_et");
								setQuery("			WHEN '3' THEN tue_et");
								setQuery("			WHEN '4' THEN wed_et");
								setQuery("			WHEN '5' THEN thu_et");
								setQuery("			WHEN '6' THEN fri_et");
								setQuery("			WHEN '7' THEN sat_et");
								setQuery("		END AS work_et");
								setQuery("		, CASE TO_CHAR(TO_DATE(?, 'YYYY-MM-DD'), 'd')", calc_day);
								setQuery("			WHEN '1' THEN sun_blk_tm");
								setQuery("			WHEN '2' THEN mon_blk_tm");
								setQuery("			WHEN '3' THEN tue_blk_tm");
								setQuery("			WHEN '4' THEN wed_blk_tm");
								setQuery("			WHEN '5' THEN thu_blk_tm");
								setQuery("			WHEN '6' THEN fri_blk_tm");
								setQuery("			WHEN '7' THEN sat_blk_tm");
								setQuery("		END AS work_close_tm");
								setQuery("	FROM");
								setQuery("		jovt_workset");
								setQuery("	WHERE");
								setQueryInt("		work_no = ?", work_no);
								setQuery("	) T");
								row2 = getRs();
							}

							if (row2.getRsCount() > 0) {
								work_st = row2.getInt("work_st", 0);
								work_et = row2.getInt("work_et", 0);
								work_blk = row2.getData("work_close_tm", 0);
								work_close_tm = row2.getData("work_close_tm", 0);
							}
						}

						// ########## 차단 요일 차단시각 ##########
						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2015.12.02.01");
							setComment("차단 요일 차단시각");
							setQuery("SELECT");
							setQuery("	work_close_tm");
							setQuery("FROM");
							setQuery("	(SELECT");
							setQuery("		CASE DATE_PART('dow', CAST(? AS DATE))", calc_day);
							setQuery("			WHEN 0 THEN sun");
							setQuery("			WHEN 1 THEN mon");
							setQuery("			WHEN 2 THEN tue");
							setQuery("			WHEN 3 THEN wed");
							setQuery("			WHEN 4 THEN thu");
							setQuery("			WHEN 5 THEN fri");
							setQuery("			WHEN 6 THEN sat");
							setQuery("		END AS status");
							setQuery("		, block_tm AS work_close_tm");
							setQuery("	FROM");
							setQuery("		jovt_familyday");
							setQuery("	WHERE");
							setQuery("		block_type = 1) T");
							setQuery("WHERE");
							setQuery("	status = 1");
							row2 = getRs();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2015.12.02.01");
							setComment("차단 요일 차단시각");
							setQuery("SELECT");
							setQuery("	work_close_tm");
							setQuery("FROM");
							setQuery("	(SELECT");
							setQuery("		CASE TO_CHAR(TO_DATE(?, 'YYYY-MM-DD'), 'd')", calc_day);
							setQuery("			WHEN '1' THEN sun");
							setQuery("			WHEN '2' THEN mon");
							setQuery("			WHEN '3' THEN tue");
							setQuery("			WHEN '4' THEN wed");
							setQuery("			WHEN '5' THEN thu");
							setQuery("			WHEN '6' THEN fri");
							setQuery("			WHEN '7' THEN sat");
							setQuery("		END AS status");
							setQuery("		, block_tm AS work_close_tm");
							setQuery("	FROM");
							setQuery("		jovt_familyday");
							setQuery("	WHERE");
							setQuery("		block_type = 1) T");
							setQuery("WHERE");
							setQuery("	status = 1");
							row2 = getRs();
						}

						if (row2.getRsCount() > 0) {
							work_close_tm = row2.getData("work_close_tm", 0);
						}

						// ########## 특정일 차단시각 ##########
						/* ANSI SQL */
						setVersion("2015.10.20.01");
						setComment("특정일 차단시각");
						setQuery("SELECT");
						setQuery("	TRIM(sdy_hm) AS work_close_tm");
						setQuery("FROM");
						setQuery("	jovt_selectday");
						setQuery("WHERE");
						setQuery("	status = 1");
						setQuery("	AND sdy_ymd = ?", calc_day);
						row2 = getRs();

						if (row2.getRsCount() > 0) {
							work_close_tm = row2.getData("work_close_tm", 0);
						}

						// ########## 스마트 워킹데이 차단시각 ##########
						/* ANSI SQL */
						setVersion("2017.01.24.01");
						setComment("스마트 워킹데이 차단시각");
						setQuery("SELECT");
						setQuery("	(swdy_plus_minus");
						setQuery("	|| (CAST(SUBSTR(swdy_hm, 1, 2) AS INT) * 60) + CAST(SUBSTR(swdy_hm, 3, 2) AS INT)) AS swdy_hm");
						setQuery("FROM");
						setQuery("	jovt_smartworkday");
						setQuery("WHERE");
						setQuery("	status = 1");
						setQuery("	AND swdy_ymd = ?", calc_day);
						row2 = getRs();

						if (row2.getRsCount() > 0) {
							int work_close_tmp = ((Integer.parseInt(work_blk.substring(0, 2)) * 60) + Integer.parseInt(work_blk.substring(2, 4))) + Integer.parseInt(row2.getData("swdy_hm", 0));
							if (work_close_tmp < 0)
								work_close_tm = "0000";
							else if (work_close_tmp > 1440)
								work_close_tm = "2400";
							else
								work_close_tm = StringUtil.replicate(Integer.toString((work_close_tmp / 60)), "0", 2) + StringUtil.replicate(Integer.toString((work_close_tmp % 60)), "0", 2);
						}

						if (work_st < work_et) {
							work_work_mm += work_et - work_st;
						} else {
							work_work_mm += 1440 - work_st;
							work_work_mm += work_et;
						}
					}

					// ########## 업무시간/PC 로그/IDLE 로그 ##########
					int[] arr_wa = new int[1440];
					for (int t = 0; t < 1440; t++) {
						arr_wa[t] = 0;
					}

					int[] arr_wi = new int[1440];
					for (int t = 0; t < 1440; t++) {
						arr_wi[t] = 0;
					}

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2016.01.21.01");
						setComment("업무시간 PC 로그 시작/끝");
						setQuery("SELECT");
						setQuery("	((DATE_PART('hour', plg_st_dt) * 60) + DATE_PART('minute', plg_st_dt)) AS plg_st_dt");
						setQuery("	, ((DATE_PART('hour', plg_ed_dt) * 60) + DATE_PART('minute', plg_ed_dt)) AS plg_ed_dt");
						setQuery("FROM");
						setQuery("	jovt_pclog");
						setQuery("WHERE");
						setQuery("	plg_st_dt < plg_ed_dt");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND plg_ymd = ?", calc_day);
						setQuery("	AND (plg_mode % 100) IN (0, 3, 4, 9, 50)");
						row2 = getRs();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2016.01.21.01");
						setComment("업무시간 PC 로그 시작/끝");
						setQuery("SELECT");
						setQuery("	((CAST(TO_CHAR(plg_st_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(plg_st_dt, 'MI') AS INT)) AS plg_st_dt");
						setQuery("	, ((CAST(TO_CHAR(plg_ed_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(plg_ed_dt, 'MI') AS INT)) AS plg_ed_dt");
						setQuery("FROM");
						setQuery("	jovt_pclog");
						setQuery("WHERE");
						setQuery("	plg_st_dt < plg_ed_dt");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND plg_ymd = ?", calc_day);
						setQuery("	AND MOD(plg_mode, 100) IN (0, 3, 4, 9, 50)");
						row2 = getRs();
					}

					for (int c = 0; c < row2.getRsCount(); c++) {
						int plg_st_dt = row2.getInt("plg_st_dt", c);
						int plg_ed_dt = row2.getInt("plg_ed_dt", c);

						if (plg_ed_dt < plg_st_dt) {
							for (int t = (plg_st_dt + 1); t < 1440; t++) {
								arr_wa[t]++;
							}
							for (int t = 0; t <= plg_ed_dt; t++) {
								arr_wa[t]++;
							}
						} else {
							for (int t = (plg_st_dt + 1); t <= plg_ed_dt; t++) {
								arr_wa[t]++;
							}
						}
					}

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2016.01.21.01");
						setComment("업무시간 IDLE 로그 시작/끝");
						setQuery("SELECT");
						setQuery("	((DATE_PART('hour', idl_st_dt) * 60) + DATE_PART('minute', idl_st_dt)) AS idl_st_dt");
						setQuery("	, ((DATE_PART('hour', idl_ed_dt) * 60) + DATE_PART('minute', idl_ed_dt)) AS idl_ed_dt");
						setQuery("FROM");
						setQuery("	jovt_idlelog");
						setQuery("WHERE");
						setQuery("	idl_st_dt < idl_ed_dt");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND idl_ymd = ?", calc_day);
						setQuery("	AND (idl_mode % 100) IN (0, 3, 4, 9, 50)");
						row2 = getRs();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2016.01.21.01");
						setComment("업무시간 IDLE 로그 시작/끝");
						setQuery("SELECT");
						setQuery("	((CAST(TO_CHAR(idl_st_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(idl_st_dt, 'MI') AS INT)) AS idl_st_dt");
						setQuery("	, ((CAST(TO_CHAR(idl_ed_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(idl_ed_dt, 'MI') AS INT)) AS idl_ed_dt");
						setQuery("FROM");
						setQuery("	jovt_idlelog");
						setQuery("WHERE");
						setQuery("	idl_st_dt < idl_ed_dt");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND idl_ymd = ?", calc_day);
						setQuery("	AND MOD(idl_mode, 100) IN (0, 3, 4, 9, 50)");
						row2 = getRs();
					}

					for (int c = 0; c < row2.getRsCount(); c++) {
						int idl_st_dt = row2.getInt("idl_st_dt", c);
						int idl_ed_dt = row2.getInt("idl_ed_dt", c);

						if (idl_ed_dt < idl_st_dt) {
							for (int t = (idl_st_dt + 1); t < 1440; t++) {
								arr_wi[t]++;
							}
							for (int t = 0; t <= idl_ed_dt; t++) {
								arr_wi[t]++;
							}
						} else {
							for (int t = (idl_st_dt + 1); t <= idl_ed_dt; t++) {
								arr_wi[t]++;
							}
						}
					}

					for (int t = 0; t < 1440; t++) {
						if (arr_wa[t] >= 1)
							work_acpt_mm++;

						if ((0 < arr_wi[t]) && (arr_wa[t] <= arr_wi[t]))
							work_idle_mm++;
					}

					// ########## 연장사용 신청시간/PC 로그/IDLE 로그 ##########
					int[] arr_oa = new int[1440];
					for (int t = 0; t < 1440; t++) {
						arr_oa[t] = 0;
					}

					int[] arr_oi = new int[1440];
					for (int t = 0; t < 1440; t++) {
						arr_oi[t] = 0;
					}

					/* ANSI SQL */
					setVersion("2015.05.28.01");
					setComment("연장사용 신청시간 시작/끝");
					setQuery("SELECT");
					setQuery("	ot_type");
					setQuery("	, TRIM(work_close_tm) AS work_close_tm");
					setQuery("	, ((CAST(SUBSTR(sta_hm, 1, 2) AS INT) * 60) + CAST(SUBSTR(sta_hm, 3, 2) AS INT)) AS sta_hm");
					setQuery("	, ((CAST(SUBSTR(end_hm, 1, 2) AS INT) * 60) + CAST(SUBSTR(end_hm, 3, 2) AS INT)) AS end_hm");
					setQuery("FROM");
					setQuery("	jovt_ot");
					setQuery("WHERE");
					setQuery("	emp_no = ?", emp_no);
					setQuery("	AND work_ymd = ?", calc_day);
					setQuery("	AND aprv_status = 2");
					setQuery("ORDER BY");
					setQuery("	sta_ymd ASC, sta_hm ASC");
					row2 = getRs();

					if (row2.getRsCount() > 0) {
						for (int c = 0; c < row2.getRsCount(); c++) {
							if (StringUtil.isEquals(ot_type, "0"))
								ot_type = row2.getData("ot_type", c);
							if (StringUtil.isEquals(row2.getData("ot_type", c), "1"))
								ot_type_1++;
							if (StringUtil.isEquals(row2.getData("ot_type", c), "2"))
								ot_type_2++;
							if (StringUtil.isEmpty(work_close_tm))
								work_close_tm = row2.getData("work_close_tm", c);
							int sta_hm = row2.getInt("sta_hm", c);
							int end_hm = row2.getInt("end_hm", c);

							if (sta_hm < end_hm) {
								over_work_mm += end_hm - sta_hm;

								for (int t = (sta_hm + 1); t <= end_hm; t++) {
									arr_oa[t] = 10000;
									arr_oi[t] = 10000;
								}
							} else {
								over_work_mm += 1440 - sta_hm;
								over_work_mm += end_hm;

								for (int t = (sta_hm + 1); t < 1440; t++) {
									arr_oa[t] = 10000;
									arr_oi[t] = 10000;
								}
								for (int t = 0; t <= end_hm; t++) {
									arr_oa[t] = 10000;
									arr_oi[t] = 10000;
								}
							}
						}

						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2016.01.21.01");
							setComment("연장사용 PC 로그 시작/끝");
							setQuery("SELECT");
							setQuery("	((DATE_PART('hour', plg_st_dt) * 60) + DATE_PART('minute', plg_st_dt)) AS plg_st_dt");
							setQuery("	, ((DATE_PART('hour', plg_ed_dt) * 60) + DATE_PART('minute', plg_ed_dt)) AS plg_ed_dt");
							setQuery("FROM");
							setQuery("	jovt_pclog");
							setQuery("WHERE");
							setQuery("	plg_st_dt < plg_ed_dt");
							setQuery("	AND emp_no = ?", emp_no);
							setQuery("	AND plg_ymd = ?", calc_day);
							setQuery("	AND (plg_mode % 100) IN (1, 2, 41, 42, 50)");
							row2 = getRs();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2016.01.21.01");
							setComment("연장사용 PC 로그 시작/끝");
							setQuery("SELECT");
							setQuery("	((CAST(TO_CHAR(plg_st_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(plg_st_dt, 'MI') AS INT)) AS plg_st_dt");
							setQuery("	, ((CAST(TO_CHAR(plg_ed_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(plg_ed_dt, 'MI') AS INT)) AS plg_ed_dt");
							setQuery("FROM");
							setQuery("	jovt_pclog");
							setQuery("WHERE");
							setQuery("	plg_st_dt < plg_ed_dt");
							setQuery("	AND emp_no = ?", emp_no);
							setQuery("	AND plg_ymd = ?", calc_day);
							setQuery("	AND MOD(plg_mode, 100) IN (1, 2, 41, 42, 50)");
							row2 = getRs();
						}

						for (int c = 0; c < row2.getRsCount(); c++) {
							int plg_st_dt = row2.getInt("plg_st_dt", c);
							int plg_ed_dt = row2.getInt("plg_ed_dt", c);

							if (plg_ed_dt < plg_st_dt) {
								for (int t = (plg_st_dt + 1); t < 1440; t++) {
									arr_oa[t]++;
								}
								for (int t = 0; t <= plg_ed_dt; t++) {
									arr_oa[t]++;
								}
							} else {
								for (int t = (plg_st_dt + 1); t <= plg_ed_dt; t++) {
									arr_oa[t]++;
								}
							}
						}

						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2016.01.21.01");
							setComment("연장사용 IDLE 로그 시작/끝");
							setQuery("SELECT");
							setQuery("	((DATE_PART('hour', idl_st_dt) * 60) + DATE_PART('minute', idl_st_dt)) AS idl_st_dt");
							setQuery("	, ((DATE_PART('hour', idl_ed_dt) * 60) + DATE_PART('minute', idl_ed_dt)) AS idl_ed_dt");
							setQuery("FROM");
							setQuery("	jovt_idlelog");
							setQuery("WHERE");
							setQuery("	idl_st_dt < idl_ed_dt");
							setQuery("	AND emp_no = ?", emp_no);
							setQuery("	AND idl_ymd = ?", calc_day);
							setQuery("	AND (idl_mode % 100) IN (1, 2, 41, 42, 50)");
							row2 = getRs();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2016.01.21.01");
							setComment("연장사용 IDLE 로그 시작/끝");
							setQuery("SELECT");
							setQuery("	((CAST(TO_CHAR(idl_st_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(idl_st_dt, 'MI') AS INT)) AS idl_st_dt");
							setQuery("	, ((CAST(TO_CHAR(idl_ed_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(idl_ed_dt, 'MI') AS INT)) AS idl_ed_dt");
							setQuery("FROM");
							setQuery("	jovt_idlelog");
							setQuery("WHERE");
							setQuery("	idl_st_dt < idl_ed_dt");
							setQuery("	AND emp_no = ?", emp_no);
							setQuery("	AND idl_ymd = ?", calc_day);
							setQuery("	AND MOD(idl_mode, 100) IN (1, 2, 41, 42, 50)");
							row2 = getRs();
						}

						for (int c = 0; c < row2.getRsCount(); c++) {
							int idl_st_dt = row2.getInt("idl_st_dt", c);
							int idl_ed_dt = row2.getInt("idl_ed_dt", c);

							if (idl_ed_dt < idl_st_dt) {
								for (int t = (idl_st_dt + 1); t < 1440; t++) {
									arr_oi[t]++;
								}
								for (int t = 0; t <= idl_ed_dt; t++) {
									arr_oi[t]++;
								}
							} else {
								for (int t = (idl_st_dt + 1); t <= idl_ed_dt; t++) {
									arr_oi[t]++;
								}
							}
						}

						for (int t = 0; t < 1440; t++) {
							if (arr_oa[t] >= 10001) {
								over_acpt_mm++;

								if ((10000 < arr_oi[t]) && (arr_oa[t] <= arr_oi[t]))
									over_idle_mm++;
							}
						}
					}

					// ########## PC ON/OFF 시간 ##########
					/* ANSI SQL */
					setVersion("2016.01.21.01");
					setComment("PC ON/OFF 시간");
					setQuery("SELECT");
					setQuery("	TO_CHAR(MIN(plg_st_dt), 'YYYY-MM-DD HH24:MI:SS') AS pc_on_dt, TO_CHAR(MAX(plg_ed_dt), 'YYYY-MM-DD HH24:MI:SS') AS pc_off_dt");
					setQuery("	, CAST(TO_CHAR(MIN(plg_st_dt), 'YYYYMMDDHH24MISS') AS FLOAT) AS plg_st_dt");
					setQuery("	, CAST(TO_CHAR(MAX(plg_ed_dt), 'YYYYMMDDHH24MISS') AS FLOAT) AS plg_ed_dt");
					setQuery("FROM");
					setQuery("	jovt_pclog");
					setQuery("WHERE");
					setQuery("	plg_st_dt < plg_ed_dt");
					setQuery("	AND emp_no = ?", emp_no);
					setQuery("	AND plg_ymd = ?", calc_day);
					row2 = getRs();

					pc_on_dt = "";
					pc_off_dt = "";
					long plg_st_dt = 0;
					long plg_ed_dt = 0;

					if (row2.getRsCount() > 0) {
						pc_on_dt = row2.getData("pc_on_dt", 0);
						pc_off_dt = row2.getData("pc_off_dt", 0);
						plg_st_dt = row2.getLong("plg_st_dt", 0);
						plg_ed_dt = row2.getLong("plg_ed_dt", 0);
					}

					// ########## LOG ON/OFF 시간 ##########
					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2016.01.21.01");
						setComment("LOG ON 시간");
						setQuery("SELECT");
						setQuery("	TO_CHAR(idl_ed_dt, 'YYYY-MM-DD HH24:MI:SS') AS log_on_dt");
						setQuery("	, CAST(TO_CHAR(idl_st_dt, 'YYYYMMDDHH24MISS') AS FLOAT) AS idl_st_dt");
						setQuery("FROM");
						setQuery("	jovt_idlelog");
						setQuery("WHERE");
						setQuery("	idl_st_dt < idl_ed_dt");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND idl_ymd = ?", calc_day);
						setQuery("	AND idl_ed_dt >= TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US')", pc_on_dt);
						setQuery("ORDER BY");
						setQuery("	idl_st_dt ASC, idl_ed_dt ASC");
						row2 = getRs();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2016.01.21.01");
						setComment("LOG ON 시간");
						setQuery("SELECT");
						setQuery("	TO_CHAR(idl_ed_dt, 'YYYY-MM-DD HH24:MI:SS') AS log_on_dt");
						setQuery("	, CAST(TO_CHAR(idl_st_dt, 'YYYYMMDDHH24MISS') AS FLOAT) AS idl_st_dt");
						setQuery("FROM");
						setQuery("	jovt_idlelog");
						setQuery("WHERE");
						setQuery("	idl_st_dt < idl_ed_dt");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND idl_ymd = ?", calc_day);
						setQuery("	AND idl_ed_dt >= TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS')", pc_on_dt);
						setQuery("ORDER BY");
						setQuery("	idl_st_dt ASC, idl_ed_dt ASC");
						row2 = getRs();
					}

					log_on_dt = pc_on_dt;
					long idl_st_dt = 0;

					for (int c = 0; c < row2.getRsCount(); c++) {
						idl_st_dt = row2.getLong("idl_st_dt", c);

						// (PC ON시각 < IDLE 시작시각) && ((IDLE 시작시각 - PC ON시각) > 1)
						if ((plg_st_dt < idl_st_dt) && ((idl_st_dt - plg_st_dt) > 1))
							break;

						log_on_dt = row2.getData("log_on_dt", c);
					}

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2016.01.21.01");
						setComment("LOG OFF 시간");
						setQuery("SELECT");
						setQuery("	TO_CHAR(idl_st_dt, 'YYYY-MM-DD HH24:MI:SS') AS log_off_dt");
						setQuery("	, CAST(TO_CHAR(idl_ed_dt, 'YYYYMMDDHH24MISS') AS FLOAT) AS idl_ed_dt");
						setQuery("	, TO_CHAR(idl_ed_dt, 'YYYY-MM-DD HH24:MI:SS') AS log_ed_dt");
						setQuery("FROM");
						setQuery("	jovt_idlelog");
						setQuery("WHERE");
						setQuery("	idl_st_dt < idl_ed_dt");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND idl_ymd = ?", calc_day);
						setQuery("	AND idl_st_dt <= TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US')", pc_off_dt);
						setQuery("ORDER BY");
						setQuery("	idl_st_dt DESC, idl_ed_dt DESC");
						row2 = getRs();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2016.01.21.01");
						setComment("LOG OFF 시간");
						setQuery("SELECT");
						setQuery("	TO_CHAR(idl_st_dt, 'YYYY-MM-DD HH24:MI:SS') AS log_off_dt");
						setQuery("	, CAST(TO_CHAR(idl_ed_dt, 'YYYYMMDDHH24MISS') AS FLOAT) AS idl_ed_dt");
						setQuery("	, TO_CHAR(idl_ed_dt, 'YYYY-MM-DD HH24:MI:SS') AS log_ed_dt");
						setQuery("FROM");
						setQuery("	jovt_idlelog");
						setQuery("WHERE");
						setQuery("	idl_st_dt < idl_ed_dt");
						setQuery("	AND emp_no = ?", emp_no);
						setQuery("	AND idl_ymd = ?", calc_day);
						setQuery("	AND idl_st_dt <= TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS')", pc_off_dt);
						setQuery("ORDER BY");
						setQuery("	idl_st_dt DESC, idl_ed_dt DESC");
						row2 = getRs();
					}

					log_off_dt = pc_off_dt;
					long idl_ed_dt = 0;
					String log_ed_dt = "";

					for (int c = 0; c < row2.getRsCount(); c++) {
						idl_ed_dt = row2.getLong("idl_ed_dt", c);
						log_ed_dt = row2.getData("log_ed_dt", c);

						// (PC OFF시각 > IDLE 종료시각) && ((PC OFF시각 - IDLE 종료시각) > 1)
						if ((plg_ed_dt > idl_ed_dt) && ((plg_ed_dt - idl_ed_dt) > 1)
							&& !StringUtil.isEquals(log_off_dt, log_ed_dt))
							break;

						log_off_dt = row2.getData("log_off_dt", c);
					}

					if (log_on_dt.compareTo(log_off_dt) > 0) {
						log_on_dt = "";
						log_off_dt = "";
					}

					// ########## 인정시간 저장 ##########
					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2017.01.19.01");
						setComment("인정시간 저장");
						setQuery("WITH");
						setQuery("	to_be_upserted (");
						setQuery("		cal_ymd, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd");
						setQuery("		, ot_type, ot_type_1, ot_type_2, holiday_yn, exception_yn");
						setQuery("		, work_work_mm, work_idle_mm, work_acpt_mm, work_close_tm");
						setQuery("		, over_work_mm, over_acpt_mm, over_idle_mm");
						setQuery("		, pc_on_dt, pc_off_dt, log_on_dt, log_off_dt");
						setQuery("	) AS");
						setQuery("	(");
						setQuery("		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?");
						setQuery("		, TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US')");
						setQuery("		, TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US')");
						setQuery("		, (CASE WHEN ? = '' THEN NULL ELSE TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US') END)");
						setQuery("		, (CASE WHEN ? = '' THEN NULL ELSE TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US') END)");
						setQuery("		)");
						setQuery("	),");
						setQuery("	updated AS");
						setQuery("	(");
						setQuery("		UPDATE jovt_otcalc SET");
						setQuery("			dpt_cd = to_be_upserted.dpt_cd");
						setQuery("			, pos_cd = to_be_upserted.pos_cd");
						setQuery("			, tit_cd = to_be_upserted.tit_cd");
						setQuery("			, jik_cd = to_be_upserted.jik_cd");
						setQuery("			, ot_type = to_be_upserted.ot_type");
						setQuery("			, ot_type_1 = to_be_upserted.ot_type_1");
						setQuery("			, ot_type_2 = to_be_upserted.ot_type_2");
						setQuery("			, holiday_yn = to_be_upserted.holiday_yn");
						setQuery("			, exception_yn = to_be_upserted.exception_yn");
						setQuery("			, work_work_mm = to_be_upserted.work_work_mm");
						setQuery("			, work_idle_mm = to_be_upserted.work_idle_mm");
						setQuery("			, work_acpt_mm = to_be_upserted.work_acpt_mm");
						//setQuery("			, work_close_tm = to_be_upserted.work_close_tm");
						setQuery("			, work_close_tm = (CASE WHEN jovt_otcalc.work_close_tm IS NULL OR TRIM(jovt_otcalc.work_close_tm) = '' THEN to_be_upserted.work_close_tm ELSE jovt_otcalc.work_close_tm END)");
						setQuery("			, over_work_mm = to_be_upserted.over_work_mm");
						setQuery("			, over_acpt_mm = to_be_upserted.over_acpt_mm");
						setQuery("			, over_idle_mm = to_be_upserted.over_idle_mm");
						setQuery("			, pc_on_dt = to_be_upserted.pc_on_dt");
						setQuery("			, pc_off_dt = to_be_upserted.pc_off_dt");
						setQuery("			, log_on_dt = to_be_upserted.log_on_dt");
						setQuery("			, log_off_dt = to_be_upserted.log_off_dt");
						setQuery("		FROM");
						setQuery("			to_be_upserted");
						setQuery("		WHERE");
						setQuery("			jovt_otcalc.cal_ymd = to_be_upserted.cal_ymd");
						setQuery("			AND jovt_otcalc.emp_no = to_be_upserted.emp_no");
						setQuery("		RETURNING jovt_otcalc.*");
						setQuery("	)");
						setQuery("	INSERT INTO jovt_otcalc");
						setQuery("		(cal_ymd, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd");
						setQuery("		, ot_type, ot_type_1, ot_type_2, holiday_yn, exception_yn");
						setQuery("		, work_work_mm, work_idle_mm, work_acpt_mm, work_close_tm");
						setQuery("		, over_work_mm, over_acpt_mm, over_idle_mm");
						setQuery("		, pc_on_dt, pc_off_dt, log_on_dt, log_off_dt)");
						setQuery("	SELECT");
						setQuery("		to_be_upserted.cal_ymd, to_be_upserted.emp_no, to_be_upserted.dpt_cd, to_be_upserted.pos_cd, to_be_upserted.tit_cd, to_be_upserted.jik_cd");
						setQuery("		, to_be_upserted.ot_type, to_be_upserted.ot_type_1, to_be_upserted.ot_type_2, to_be_upserted.holiday_yn, to_be_upserted.exception_yn");
						setQuery("		, to_be_upserted.work_work_mm, to_be_upserted.work_idle_mm, to_be_upserted.work_acpt_mm, to_be_upserted.work_close_tm");
						setQuery("		, to_be_upserted.over_work_mm, to_be_upserted.over_acpt_mm, to_be_upserted.over_idle_mm");
						setQuery("		, to_be_upserted.pc_on_dt, to_be_upserted.pc_off_dt, to_be_upserted.log_on_dt, to_be_upserted.log_off_dt");
						setQuery("	FROM");
						setQuery("		to_be_upserted");
						setQuery("	WHERE");
						setQuery("		cal_ymd NOT IN (SELECT cal_ymd FROM updated)");
						setQuery("		AND emp_no NOT IN (SELECT emp_no FROM updated)");
						setParam(calc_day);
						setParam(emp_no);
						setParam(dpt_cd);
						setParam(pos_cd);
						setParam(tit_cd);
						setParam(jik_cd);
						setParamInt(ot_type);
						setParamInt(ot_type_1);
						setParamInt(ot_type_2);
						setParamInt(holiday_yn);
						setParamInt(exception_yn);
						setParamInt(work_work_mm);
						setParamInt(work_idle_mm);
						setParamInt(work_acpt_mm);
						setParam(work_close_tm);
						setParamInt(over_work_mm);
						setParamInt(over_acpt_mm);
						setParamInt(over_idle_mm);
						setParam(pc_on_dt);
						setParam(pc_off_dt);
						setParam(log_on_dt);
						setParam(log_on_dt);
						setParam(log_off_dt);
						setParam(log_off_dt);
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2017.01.19.01");
						setComment("인정시간 저장");
						setQuery("MERGE INTO jovt_otcalc");
						setQuery("	USING DUAL");
						setQuery("	ON (cal_ymd = ? AND emp_no = ?)");
						setQuery("WHEN MATCHED THEN");
						setQuery("	UPDATE SET");
						setQuery("		dpt_cd = ?");
						setQuery("		, pos_cd = ?");
						setQuery("		, tit_cd = ?");
						setQuery("		, jik_cd = ?");
						setQuery("		, ot_type = ?");
						setQuery("		, ot_type_1 = ?");
						setQuery("		, ot_type_2 = ?");
						setQuery("		, holiday_yn = ?");
						setQuery("		, exception_yn = ?");
						setQuery("		, work_work_mm = ?");
						setQuery("		, work_idle_mm = ?");
						setQuery("		, work_acpt_mm = ?");
						//setQuery("		, work_close_tm = ?");
						setQuery("		, work_close_tm = (CASE WHEN jovt_otcalc.work_close_tm IS NULL OR TRIM(jovt_otcalc.work_close_tm) = '' THEN ? ELSE jovt_otcalc.work_close_tm END)");
						setQuery("		, over_work_mm = ?");
						setQuery("		, over_acpt_mm = ?");
						setQuery("		, over_idle_mm = ?");
						setQuery("		, pc_on_dt = TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS')");
						setQuery("		, pc_off_dt = TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS')");
						setQuery("		, log_on_dt = (CASE WHEN ? IS NULL THEN NULL ELSE TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS') END)");
						setQuery("		, log_off_dt = (CASE WHEN ? IS NULL THEN NULL ELSE TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS') END)");
						setQuery("WHEN NOT MATCHED THEN");
						setQuery("	INSERT");
						setQuery("		(cal_ymd, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd");
						setQuery("		, ot_type, ot_type_1, ot_type_2, holiday_yn, exception_yn");
						setQuery("		, work_work_mm, work_idle_mm, work_acpt_mm, work_close_tm");
						setQuery("		, over_work_mm, over_acpt_mm, over_idle_mm");
						setQuery("		, pc_on_dt, pc_off_dt, log_on_dt, log_off_dt)");
						setQuery("	VALUES");
						setQuery("		(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?");
						setQuery("		, TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS')");
						setQuery("		, TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS')");
						setQuery("		, (CASE WHEN ? IS NULL THEN NULL ELSE TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS') END)");
						setQuery("		, (CASE WHEN ? IS NULL THEN NULL ELSE TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS') END)");
						setQuery("		)");
						setParam(calc_day);
						setParam(emp_no);
						setParam(dpt_cd);
						setParam(pos_cd);
						setParam(tit_cd);
						setParam(jik_cd);
						setParamInt(ot_type);
						setParamInt(ot_type_1);
						setParamInt(ot_type_2);
						setParamInt(holiday_yn);
						setParamInt(exception_yn);
						setParamInt(work_work_mm);
						setParamInt(work_idle_mm);
						setParamInt(work_acpt_mm);
						setParam(work_close_tm);
						setParamInt(over_work_mm);
						setParamInt(over_acpt_mm);
						setParamInt(over_idle_mm);
						setParam(pc_on_dt);
						setParam(pc_off_dt);
						setParam(log_on_dt);
						setParam(log_on_dt);
						setParam(log_off_dt);
						setParam(log_off_dt);
						setParam(calc_day);
						setParam(emp_no);
						setParam(dpt_cd);
						setParam(pos_cd);
						setParam(tit_cd);
						setParam(jik_cd);
						setParamInt(ot_type);
						setParamInt(ot_type_1);
						setParamInt(ot_type_2);
						setParamInt(holiday_yn);
						setParamInt(exception_yn);
						setParamInt(work_work_mm);
						setParamInt(work_idle_mm);
						setParamInt(work_acpt_mm);
						setParam(work_close_tm);
						setParamInt(over_work_mm);
						setParamInt(over_acpt_mm);
						setParamInt(over_idle_mm);
						setParam(pc_on_dt);
						setParam(pc_off_dt);
						setParam(log_on_dt);
						setParam(log_on_dt);
						setParam(log_off_dt);
						setParam(log_off_dt);
						executeQuery();
					}

					// ########## 통계처리 플래그 설정 ##########
					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 플래그 설정 (개인별)");
						setQuery("WITH");
//						setQuery("	to_be_upserted (stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd) AS");
						setQuery("	to_be_upserted (stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd) AS");
						setQuery("	(");
//						setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, ?, ?, ?, ?)");
						setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, ?, ?, ?)");
						setQuery("	),");
						setQuery("	updated AS");
						setQuery("	(");
						setQuery("		UPDATE jovt_stat_pconoff_emp SET");
						setQuery("			need_recalc = 1");
						setQuery("		FROM");
						setQuery("			to_be_upserted");
						setQuery("		WHERE");
						setQuery("			jovt_stat_pconoff_emp.stat_year = to_be_upserted.stat_year");
						setQuery("			AND jovt_stat_pconoff_emp.stat_month = to_be_upserted.stat_month");
						setQuery("			AND jovt_stat_pconoff_emp.emp_no = to_be_upserted.emp_no");
						setQuery("			AND jovt_stat_pconoff_emp.dpt_cd = to_be_upserted.dpt_cd");
						setQuery("			AND jovt_stat_pconoff_emp.pos_cd = to_be_upserted.pos_cd");
						setQuery("			AND jovt_stat_pconoff_emp.tit_cd = to_be_upserted.tit_cd");
//						setQuery("			AND jovt_stat_pconoff_emp.jik_cd = to_be_upserted.jik_cd");
						setQuery("		RETURNING jovt_stat_pconoff_emp.*");
						setQuery("	)");
						setQuery("	INSERT INTO jovt_stat_pconoff_emp");
//						setQuery("		(stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd, need_recalc)");
						setQuery("		(stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, need_recalc)");
						setQuery("	SELECT");
						setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.emp_no");
//						setQuery("		, to_be_upserted.dpt_cd, to_be_upserted.pos_cd, to_be_upserted.tit_cd, to_be_upserted.jik_cd, 1");
						setQuery("		, to_be_upserted.dpt_cd, to_be_upserted.pos_cd, to_be_upserted.tit_cd, 1");
						setQuery("	FROM");
						setQuery("		to_be_upserted");
						setQuery("	WHERE");
						setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
						setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
						setQuery("		AND emp_no NOT IN (SELECT emp_no FROM updated)");
						setQuery("		AND dpt_cd NOT IN (SELECT dpt_cd FROM updated)");
						setQuery("		AND pos_cd NOT IN (SELECT pos_cd FROM updated)");
						setQuery("		AND tit_cd NOT IN (SELECT tit_cd FROM updated)");
//						setQuery("		AND jik_cd NOT IN (SELECT jik_cd FROM updated)");
						setParam(calc_day);
						setParam(calc_day);
						setParam(emp_no);
						setParam(dpt_cd);
						setParam(pos_cd);
						setParam(tit_cd);
//						setParam(jik_cd);
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 플래그 설정 (개인별)");
						setQuery("MERGE INTO jovt_stat_pconoff_emp");
						setQuery("	USING DUAL");
						setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND emp_no = ?");
						//setQuery("		AND dpt_cd = ? AND pos_cd = ? AND tit_cd = ? AND jik_cd = ?)");
						setQuery("		AND dpt_cd = ? AND pos_cd = ? AND tit_cd = ?)");
						setQuery("WHEN MATCHED THEN");
						setQuery("	UPDATE SET");
						setQuery("		need_recalc = 1");
						setQuery("WHEN NOT MATCHED THEN");
						setQuery("	INSERT");
						//setQuery("		(stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd, need_recalc)");
						setQuery("		(stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, need_recalc)");
						setQuery("	VALUES");
						setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, ?, ?, ?, 1)");
						setParam(calc_day);
						setParam(calc_day);
						setParam(emp_no);
						setParam(dpt_cd);
						setParam(pos_cd);
						setParam(tit_cd);
						//setParam(jik_cd);
						setParam(calc_day);
						setParam(calc_day);
						setParam(emp_no);
						setParam(dpt_cd);
						setParam(pos_cd);
						setParam(tit_cd);
						//setParam(jik_cd);
						executeQuery();
					}

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.05.28.01");
						setComment("PC ON/OFF 통계처리 플래그 설정 (부서별)");
						setQuery("WITH");
						setQuery("	to_be_upserted (stat_year, stat_month, dpt_cd) AS");
						setQuery("	(");
						setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?)");
						setQuery("	),");
						setQuery("	updated AS");
						setQuery("	(");
						setQuery("		UPDATE jovt_stat_pconoff_dpt SET");
						setQuery("			need_recalc = 1");
						setQuery("		FROM");
						setQuery("			to_be_upserted");
						setQuery("		WHERE");
						setQuery("			jovt_stat_pconoff_dpt.stat_year = to_be_upserted.stat_year");
						setQuery("			AND jovt_stat_pconoff_dpt.stat_month = to_be_upserted.stat_month");
						setQuery("			AND jovt_stat_pconoff_dpt.dpt_cd = to_be_upserted.dpt_cd");
						setQuery("		RETURNING jovt_stat_pconoff_dpt.*");
						setQuery("	)");
						setQuery("	INSERT INTO jovt_stat_pconoff_dpt");
						setQuery("		(stat_year, stat_month, dpt_cd, need_recalc)");
						setQuery("	SELECT");
						setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.dpt_cd, 1");
						setQuery("	FROM");
						setQuery("		to_be_upserted");
						setQuery("	WHERE");
						setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
						setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
						setQuery("		AND dpt_cd NOT IN (SELECT dpt_cd FROM updated)");
						setParam(calc_day);
						setParam(calc_day);
						setParam(dpt_cd);
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.05.28.01");
						setComment("PC ON/OFF 통계처리 플래그 설정 (부서별)");
						setQuery("MERGE INTO jovt_stat_pconoff_dpt");
						setQuery("	USING DUAL");
						setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND dpt_cd = ?)");
						setQuery("WHEN MATCHED THEN");
						setQuery("	UPDATE SET");
						setQuery("		need_recalc = 1");
						setQuery("WHEN NOT MATCHED THEN");
						setQuery("	INSERT");
						setQuery("		(stat_year, stat_month, dpt_cd, need_recalc)");
						setQuery("	VALUES");
						setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, 1)");
						setParam(calc_day);
						setParam(calc_day);
						setParam(dpt_cd);
						setParam(calc_day);
						setParam(calc_day);
						setParam(dpt_cd);
						executeQuery();
					}

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.05.28.01");
						setComment("PC ON/OFF 통계처리 플래그 설정 (직급별)");
						setQuery("WITH");
						setQuery("	to_be_upserted (stat_year, stat_month, pos_cd) AS");
						setQuery("	(");
						setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?)");
						setQuery("	),");
						setQuery("	updated AS");
						setQuery("	(");
						setQuery("		UPDATE jovt_stat_pconoff_position SET");
						setQuery("			need_recalc = 1");
						setQuery("		FROM");
						setQuery("			to_be_upserted");
						setQuery("		WHERE");
						setQuery("			jovt_stat_pconoff_position.stat_year = to_be_upserted.stat_year");
						setQuery("			AND jovt_stat_pconoff_position.stat_month = to_be_upserted.stat_month");
						setQuery("			AND jovt_stat_pconoff_position.pos_cd = to_be_upserted.pos_cd");
						setQuery("		RETURNING jovt_stat_pconoff_position.*");
						setQuery("	)");
						setQuery("	INSERT INTO jovt_stat_pconoff_position");
						setQuery("		(stat_year, stat_month, pos_cd, need_recalc)");
						setQuery("	SELECT");
						setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.pos_cd, 1");
						setQuery("	FROM");
						setQuery("		to_be_upserted");
						setQuery("	WHERE");
						setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
						setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
						setQuery("		AND pos_cd NOT IN (SELECT pos_cd FROM updated)");
						setParam(calc_day);
						setParam(calc_day);
						setParam(pos_cd);
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.05.28.01");
						setComment("PC ON/OFF 통계처리 플래그 설정 (직급별)");
						setQuery("MERGE INTO jovt_stat_pconoff_position");
						setQuery("	USING DUAL");
						setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND pos_cd = ?)");
						setQuery("WHEN MATCHED THEN");
						setQuery("	UPDATE SET");
						setQuery("		need_recalc = 1");
						setQuery("WHEN NOT MATCHED THEN");
						setQuery("	INSERT");
						setQuery("		(stat_year, stat_month, pos_cd, need_recalc)");
						setQuery("	VALUES");
						setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, 1)");
						setParam(calc_day);
						setParam(calc_day);
						setParam(pos_cd);
						setParam(calc_day);
						setParam(calc_day);
						setParam(pos_cd);
						executeQuery();
					}

					if (StringUtil.isEquals(Const.DEFAULT_OPTION_TIT, "Y")) {
						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2015.11.20.01");
							setComment("PC ON/OFF 통계처리 플래그 설정 (직위별)");
							setQuery("WITH");
							setQuery("	to_be_upserted (stat_year, stat_month, tit_cd) AS");
							setQuery("	(");
							setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?)");
							setQuery("	),");
							setQuery("	updated AS");
							setQuery("	(");
							setQuery("		UPDATE jovt_stat_pconoff_title SET");
							setQuery("			need_recalc = 1");
							setQuery("		FROM");
							setQuery("			to_be_upserted");
							setQuery("		WHERE");
							setQuery("			jovt_stat_pconoff_title.stat_year = to_be_upserted.stat_year");
							setQuery("			AND jovt_stat_pconoff_title.stat_month = to_be_upserted.stat_month");
							setQuery("			AND jovt_stat_pconoff_title.tit_cd = to_be_upserted.tit_cd");
							setQuery("		RETURNING jovt_stat_pconoff_title.*");
							setQuery("	)");
							setQuery("	INSERT INTO jovt_stat_pconoff_title");
							setQuery("		(stat_year, stat_month, tit_cd, need_recalc)");
							setQuery("	SELECT");
							setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.tit_cd, 1");
							setQuery("	FROM");
							setQuery("		to_be_upserted");
							setQuery("	WHERE");
							setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
							setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
							setQuery("		AND tit_cd NOT IN (SELECT tit_cd FROM updated)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(tit_cd);
							executeQuery();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2015.11.20.01");
							setComment("PC ON/OFF 통계처리 플래그 설정 (직위별)");
							setQuery("MERGE INTO jovt_stat_pconoff_title");
							setQuery("	USING DUAL");
							setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND tit_cd = ?)");
							setQuery("WHEN MATCHED THEN");
							setQuery("	UPDATE SET");
							setQuery("		need_recalc = 1");
							setQuery("WHEN NOT MATCHED THEN");
							setQuery("	INSERT");
							setQuery("		(stat_year, stat_month, tit_cd, need_recalc)");
							setQuery("	VALUES");
							setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, 1)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(tit_cd);
							setParam(calc_day);
							setParam(calc_day);
							setParam(tit_cd);
							executeQuery();
						}
					}

					if (StringUtil.isEquals(Const.DEFAULT_OPTION_JIK, "Y")) {
						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2015.11.20.01");
							setComment("PC ON/OFF 통계처리 플래그 설정 (직책별)");
							setQuery("WITH");
							setQuery("	to_be_upserted (stat_year, stat_month, jik_cd) AS");
							setQuery("	(");
							setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?)");
							setQuery("	),");
							setQuery("	updated AS");
							setQuery("	(");
							setQuery("		UPDATE jovt_stat_pconoff_jikjong SET");
							setQuery("			need_recalc = 1");
							setQuery("		FROM");
							setQuery("			to_be_upserted");
							setQuery("		WHERE");
							setQuery("			jovt_stat_pconoff_jikjong.stat_year = to_be_upserted.stat_year");
							setQuery("			AND jovt_stat_pconoff_jikjong.stat_month = to_be_upserted.stat_month");
							setQuery("			AND jovt_stat_pconoff_jikjong.jik_cd = to_be_upserted.jik_cd");
							setQuery("		RETURNING jovt_stat_pconoff_jikjong.*");
							setQuery("	)");
							setQuery("	INSERT INTO jovt_stat_pconoff_jikjong");
							setQuery("		(stat_year, stat_month, jik_cd, need_recalc)");
							setQuery("	SELECT");
							setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.jik_cd, 1");
							setQuery("	FROM");
							setQuery("		to_be_upserted");
							setQuery("	WHERE");
							setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
							setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
							setQuery("		AND jik_cd NOT IN (SELECT jik_cd FROM updated)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(jik_cd);
							executeQuery();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2015.11.20.01");
							setComment("PC ON/OFF 통계처리 플래그 설정 (직책별)");
							setQuery("MERGE INTO jovt_stat_pconoff_jikjong");
							setQuery("	USING DUAL");
							setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND jik_cd = ?)");
							setQuery("WHEN MATCHED THEN");
							setQuery("	UPDATE SET");
							setQuery("		need_recalc = 1");
							setQuery("WHEN NOT MATCHED THEN");
							setQuery("	INSERT");
							setQuery("		(stat_year, stat_month, jik_cd, need_recalc)");
							setQuery("	VALUES");
							setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, 1)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(jik_cd);
							setParam(calc_day);
							setParam(calc_day);
							setParam(jik_cd);
							executeQuery();
						}
					}

					if (Integer.parseInt(ot_type) > 0) {
						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2015.11.20.01");
							setComment("PC 연장사용 통계처리 플래그 설정 (개인별)");
							setQuery("WITH");
//							setQuery("	to_be_upserted (stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd) AS");
							setQuery("	to_be_upserted (stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd) AS");
							setQuery("	(");
//							setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, ?, ?, ?, ?)");
							setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, ?, ?, ?)");
							setQuery("	),");
							setQuery("	updated AS");
							setQuery("	(");
							setQuery("		UPDATE jovt_stat_otcalc_emp SET");
							setQuery("			need_recalc = 1");
							setQuery("		FROM");
							setQuery("			to_be_upserted");
							setQuery("		WHERE");
							setQuery("			jovt_stat_otcalc_emp.stat_year = to_be_upserted.stat_year");
							setQuery("			AND jovt_stat_otcalc_emp.stat_month = to_be_upserted.stat_month");
							setQuery("			AND jovt_stat_otcalc_emp.emp_no = to_be_upserted.emp_no");
							setQuery("			AND jovt_stat_otcalc_emp.dpt_cd = to_be_upserted.dpt_cd");
							setQuery("			AND jovt_stat_otcalc_emp.pos_cd = to_be_upserted.pos_cd");
							setQuery("			AND jovt_stat_otcalc_emp.tit_cd = to_be_upserted.tit_cd");
//							setQuery("			AND jovt_stat_otcalc_emp.jik_cd = to_be_upserted.jik_cd");
							setQuery("		RETURNING jovt_stat_otcalc_emp.*");
							setQuery("	)");
							setQuery("	INSERT INTO jovt_stat_otcalc_emp");
//							setQuery("		(stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd, need_recalc)");
							setQuery("		(stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, need_recalc)");
							setQuery("	SELECT");
							setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.emp_no");
//							setQuery("		, to_be_upserted.dpt_cd, to_be_upserted.pos_cd, to_be_upserted.tit_cd, to_be_upserted.jik_cd, 1");
							setQuery("		, to_be_upserted.dpt_cd, to_be_upserted.pos_cd, to_be_upserted.tit_cd, 1");
							setQuery("	FROM");
							setQuery("		to_be_upserted");
							setQuery("	WHERE");
							setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
							setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
							setQuery("		AND emp_no NOT IN (SELECT emp_no FROM updated)");
							setQuery("		AND dpt_cd NOT IN (SELECT dpt_cd FROM updated)");
							setQuery("		AND pos_cd NOT IN (SELECT pos_cd FROM updated)");
							setQuery("		AND tit_cd NOT IN (SELECT tit_cd FROM updated)");
//							setQuery("		AND jik_cd NOT IN (SELECT jik_cd FROM updated)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(emp_no);
							setParam(dpt_cd);
							setParam(pos_cd);
							setParam(tit_cd);
//							setParam(jik_cd);
							executeQuery();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2015.11.20.01");
							setComment("PC 연장사용 통계처리 플래그 설정 (개인별)");
							setQuery("MERGE INTO jovt_stat_otcalc_emp");
							setQuery("	USING DUAL");
							setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND emp_no = ?");
							//setQuery("		AND dpt_cd = ? AND pos_cd = ? AND tit_cd = ? AND jik_cd = ?)");
							setQuery("		AND dpt_cd = ? AND pos_cd = ? AND tit_cd = ?)");
							setQuery("WHEN MATCHED THEN");
							setQuery("	UPDATE SET");
							setQuery("		need_recalc = 1");
							setQuery("WHEN NOT MATCHED THEN");
							setQuery("	INSERT");
							//setQuery("		(stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd, need_recalc)");
							setQuery("		(stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, need_recalc)");
							setQuery("	VALUES");
							setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, ?, ?, ?, 1)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(emp_no);
							setParam(dpt_cd);
							setParam(pos_cd);
							setParam(tit_cd);
							//setParam(jik_cd);
							setParam(calc_day);
							setParam(calc_day);
							setParam(emp_no);
							setParam(dpt_cd);
							setParam(pos_cd);
							setParam(tit_cd);
							//setParam(jik_cd);
							executeQuery();
						}

						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2015.05.28.01");
							setComment("PC 연장사용 통계처리 플래그 설정 (부서별)");
							setQuery("WITH");
							setQuery("	to_be_upserted (stat_year, stat_month, dpt_cd) AS");
							setQuery("	(");
							setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?)");
							setQuery("	),");
							setQuery("	updated AS");
							setQuery("	(");
							setQuery("		UPDATE jovt_stat_otcalc_dpt SET");
							setQuery("			need_recalc = 1");
							setQuery("		FROM");
							setQuery("			to_be_upserted");
							setQuery("		WHERE");
							setQuery("			jovt_stat_otcalc_dpt.stat_year = to_be_upserted.stat_year");
							setQuery("			AND jovt_stat_otcalc_dpt.stat_month = to_be_upserted.stat_month");
							setQuery("			AND jovt_stat_otcalc_dpt.dpt_cd = to_be_upserted.dpt_cd");
							setQuery("		RETURNING jovt_stat_otcalc_dpt.*");
							setQuery("	)");
							setQuery("	INSERT INTO jovt_stat_otcalc_dpt");
							setQuery("		(stat_year, stat_month, dpt_cd, need_recalc)");
							setQuery("	SELECT");
							setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.dpt_cd, 1");
							setQuery("	FROM");
							setQuery("		to_be_upserted");
							setQuery("	WHERE");
							setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
							setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
							setQuery("		AND dpt_cd NOT IN (SELECT dpt_cd FROM updated)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(dpt_cd);
							executeQuery();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2015.05.28.01");
							setComment("PC 연장사용 통계처리 플래그 설정 (부서별)");
							setQuery("MERGE INTO jovt_stat_otcalc_dpt");
							setQuery("	USING DUAL");
							setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND dpt_cd = ?)");
							setQuery("WHEN MATCHED THEN");
							setQuery("	UPDATE SET");
							setQuery("		need_recalc = 1");
							setQuery("WHEN NOT MATCHED THEN");
							setQuery("	INSERT");
							setQuery("		(stat_year, stat_month, dpt_cd, need_recalc)");
							setQuery("	VALUES");
							setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, 1)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(dpt_cd);
							setParam(calc_day);
							setParam(calc_day);
							setParam(dpt_cd);
							executeQuery();
						}

						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2015.05.28.01");
							setComment("PC 연장사용 통계처리 플래그 설정 (직급별)");
							setQuery("WITH");
							setQuery("	to_be_upserted (stat_year, stat_month, pos_cd) AS");
							setQuery("	(");
							setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?)");
							setQuery("	),");
							setQuery("	updated AS");
							setQuery("	(");
							setQuery("		UPDATE jovt_stat_otcalc_position SET");
							setQuery("			need_recalc = 1");
							setQuery("		FROM");
							setQuery("			to_be_upserted");
							setQuery("		WHERE");
							setQuery("			jovt_stat_otcalc_position.stat_year = to_be_upserted.stat_year");
							setQuery("			AND jovt_stat_otcalc_position.stat_month = to_be_upserted.stat_month");
							setQuery("			AND jovt_stat_otcalc_position.pos_cd = to_be_upserted.pos_cd");
							setQuery("		RETURNING jovt_stat_otcalc_position.*");
							setQuery("	)");
							setQuery("	INSERT INTO jovt_stat_otcalc_position");
							setQuery("		(stat_year, stat_month, pos_cd, need_recalc)");
							setQuery("	SELECT");
							setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.pos_cd, 1");
							setQuery("	FROM");
							setQuery("		to_be_upserted");
							setQuery("	WHERE");
							setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
							setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
							setQuery("		AND pos_cd NOT IN (SELECT pos_cd FROM updated)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(pos_cd);
							executeQuery();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2015.05.28.01");
							setComment("PC 연장사용 통계처리 플래그 설정 (직급별)");
							setQuery("MERGE INTO jovt_stat_otcalc_position");
							setQuery("	USING DUAL");
							setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND pos_cd = ?)");
							setQuery("WHEN MATCHED THEN");
							setQuery("	UPDATE SET");
							setQuery("		need_recalc = 1");
							setQuery("WHEN NOT MATCHED THEN");
							setQuery("	INSERT");
							setQuery("		(stat_year, stat_month, pos_cd, need_recalc)");
							setQuery("	VALUES");
							setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, 1)");
							setParam(calc_day);
							setParam(calc_day);
							setParam(pos_cd);
							setParam(calc_day);
							setParam(calc_day);
							setParam(pos_cd);
							executeQuery();
						}

						if (StringUtil.isEquals(Const.DEFAULT_OPTION_TIT, "Y")) {
							if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
								/* POSTGRESQL */
								setVersion("2015.11.20.01");
								setComment("PC 연장사용 통계처리 플래그 설정 (직위별)");
								setQuery("WITH");
								setQuery("	to_be_upserted (stat_year, stat_month, tit_cd) AS");
								setQuery("	(");
								setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?)");
								setQuery("	),");
								setQuery("	updated AS");
								setQuery("	(");
								setQuery("		UPDATE jovt_stat_otcalc_title SET");
								setQuery("			need_recalc = 1");
								setQuery("		FROM");
								setQuery("			to_be_upserted");
								setQuery("		WHERE");
								setQuery("			jovt_stat_otcalc_title.stat_year = to_be_upserted.stat_year");
								setQuery("			AND jovt_stat_otcalc_title.stat_month = to_be_upserted.stat_month");
								setQuery("			AND jovt_stat_otcalc_title.tit_cd = to_be_upserted.tit_cd");
								setQuery("		RETURNING jovt_stat_otcalc_title.*");
								setQuery("	)");
								setQuery("	INSERT INTO jovt_stat_otcalc_title");
								setQuery("		(stat_year, stat_month, tit_cd, need_recalc)");
								setQuery("	SELECT");
								setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.tit_cd, 1");
								setQuery("	FROM");
								setQuery("		to_be_upserted");
								setQuery("	WHERE");
								setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
								setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
								setQuery("		AND tit_cd NOT IN (SELECT tit_cd FROM updated)");
								setParam(calc_day);
								setParam(calc_day);
								setParam(tit_cd);
								executeQuery();
							} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
								/* ORACLE */
								setVersion("2015.11.20.01");
								setComment("PC 연장사용 통계처리 플래그 설정 (직위별)");
								setQuery("MERGE INTO jovt_stat_otcalc_title");
								setQuery("	USING DUAL");
								setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND tit_cd = ?)");
								setQuery("WHEN MATCHED THEN");
								setQuery("	UPDATE SET");
								setQuery("		need_recalc = 1");
								setQuery("WHEN NOT MATCHED THEN");
								setQuery("	INSERT");
								setQuery("		(stat_year, stat_month, tit_cd, need_recalc)");
								setQuery("	VALUES");
								setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, 1)");
								setParam(calc_day);
								setParam(calc_day);
								setParam(tit_cd);
								setParam(calc_day);
								setParam(calc_day);
								setParam(tit_cd);
								executeQuery();
							}
						}

						if (StringUtil.isEquals(Const.DEFAULT_OPTION_JIK, "Y")) {
							if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
								/* POSTGRESQL */
								setVersion("2015.11.20.01");
								setComment("PC 연장사용 통계처리 플래그 설정 (직책별)");
								setQuery("WITH");
								setQuery("	to_be_upserted (stat_year, stat_month, jik_cd) AS");
								setQuery("	(");
								setQuery("		VALUES (SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?)");
								setQuery("	),");
								setQuery("	updated AS");
								setQuery("	(");
								setQuery("		UPDATE jovt_stat_otcalc_jikjong SET");
								setQuery("			need_recalc = 1");
								setQuery("		FROM");
								setQuery("			to_be_upserted");
								setQuery("		WHERE");
								setQuery("			jovt_stat_otcalc_jikjong.stat_year = to_be_upserted.stat_year");
								setQuery("			AND jovt_stat_otcalc_jikjong.stat_month = to_be_upserted.stat_month");
								setQuery("			AND jovt_stat_otcalc_jikjong.jik_cd = to_be_upserted.jik_cd");
								setQuery("		RETURNING jovt_stat_otcalc_jikjong.*");
								setQuery("	)");
								setQuery("	INSERT INTO jovt_stat_otcalc_jikjong");
								setQuery("		(stat_year, stat_month, jik_cd, need_recalc)");
								setQuery("	SELECT");
								setQuery("		to_be_upserted.stat_year, to_be_upserted.stat_month, to_be_upserted.jik_cd, 1");
								setQuery("	FROM");
								setQuery("		to_be_upserted");
								setQuery("	WHERE");
								setQuery("		stat_year NOT IN (SELECT stat_year FROM updated)");
								setQuery("		AND stat_month NOT IN (SELECT stat_month FROM updated)");
								setQuery("		AND jik_cd NOT IN (SELECT jik_cd FROM updated)");
								setParam(calc_day);
								setParam(calc_day);
								setParam(jik_cd);
								executeQuery();
							} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
								/* ORACLE */
								setVersion("2015.11.20.01");
								setComment("PC 연장사용 통계처리 플래그 설정 (직책별)");
								setQuery("MERGE INTO jovt_stat_otcalc_jikjong");
								setQuery("	USING DUAL");
								setQuery("	ON (stat_year = SUBSTR(?, 1, 4) AND stat_month = SUBSTR(?, 5, 2) AND jik_cd = ?)");
								setQuery("WHEN MATCHED THEN");
								setQuery("	UPDATE SET");
								setQuery("		need_recalc = 1");
								setQuery("WHEN NOT MATCHED THEN");
								setQuery("	INSERT");
								setQuery("		(stat_year, stat_month, jik_cd, need_recalc)");
								setQuery("	VALUES");
								setQuery("		(SUBSTR(?, 1, 4), SUBSTR(?, 5, 2), ?, 1)");
								setParam(calc_day);
								setParam(calc_day);
								setParam(jik_cd);
								setParam(calc_day);
								setParam(calc_day);
								setParam(jik_cd);
								executeQuery();
							}
						}
					}

					// ########## 계산결과 ##########
					sb.append("\t" + (i+1) + ".calc_day=" + calc_day + "\n");
					sb.append("\t" + (i+1) + ".emp_no=" + emp_no + "\n");
					sb.append("\t" + (i+1) + ".dpt_cd=" + dpt_cd + "\n");
					sb.append("\t" + (i+1) + ".pos_cd=" + pos_cd + "\n");
					sb.append("\t" + (i+1) + ".tit_cd=" + tit_cd + "\n");
					sb.append("\t" + (i+1) + ".jik_cd=" + jik_cd + "\n");
					sb.append("\t" + (i+1) + ".grp_seqno=" + grp_seqno + "\n");
					sb.append("\t" + (i+1) + ".ot_type=" + ot_type + "\n");
					sb.append("\t" + (i+1) + ".ot_type_1=" + ot_type_1 + "\n");
					sb.append("\t" + (i+1) + ".ot_type_2=" + ot_type_2 + "\n");
					sb.append("\t" + (i+1) + ".holiday_yn=" + holiday_yn + "\n");
					sb.append("\t" + (i+1) + ".exception_yn=" + exception_yn + "\n");
					sb.append("\t" + (i+1) + ".work_work_mm=" + work_work_mm + "\n");
					sb.append("\t" + (i+1) + ".work_acpt_mm=" + work_acpt_mm + "\n");
					sb.append("\t" + (i+1) + ".work_idle_mm=" + work_idle_mm + "\n");
					sb.append("\t" + (i+1) + ".work_close_tm=" + work_close_tm + "\n");
					sb.append("\t" + (i+1) + ".over_work_mm=" + over_work_mm + "\n");
					sb.append("\t" + (i+1) + ".over_acpt_mm=" + over_acpt_mm + "\n");
					sb.append("\t" + (i+1) + ".over_idle_mm=" + over_idle_mm + "\n");
					sb.append("\t" + (i+1) + ".pc_on_dt=" + pc_on_dt + "\n");
					sb.append("\t" + (i+1) + ".pc_off_dt=" + pc_off_dt + "\n");
					sb.append("\t" + (i+1) + ".log_on_dt=" + log_on_dt + "\n");
					sb.append("\t" + (i+1) + ".log_off_dt=" + log_off_dt + "\n");

					// ########## 일시사용 저장 ##########
					/* ANSI SQL */
					setVersion("2015.11.19.01");
					setComment("일시사용 시작/끝");
					setQuery("SELECT");
					setQuery("	TO_CHAR(plg_st_dt, 'HH24MI') AS sta_hm");
					setQuery("	, TO_CHAR(plg_ed_dt, 'HH24MI') AS end_hm");
					setQuery("FROM");
					setQuery("	jovt_pclog");
					setQuery("WHERE");
					setQuery("	emp_no = ?", emp_no);
					setQuery("	AND plg_ymd = ?", calc_day);
					setQuery("	AND plg_mode = 41");
					row2 = getRs();

					for (int c = 0; c < row2.getRsCount(); c++) {
						String sta_hm = row2.getData("sta_hm", c);
						String end_hm = row2.getData("end_hm", c);

						if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
							/* POSTGRESQL */
							setVersion("2015.11.19.01");
							setComment("일시사용 저장");
							setQuery("WITH");
							setQuery("	to_be_upserted (work_ymd, emp_no, sta_hm, end_hm) AS");
							setQuery("	(");
							setQuery("		VALUES (?, ?, ?, ?)");
							setQuery("	),");
							setQuery("	updated AS");
							setQuery("	(");
							setQuery("		UPDATE jovt_onetime_use SET");
							setQuery("			end_hm = to_be_upserted.end_hm");
							setQuery("			, need_recalc = 1");
							setQuery("		FROM");
							setQuery("			to_be_upserted");
							setQuery("		WHERE");
							setQuery("			jovt_onetime_use.work_ymd = to_be_upserted.work_ymd");
							setQuery("			AND jovt_onetime_use.emp_no = to_be_upserted.emp_no");
							setQuery("			AND jovt_onetime_use.sta_hm = to_be_upserted.sta_hm");
							setQuery("		RETURNING jovt_onetime_use.*");
							setQuery("	)");
							setQuery("	INSERT INTO jovt_onetime_use");
							setQuery("		(work_ymd, emp_no, sta_hm, end_hm, sum_mm, need_recalc)");
							setQuery("	SELECT");
							setQuery("		to_be_upserted.work_ymd, to_be_upserted.emp_no, to_be_upserted.sta_hm, to_be_upserted.end_hm, 0, 1");
							setQuery("	FROM");
							setQuery("		to_be_upserted");
							setQuery("	WHERE");
							setQuery("		work_ymd NOT IN (SELECT work_ymd FROM updated)");
							setQuery("		AND emp_no NOT IN (SELECT emp_no FROM updated)");
							setQuery("		AND sta_hm NOT IN (SELECT sta_hm FROM updated)");
							setParam(calc_day);
							setParam(emp_no);
							setParam(sta_hm);
							setParam(end_hm);
							executeQuery();
						} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
							/* ORACLE */
							setVersion("2015.11.19.01");
							setComment("일시사용 저장");
							setQuery("MERGE INTO jovt_onetime_use");
							setQuery("	USING DUAL");
							setQuery("	ON (work_ymd = ? AND emp_no = ? AND sta_hm = ?)");
							setQuery("WHEN MATCHED THEN");
							setQuery("	UPDATE SET");
							setQuery("		end_hm = ?");
							setQuery("		, need_recalc = 1");
							setQuery("WHEN NOT MATCHED THEN");
							setQuery("	INSERT");
							setQuery("		(work_ymd, emp_no, sta_hm, end_hm, sum_mm, need_recalc)");
							setQuery("	VALUES");
							setQuery("		(?, ?, ?, ?, 0, 1)");
							setParam(calc_day);
							setParam(emp_no);
							setParam(sta_hm);
							setParam(end_hm);
							setParam(calc_day);
							setParam(emp_no);
							setParam(sta_hm);
							setParam(end_hm);
							executeQuery();
						}
					}
				}

				//commitTran();

				daemon_status = "1";
				daemon_dm_dspt = "성공 (PC 사용기록 계산 (" + calc_day + ") 완료)";
			} catch (Exception e) {
				//rollbackTran();

				daemon_status = "0";
				daemon_dm_dspt = "실패 (PC 사용기록 계산 (" + calc_day + ", " + emp_no + ") 예외 : " + e.getMessage() + ")";
			} finally {
				//closeConn();
			}

			daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			// ########## 로그 정보 ##########
			log += "PC 사용기록 데몬로그\n";
			log += "\t" + "st_tm=" + daemon_st_tm + "\n";
			log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
			log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
			log += "\t" + "status=" + daemon_status + "\n";
			log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
			log += "PC 사용기록 계산결과\n";
			log += sb.toString();

			LogUtil.info(debugKey + "########## Job Trace ##########", log);

			Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
			if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
				Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);
		}
	}

	private void Log(String daemon_st_tm, String daemon_ed_tm, String daemon_dm_nm, String daemon_status, String daemon_dm_dspt) throws DBWorkerException, ResultObjectException {
		if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
			/* POSTGRESQL */
			setVersion("2015.05.27.01");
			setComment("데몬로그 저장");
			setQuery("INSERT INTO jovt_daemon_log");
			setQuery("	(st_tm, ed_tm, dm_nm, status, dm_dspt)");
			setQuery("VALUES");
			setQuery("	(TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US'), TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US'), ?, ?, ?)");
			setParam(daemon_st_tm);
			setParam(daemon_ed_tm);
			setParam(daemon_dm_nm);
			setParamInt(daemon_status);
			setParam(daemon_dm_dspt);
			executeQuery();
		} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
			/* ORACLE */
			setVersion("2015.05.27.01");
			setComment("데몬로그 저장");
			setQuery("INSERT INTO jovt_daemon_log");
			setQuery("	(st_tm, ed_tm, dm_nm, status, dm_dspt)");
			setQuery("VALUES");
			setQuery("	(TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS'), TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS'), ?, ?, ?)");
			setParam(daemon_st_tm);
			setParam(daemon_ed_tm);
			setParam(daemon_dm_nm);
			setParamInt(daemon_status);
			setParam(daemon_dm_dspt);
			executeQuery();
		}
	}

	private void Mail(String daemon_dm_nm, String daemon_status, String daemon_dm_dspt) throws DBWorkerException, ResultObjectException {
		if (StringUtil.isEquals(daemon_status, "0")) {
			String mail_title = "[" + Const.DEFAULT_SITE_NAME + "] " + Const.DEFAULT_PRODUCT_NAME + "-" + daemon_dm_nm + " 데몬에러";
			String mail_contents = daemon_dm_nm + "<br /><br />" + daemon_dm_dspt;
			String send_emp_no = Const.DEFAULT_SYSTEM_CODE;
			String send_emp_nm = Const.DEFAULT_SYSTEM_NAME;
			String send_mail = Const.DEFAULT_EMAIL_SYSTEM;
			String recv_mail = "";

			/* ANSI SQL */
			setVersion("2015.05.27.01");
			setComment("이메일 정보");
			setQuery("SELECT");
			setQuery("	daemon_email");
			setQuery("FROM");
			setQuery("	jovt_system");
			ResultObject row = getRs();

			if (row.getRsCount() > 0) {
				recv_mail = row.getData("daemon_email", 0);
			}

			String[] arr = recv_mail.split(";");
			for (int i = 0; i < arr.length; i++) {
				if (!StringUtil.isEmpty(StringUtil.trim(arr[i]))) {
					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.05.27.01");
						setComment("이메일 발송");
						setQuery("INSERT INTO jovt_mail_list");
						setQuery("	(mail_title, mail_contents, send_emp_no, send_emp_nm, send_mail, recv_emp_no, recv_emp_nm, recv_mail, reg_dt, mail_type)");
						setQuery("VALUES");
						setQuery("	(?, ?, ?, ?, ?, '', '', ?, NOW(), 1)");
						setParam(mail_title);
						setParam(mail_contents);
						setParam(send_emp_no);
						setParam(send_emp_nm);
						setParam(send_mail);
						setParam(StringUtil.trim(arr[i]));
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.05.27.01");
						setComment("이메일 발송");
						setQuery("INSERT INTO jovt_mail_list");
						setQuery("	(mail_title, mail_contents, send_emp_no, send_emp_nm, send_mail, recv_emp_no, recv_emp_nm, recv_mail, reg_dt, mail_type)");
						setQuery("VALUES");
						setQuery("	(?, ?, ?, ?, ?, NULL, NULL, ?, SYSDATE, 1)");
						setParam(mail_title);
						setParam(mail_contents);
						setParam(send_emp_no);
						setParam(send_emp_nm);
						setParam(send_mail);
						setParam(StringUtil.trim(arr[i]));
						executeQuery();
					}
				}
			}
		}
	}
}