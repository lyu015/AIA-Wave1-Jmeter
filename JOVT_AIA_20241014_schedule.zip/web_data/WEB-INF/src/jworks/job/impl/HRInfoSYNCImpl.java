package jworks.job.impl;

import jworks.exception.DBWorkerException;
import jworks.exception.ResultObjectException;
import jworks.job.HRInfoSYNC;
import secured.utils.LogUtil;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <pre>
 * HRInfoSYNCImpl.java
 *
 * </pre>
 */
public class HRInfoSYNCImpl implements Job {

	private static Logger logger = LoggerFactory.getLogger(HRInfoSYNCImpl.class);

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		try { job(); } catch (Exception e) {}
	}

	private void job() throws DBWorkerException, ResultObjectException {
		logger.error("HRInfo Sync Start");
		HRInfoSYNC job = new HRInfoSYNC();

		job.job();
		logger.error("HRInfo Sync End");
	}
}