package jworks.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import jworks.biz.Const;
import jworks.biz.SecurityBiz;
import jworks.exception.DBWorkerException;
import jworks.util.LogUtil;
import jworks.util.StringUtil;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * <pre>
 * DBWorker.java
 *
 * </pre>
 */
public class DBWorker {
	protected String databaseName = Const.DEFAULT_DATABASE_NAME;
	protected Connection conn;

	protected StringBuffer query = new StringBuffer();
	protected ArrayList<Object> paramArr = new ArrayList<Object>();
	protected String version = "";
	protected String comment = "";

	protected String debugKey = "";
	protected String key = "";
	protected String iv = "";
	protected String log = "";

	/**
	 * <pre>
	 * Database Connection
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public Connection getConnection() throws DBWorkerException {
		try {
			try {
				Context initCtx = new InitialContext();
				DataSource ds = (DataSource) initCtx.lookup("java:comp/env/" + databaseName);

				return ds.getConnection();
			// WebSphere에서 Quartz 사용 시 필요
			} catch (Exception e) {
				Context initCtx = new InitialContext();
				DataSource ds = (DataSource) initCtx.lookup(databaseName);

				return ds.getConnection();
			}
		} catch (NamingException ne) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_CONN, ne);
		} catch (SQLException se) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_CONN, se);
		}
	}

	/**
	 * <pre>
	 * Database Connection
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public Connection getConnection(String databaseName) throws DBWorkerException {
		try {
			try {
				Context initCtx = new InitialContext();
				DataSource ds = (DataSource) initCtx.lookup("java:comp/env/" + databaseName);

				return ds.getConnection();
			// WebSphere에서 Quartz 사용 시 필요
			} catch (Exception e) {
				Context initCtx = new InitialContext();
				DataSource ds = (DataSource) initCtx.lookup(databaseName);

				return ds.getConnection();
			}
		} catch (NamingException ne) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_CONN, ne);
		} catch (SQLException se) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_CONN, se);
		}
	}

	/**
	 * <pre>
	 * Connection Open
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public void openConn() throws DBWorkerException {
		if (this.conn != null)
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_OPEN);
		this.conn = getConnection();
	}

	/**
	 * <pre>
	 * Connection Open
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public void openConn(String databaseName) throws DBWorkerException {
		if (this.conn != null)
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_OPEN);
		this.conn = getConnection(databaseName);
	}

	/**
	 * <pre>
	 * Connection Close
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public void closeConn() throws DBWorkerException {
		try {
			if (this.conn != null && this.conn.getAutoCommit()) {
				this.conn.close();
				this.conn = null;
			}
		} catch (SQLException se) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_CLOSE, se);
		}
	}

	/**
	 * <pre>
	 * BEGIN TRAN
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public void beginTran() throws DBWorkerException {
		try {
			if (this.conn != null)
				this.conn.setAutoCommit(false);
		} catch (SQLException se) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_TRAN, se);
		}
	}

	/**
	 * <pre>
	 * COMMIT TRAN
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public void commitTran() throws DBWorkerException {
		try {
			if (this.conn != null) {
				if (!this.conn.getAutoCommit()) {
					this.conn.commit();
					this.conn.setAutoCommit(true);
				}

				this.conn.close();
				this.conn = null;
			}
		} catch (SQLException se) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_TRAN, se);
		}
	}

	/**
	 * <pre>
	 * ROLLBACK TRAN
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public void rollbackTran() throws DBWorkerException {
		try {
			if (this.conn != null) {
				if (!this.conn.getAutoCommit()) {
					this.conn.rollback();
					this.conn.setAutoCommit(true);
				}

				this.conn.close();
				this.conn = null;
			}
		} catch (SQLException se) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_TRAN, se);
		}
	}

	/**
	 * <pre>
	 * SELECT
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public ResultObject getRs() throws DBWorkerException {
		PreparedStatement pstmt = null;
		Object param = null;
		ResultSet rs = null;
		ResultObject ro = null;
		ArrayList<Object> row = new ArrayList<Object>();

		if (this.conn == null)
			openConn();

		try {
			checkQuery(true);

			pstmt = this.conn.prepareStatement(this.query.toString());

			if (this.paramArr.size() > 0) {
				for (int i = 0; i < this.paramArr.size(); i++) {
					param = this.paramArr.get(i);

					if (param instanceof java.lang.String)
						pstmt.setString(i + 1, (String) param);
					else if (param instanceof java.lang.Integer)
						pstmt.setInt(i + 1, Integer.parseInt("" + param));
					else if (param instanceof java.lang.Long)
						pstmt.setLong(i + 1, Long.parseLong("" + param));
					else if (param instanceof java.lang.Float)
						pstmt.setFloat(i + 1, Float.parseFloat("" + param));
					else if (param instanceof java.lang.Double)
						pstmt.setDouble(i + 1, Double.parseDouble("" + param));
				}
			}

			long st = System.currentTimeMillis();
			rs = pstmt.executeQuery();
			long et = System.currentTimeMillis();

			LogUtil.info(debugKey + "쿼리 실행 속도: " + Long.toString((et - st)) + "ms");

			ResultSetMetaData md = rs.getMetaData();
			String label = "";
//			String type = "";
			String result = "";

			while (rs.next()) {
				Properties col = new Properties();

				for (int i = 1; i <= md.getColumnCount(); i++) {
					label = md.getColumnLabel(i);
//					type = md.getColumnTypeName(i);
					result = rs.getString(i);


					if (StringUtil.isEquals(label.toUpperCase(), "SEC")) {
						LogUtil.debug("SQL Type : " + Integer.toString(md.getColumnType(i)));

						LogUtil.debug("unmodified result : " + result);
					}


					if (md.getColumnType(i) == Types.DOUBLE
							&& result.lastIndexOf(".") > 0
							&& Integer.parseInt(result.substring(result.lastIndexOf(".") + 1, result.length())) == 0) {
						result = result.substring(0, result.lastIndexOf("."));

						LogUtil.debug("modified result : " + result);
					}

					if (!StringUtil.isEmpty(result)) {
						if (!(label.startsWith("_") && label.endsWith("_"))) {
							if (label.startsWith("_")) {
								result = SecurityBiz.getEncrypt(result, key, iv);
							} else if (label.endsWith("_")) {
								result = SecurityBiz.getEncrypt(result, SecurityBiz.getKey(), SecurityBiz.getIV());
							}
						}

						col.setProperty(label.toUpperCase(), result);
					} else {
						col.setProperty(label.toUpperCase(), "");
					}
				}

				row.add(col);
			}

			ro = new ResultObject(row);
		} catch (Exception e) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_QUERY, e);
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) {}
			try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}

			closeConn();
			initQuery();
		}

		return ro;
	}

	/**
	 * <pre>
	 * SELECT
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	@SuppressWarnings("unchecked")
	public JSONObject getRsJSON() throws DBWorkerException {
		PreparedStatement pstmt = null;
		Object param = null;
		ResultSet rs = null;
		JSONObject obj = new JSONObject();
		JSONArray arr = new JSONArray();

		if (this.conn == null)
			openConn();

		try {
			checkQuery(true);

			pstmt = this.conn.prepareStatement(this.query.toString());

			if (this.paramArr.size() > 0) {
				for (int i = 0; i < this.paramArr.size(); i++) {
					param = this.paramArr.get(i);

					if (param instanceof java.lang.String)
						pstmt.setString(i + 1, (String) param);
					else if (param instanceof java.lang.Integer)
						pstmt.setInt(i + 1, Integer.parseInt("" + param));
					else if (param instanceof java.lang.Long)
						pstmt.setLong(i + 1, Long.parseLong("" + param));
					else if (param instanceof java.lang.Float)
						pstmt.setFloat(i + 1, Float.parseFloat("" + param));
					else if (param instanceof java.lang.Double)
						pstmt.setDouble(i + 1, Double.parseDouble("" + param));
				}
			}

			long st = System.currentTimeMillis();
			rs = pstmt.executeQuery();
			long et = System.currentTimeMillis();

			LogUtil.info(debugKey + "쿼리 실행 속도: " + Long.toString((et - st)) + "ms");

			ResultSetMetaData md = rs.getMetaData();
			String label = "";
			//String type = "";
			String result = "";

			while (rs.next()) {
				JSONObject col = new JSONObject();

				for (int i = 1; i <= md.getColumnCount(); i++) {
					label = md.getColumnLabel(i);
					//type = md.getColumnTypeName(i);
					result = rs.getString(i);

					if (!StringUtil.isEmpty(result)) {
						if (!(label.startsWith("_") && label.endsWith("_"))) {
							if (label.startsWith("_")) {
								result = SecurityBiz.getEncrypt(result, key, iv);
							} else if (label.endsWith("_")) {
								result = SecurityBiz.getEncrypt(result, SecurityBiz.getKey(), SecurityBiz.getIV());
							}
						}

						col.put(label.toLowerCase(), result);
					} else {
						col.put(label.toLowerCase(), "");
					}
				}

				arr.add(col);
			}

			obj.put("success", "true");
			obj.put("data", arr);
		} catch (Exception e) {
			obj.put("success", "false");

			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_QUERY, e);
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) {}
			try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}

			closeConn();
			initQuery();

			LogUtil.info(debugKey + "########## JSON Trace ##########", obj + "\n");
		}

		return obj;
	}

	/**
	 * <pre>
	 * INSERT, UPDATE, DELETE
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public int executeQuery() throws DBWorkerException {
		PreparedStatement pstmt = null;
		Object param = null;
		int cnt = 0;

		if (this.conn == null)
			openConn();

		try {
			checkQuery(true);

			pstmt = this.conn.prepareStatement(this.query.toString());

			if (this.paramArr.size() > 0) {
				for (int i = 0; i < this.paramArr.size(); i++) {
					param = this.paramArr.get(i);

					if (param instanceof java.lang.String)
						pstmt.setString(i + 1, (String) param);
					else if (param instanceof java.lang.Integer)
						pstmt.setInt(i + 1, Integer.parseInt("" + param));
					else if (param instanceof java.lang.Long)
						pstmt.setLong(i + 1, Long.parseLong("" + param));
					else if (param instanceof java.lang.Float)
						pstmt.setFloat(i + 1, Float.parseFloat("" + param));
					else if (param instanceof java.lang.Double)
						pstmt.setDouble(i + 1, Double.parseDouble("" + param));
				}
			}

			long st = System.currentTimeMillis();
			cnt = pstmt.executeUpdate();
			long et = System.currentTimeMillis();

			if (cnt == 0)
				cnt = 1;

			LogUtil.info(debugKey + "쿼리 실행 속도: " + Long.toString((et - st)) + "ms");

			checkQuery(false);
		} catch (Exception e) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_QUERY, e);
		} finally {
			try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}

			closeConn();
			initQuery();
		}

		return cnt;
	}

	/**
	 * <pre>
	 * INSERT, UPDATE, DELETE
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	@SuppressWarnings("unchecked")
	public JSONObject executeQueryJSON() throws DBWorkerException {
		JSONObject obj = new JSONObject();

		try {
			int cnt = executeQuery();

			if (cnt > 0)
				obj.put("success", "true");
			else
				obj.put("success", "false");
		} catch (Exception e) {
			obj.put("success", "false");
		} finally {
			LogUtil.info(debugKey + "########## JSON Trace ##########", obj + "\n");
		}

		return obj;
	}

	/**
	 * <pre>
	 * INSERT
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	public String executeQueryRs(String column) throws DBWorkerException {
		PreparedStatement pstmt = null;
		Object param = null;
		int cnt = 0;
		ResultSet rs = null;
		String result = "";

		if (this.conn == null)
			openConn();

		try {
			checkQuery(true);

			pstmt = this.conn.prepareStatement(this.query.toString(), new String[] {"" + column + ""});

			if (this.paramArr.size() > 0) {
				for (int i = 0; i < this.paramArr.size(); i++) {
					param = this.paramArr.get(i);

					if (param instanceof java.lang.String)
						pstmt.setString(i + 1, (String) param);
					else if (param instanceof java.lang.Integer)
						pstmt.setInt(i + 1, Integer.parseInt("" + param));
					else if (param instanceof java.lang.Long)
						pstmt.setLong(i + 1, Long.parseLong("" + param));
					else if (param instanceof java.lang.Float)
						pstmt.setFloat(i + 1, Float.parseFloat("" + param));
					else if (param instanceof java.lang.Double)
						pstmt.setDouble(i + 1, Double.parseDouble("" + param));
				}
			}

			long st = System.currentTimeMillis();
			cnt = pstmt.executeUpdate();
			long et = System.currentTimeMillis();

			if (cnt > 0) {
				rs = pstmt.getGeneratedKeys();

				while (rs.next()) {
					result = rs.getString(1);
				}
			}

			LogUtil.info(debugKey + "쿼리 실행 속도: " + Long.toString((et - st)) + "ms");

			checkQuery(false);
		} catch (Exception e) {
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_QUERY, e);
		} finally {
			try { if (rs != null) rs.close(); } catch (Exception e) {}
			try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}

			closeConn();
			initQuery();
		}

		return result;
	}

	/**
	 * <pre>
	 * setVersion
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setVersion(String version) {
		if (!StringUtil.isEmpty(version))
			this.version = "/* " + version + " */";
	}

	/**
	 * <pre>
	 * setComment
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setComment(String comment) {
		if (!StringUtil.isEmpty(comment))
			this.comment = "/* " + comment + " */";
	}

	/**
	 * <pre>
	 * setQuery
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setQuery(String query) {
		this.query.append(query + "\n");
	}

	/**
	 * <pre>
	 * setQuery
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setQuery(String query, Object param) {
		setQuery(query);
		setParam(param);
	}

	/**
	 * <pre>
	 * setParam
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setParam(Object param) {
		if (param instanceof java.lang.String) {
			String s = "" + param;

			if (StringUtil.isEmpty(s))
				s = "";

			this.paramArr.add(s);
		} else {
			this.paramArr.add(param);
		}
	}

	/**
	 * <pre>
	 * setIfQuery
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setIfQuery(String query, Object param) {
		String s = "" + param;

		if (!StringUtil.isEmpty(s))
			setQuery(query, param);
	}

	/**
	 * <pre>
	 * setQueryInt
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setQueryInt(String query, Object param) {
		setQuery(query);
		setParamInt(param);
	}

	/**
	 * <pre>
	 * setParamInt
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setParamInt(Object param) {
		String s = "" + param;

		if (StringUtil.isEmpty(s))
			this.paramArr.add(null);
		else
			this.paramArr.add(Integer.parseInt(s));
	}

	/**
	 * <pre>
	 * setIfQueryInt
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setIfQueryInt(String query, Object param) {
		String s = "" + param;

		if (!StringUtil.isEmpty(s))
			setQueryInt(query, param);
	}

	/**
	 * <pre>
	 * setQueryLong
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setQueryLong(String query, Object param) {
		setQuery(query);
		setParamLong(param);
	}

	/**
	 * <pre>
	 * setParamLong
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setParamLong(Object param) {
		String s = "" + param;

		if (StringUtil.isEmpty(s))
			this.paramArr.add(null);
		else
			this.paramArr.add(Long.parseLong(s));
	}

	/**
	 * <pre>
	 * setIfQueryLong
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setIfQueryLong(String query, Object param) {
		String s = "" + param;

		if (!StringUtil.isEmpty(s))
			setQueryLong(query, param);
	}

	/**
	 * <pre>
	 * setQueryFloat
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setQueryFloat(String query, Object param) {
		setQuery(query);
		setParamFloat(param);
	}

	/**
	 * <pre>
	 * setParamFloat
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setParamFloat(Object param) {
		String s = "" + param;

		if (StringUtil.isEmpty(s))
			this.paramArr.add(null);
		else
			this.paramArr.add(Float.parseFloat(s));
	}

	/**
	 * <pre>
	 * setIfQueryFloat
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setIfQueryFloat(String query, Object param) {
		String s = "" + param;

		if (!StringUtil.isEmpty(s))
			setQueryFloat(query, param);
	}

	/**
	 * <pre>
	 * setQueryDouble
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setQueryDouble(String query, Object param) {
		setQuery(query);
		setParamDouble(param);
	}

	/**
	 * <pre>
	 * setParamDouble
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setParamDouble(Object param) {
		String s = "" + param;

		if (StringUtil.isEmpty(s))
			this.paramArr.add(null);
		else
			this.paramArr.add(Double.parseDouble(s));
	}

	/**
	 * <pre>
	 * setIfQueryDouble
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setIfQueryDouble(String query, Object param) {
		String s = "" + param;

		if (!StringUtil.isEmpty(s))
			setQueryDouble(query, param);
	}

	/**
	 * <pre>
	 * setQueryNumber
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setQueryNumber(String query, Object param) {
		setQuery(query);
		setParamNumber(param);
	}

	/**
	 * <pre>
	 * setParamNumber
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setParamNumber(Object param) {
		String s = "" + param;

		if (StringUtil.isEmpty(s)) {
			this.paramArr.add(null);
		} else {
			try {
				// -2147483648 ~ 2147483647
				this.paramArr.add(Integer.parseInt(s));
			} catch (NumberFormatException nfe_i) {
				try {
					// -9223372036854775808 ~ 9223372036854775807
					this.paramArr.add(Long.parseLong(s));
				} catch (NumberFormatException nfe_l) {
					try {
						// 1.4E-45 ~ 3.4028235E38
						this.paramArr.add(Float.parseFloat(s));
					} catch (NumberFormatException nfe_f) {
						// 4.9E-324 ~ 1.7976931348623157E308
						this.paramArr.add(Double.parseDouble(s));
					}
				}
			}
		}
	}

	/**
	 * <pre>
	 * setIfQueryNumber
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public void setIfQueryNumber(String query, Object param) {
		String s = "" + param;

		if (!StringUtil.isEmpty(s))
			setQueryNumber(query, param);
	}

	/**
	 * <pre>
	 * Query 체크
	 *
	 * @param
	 * @return
	 * @throws DBWorkerException
	 * </pre>
	 */
	protected void checkQuery(boolean flag) throws DBWorkerException {
		String log = "";

		log += this.query;

		if (this.paramArr.size() > 0) {
			for (int i = 0; i < this.paramArr.size(); i++) {
				if (this.paramArr.get(i) instanceof java.lang.String)
					log = log.substring(0, log.indexOf("?")) + "'" + this.paramArr.get(i) + "'" + log.substring(log.indexOf("?") + 1);
				else
					log = log.substring(0, log.indexOf("?")) + this.paramArr.get(i) + log.substring(log.indexOf("?") + 1);
			}
		}

		if (!StringUtil.isEmpty(this.comment))
			log = this.comment + "\n" + log;

		if (!StringUtil.isEmpty(this.version))
			log = this.version + "\n" + log;

		if (flag) {
			LogUtil.info(debugKey + "########## Query Trace ##########", log);
		} else {
			/* ########## 운영 로그 ########## */
			if (!StringUtil.isEmpty(this.log)) {
				PreparedStatement pstmt = null;

				try {
					log = StringUtil.replace(this.log + "", "\\{log\\}", StringUtil.replace(log, "'", "''"));

					pstmt = this.conn.prepareStatement(log);
					pstmt.executeUpdate();
				} catch (Exception e) {
					throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_QUERY, e);
				} finally {
					try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
				}
			}
			/* ########## 운영 로그 ########## */
		}

		if (this.paramArr.size() != StringUtil.getWordCount(this.query.toString(), "?"))
			throw new DBWorkerException(debugKey + Const.DEFAULT_MSG_ERROR_BIND);
	}

	/**
	 * <pre>
	 * Query 초기화
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	protected void initQuery() {
		this.version = "";
		this.comment = "";
		this.paramArr = new ArrayList<Object>();
		this.query.delete(0, this.query.length());
	}

	/**
	 * <pre>
	 * validationQuery
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public boolean validationQuery() throws DBWorkerException {
		try {
			if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
				/* POSTGRESQL */
				setQuery("SELECT 1");
				getRs();
			} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
				/* ORACLE */
				setQuery("SELECT 1 FROM DUAL");
				getRs();
			} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "mssql")) {
				/* MSSQL */
				setQuery("SELECT 1");
				getRs();
			}

			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * <pre>
	 * getLikeWord
	 *
	 * @param s[문자열]
	 * @return
	 * @throws
	 * </pre>
	 */
	public String getLikeWord(String s) {
		if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
			if (StringUtil.isEquals(s, "_") || StringUtil.isEquals(s, "%"))
				s = "[" + s;
		} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
			if (StringUtil.isEquals(s, "_") || StringUtil.isEquals(s, "%"))
				s = "[" + s;
		} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "mssql")) {
			if (StringUtil.isEquals(s, "_") || StringUtil.isEquals(s, "%") || StringUtil.isEquals(s, "["))
				s = "[" + s;
		}

		return s;
	}
}