package jworks.job;

import com.penta.scpdb.ScpDbAgent;
import com.penta.scpdb.ScpDbAgentException;
import jworks.util.LogUtil;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Ldap {

	public List<Map<String, Object>> ldapEmployeeSync() {
		try {
			String debugKey = "[Ldap]\n";
			LogUtil.info(debugKey + "########## ldap Start ##########");

			// properties 파일 매핑
			final String url = "/home/jovt_aia/web_data/WEB-INF/src/ldapConfig.properties";
			Properties properties = new Properties();
			properties.load(new FileInputStream(url));

			LogUtil.info(debugKey + "########## ldapConfig Success ##########");

			// Ldap 접속 계정 복호화 (Damo 라이브러리 사용)

			ScpDbAgent agt = new ScpDbAgent();
			LogUtil.info(debugKey + "########## Damo init Object ##########");
			String iniFilePath = properties.getProperty("ini.file.path");
			LogUtil.info(debugKey + "########## Damo properties ##########");
			LogUtil.info(iniFilePath);
			String ldapId= "";
			String ldapPwd= "";
			if(properties.getProperty("ldap.id") != null){
				ldapId = agt.ScpDecB64( iniFilePath, "SCPKIDPW", properties.getProperty("ldap.id"), "UTF-8");
				LogUtil.info(debugKey + "########## Damo init ID ##########");
			} else {
				LogUtil.info(debugKey + "########## Damo init ID fail ##########");
			}
			if(properties.getProperty("ldap.pwd") != null){
				ldapPwd = agt.ScpDecB64( iniFilePath, "SCPKIDPW", properties.getProperty("ldap.pwd"), "UTF-8");
				LogUtil.info(debugKey + "########## Damo init PW ##########");
			} else {
				LogUtil.info(debugKey + "########## Damo init PW fail ##########");
			}

			LogUtil.info(debugKey + "########## LdapId, LdapPwd: " + ldapId + ", " + ldapPwd + " ##########");
			LogUtil.info(debugKey + "########## Decryption Success ##########");

			// Ldap 연결
			Hashtable<Object, Object> env = new Hashtable<Object, Object>();
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, "ldaps://krcspwdom01.aia.biz");
			env.put(Context.SECURITY_AUTHENTICATION, "simple");
			env.put(Context.SECURITY_PRINCIPAL, ldapId);
			env.put(Context.SECURITY_CREDENTIALS, ldapPwd);

			DirContext ctx = new InitialDirContext(env); // connection

			String searchFilter = "employeeType=*employee*"; // Ldap 검색 조건
			String returnedAtts[] = {
					"cn",
					"EmployeeID",
					"displayName",
					"extensionAttribute6"}; // 검색 조건에 해당하는 데이터의 출력하고 싶은 속성 목록

			SearchControls searchCtls = new SearchControls();
			searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			searchCtls.setReturningAttributes(returnedAtts);

			// Ldap 디렉토리 계층에서 검색할 범위 설정 (AIA.BIZ > AIA > korea 하위 폴더 내)
			NamingEnumeration<SearchResult> users = ctx.search("ou=korea,ou=AIA,dc=AIA,dc=BIZ", searchFilter, searchCtls);

			List<Map<String, Object>> employeeList = new ArrayList<>(); // 결과 값 저장
			int count = 0; // 데이터 갯수

			while (users.hasMore()) {

				SearchResult result = users.next();
				Attributes attr = result.getAttributes();
				Map<String, Object> employeeInfo = new HashMap<>();

				if(attr.get("EmployeeID") == null){
					employeeInfo.put("empNo", attr.get("extensionAttribute6").get()); // 사번
				} else {
					employeeInfo.put("empNo", attr.get("EmployeeID").get()); // 사번
				}
				employeeInfo.put("empNm", attr.get("displayName").get()); // 이름

				if(attr.get("cn") != null){
					employeeInfo.put("empAccount", attr.get("cn").get()); // 계정
				}

				employeeList.add(employeeInfo);

				count++;
			}

			ctx.close();
			LogUtil.info("===== Ldap Data Count : " + count);
			return employeeList;
		} catch (ScpDbAgentException e) {
			LogUtil.info("[Damo Error]\n" + e.toString());
		} catch (Exception e) {
			String debugKey = "[Ldap Error]\n";
			e.printStackTrace();
			LogUtil.info(debugKey + e);
		}
		return null;
	}
}


