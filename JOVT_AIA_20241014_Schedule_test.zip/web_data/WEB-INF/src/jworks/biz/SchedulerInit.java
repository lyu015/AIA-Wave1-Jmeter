package jworks.biz;

import java.text.ParseException;

import javax.servlet.http.HttpServlet;

import jworks.util.LogUtil;
import jworks.util.StringUtil;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

/**
 * <pre>
 * SchedulerInit.java
 *
 * </pre>
 */
public class SchedulerInit extends HttpServlet {
	private static final long serialVersionUID = -8650464174721933363L;

	public static void main(String[] args) {
		new SchedulerInit();
	}

	public SchedulerInit() {
		try {
			SchedulerFactory schedFact = new StdSchedulerFactory();
			Scheduler sched = schedFact.getScheduler();
			sched.start();

			/*
				포맷: "초 분 시 일 월 요일 년도(옵션)"
					- 초: 0-59
					- 분: 0-59
					- 시: 0-23
					- 일: 1-31
					- 월: 1-12/JAN-DEC
					- 요일: 1-7/SUN-SAT
					- 년도: 1970-2099
				예제
					- 매분 0초: "0 * * * * ?"
					- 매분 30초: "30 * * * * ?"
					- 매시 0분 30초: "30 0 * * * ?"
					- 매시 0,30분 30초: "30 0,30 * * * ?"
					- 매시 0,10,20,30,40,50분: "0 0,10,20,30,40,50 * * * ?"
					- 매일 오전 3시 2분 1초: "1 2 3 * * ?"
					- 매일 오전 6시 4분 2초: "2 4 6 * * ?"
					- 매주 일요일 오전 9시: "0 0 9 ? * SUN"
					- 매월 1일 오전 9시: "0 0 9 1 * ?"
					- 매월 마지막 날 오전 9시: "0 0 9 L * ?"
					- 매년 12월 31일 오전 0시: "0 0 0 31 12 ?"
			*/

			if (StringUtil.isEquals(Const.DEFAULT_SYSTEM_MODE, "REAL")) {
				// 로그 삭제 (매일 오전 4시)
				JobDetail DeleteLog_Job = new JobDetail("DeleteLog_Job", "moffice", jworks.job.impl.DeleteLogImpl.class);
				CronTrigger DeleteLog_Trigger = new CronTrigger("DeleteLog_Trigger", "moffice", "0 0 4 * * ?");
				sched.scheduleJob(DeleteLog_Job, DeleteLog_Trigger);

				// 인사정보 동기화 (매일 오전 4시 30분)
				JobDetail HRInfoSYNC_Job = new JobDetail("HRInfoSYNC_Job", "moffice", jworks.job.impl.HRInfoSYNCImpl.class);
//				CronTrigger HRInfoSYNC_Trigger = new CronTrigger("HRInfoSYNC_Trigger", "moffice", "0 30 5 * * ?");
				CronTrigger HRInfoSYNC_Trigger = new CronTrigger("HRInfoSYNC_Trigger", "moffice", "0 */5 * * * ?");
				sched.scheduleJob(HRInfoSYNC_Job, HRInfoSYNC_Trigger);
				// PC 사용기록 계산 (매일 오전 6시 1분 1초)
				// 필독!!! 하루 기준시 보다 커야함
				JobDetail PCLogCalc_Job = new JobDetail("PCLogCalc_Job", "moffice", jworks.job.impl.PCLogCalcImpl.class);
//				CronTrigger PCLogCalc_Trigger = new CronTrigger("PCLogCalc_Trigger", "moffice", "1 1 6 * * ?");
				CronTrigger PCLogCalc_Trigger = new CronTrigger("PCLogCalc_Trigger", "moffice", "1 */7 * * * ?");

				sched.scheduleJob(PCLogCalc_Job, PCLogCalc_Trigger);

				// OT사용기록 계산 (매일 오전 6시 20분)
				JobDetail OTLogCalc_Job = new JobDetail("OTLogCalc_Job", "moffice", jworks.job.impl.OTLogCalcImpl.class);
//				CronTrigger OTLogCalc_Trigger = new CronTrigger("OTLogCalc_Trigger", "moffice", "0 20 6 * * ?");
				CronTrigger OTLogCalc_Trigger = new CronTrigger("OTLogCalc_Trigger", "moffice", "0 */8 * * * ?");
				sched.scheduleJob(OTLogCalc_Job, OTLogCalc_Trigger);

				// 통계처리 (매일 오전 6시 30분)
				JobDetail Statistics_Job = new JobDetail("Statistics_Job", "moffice", jworks.job.impl.StatisticsImpl.class);
				CronTrigger Statistics_Trigger = new CronTrigger("Statistics_Trigger", "moffice", "0 30 6 * * ?");
				sched.scheduleJob(Statistics_Job, Statistics_Trigger);

				// 잡 에이전트 (매분 0초)
				JobDetail JobAgent_Job = new JobDetail("JobAgent_Job", "moffice", jworks.job.impl.JobAgentImpl.class);
				CronTrigger JobAgent_Trigger = new CronTrigger("JobAgent_Trigger", "moffice", "0 * * * * ?");
				sched.scheduleJob(JobAgent_Job, JobAgent_Trigger);

				// 유연근무 정보 동기화 (매 10분)
//				JobDetail WorkInfoSYNC_Job = new JobDetail("WorkInfoSYNC_Job", "moffice", jworks.job.impl.WorkInfoSYNCImpl.class);
//				CronTrigger WorkInfoSYNC_Trigger = new CronTrigger("WorkInfoSYNC_Trigger", "moffice", "10 0/10 * * * ?");
//				sched.scheduleJob(WorkInfoSYNC_Job, WorkInfoSYNC_Trigger);

				// 휴가자 정보 동기화 (매 10분)
//				JobDetail VacationSYNC_Job = new JobDetail("VacationSYNC_Job", "moffice", jworks.job.impl.VacationSYNCImpl.class);
//				CronTrigger VacationSYNC_Trigger = new CronTrigger("VacationSYNC_Trigger", "moffice", "20 0/5 * * * ?");
//				sched.scheduleJob(VacationSYNC_Job, VacationSYNC_Trigger);

				// 서버 모니터링 (매분 0초,30초)
				//JobDetail SvrMonitor_Job = new JobDetail("SvrMonitor_Job", "moffice", jworks.job.impl.SvrMonitorImpl.class);
				//CronTrigger SvrMonitor_Trigger = new CronTrigger("SvrMonitor_Trigger", "moffice", "0,30 * * * * ?");
				//sched.scheduleJob(SvrMonitor_Job, SvrMonitor_Trigger);
			}
		} catch (SchedulerException se) {
			LogUtil.error(Const.DEFAULT_MSG_ERROR_COMMON, se.getMessage(), se.getStackTrace());
		} catch (ParseException pe) {
			LogUtil.error(Const.DEFAULT_MSG_ERROR_COMMON, pe.getMessage(), pe.getStackTrace());
		}
	}
}