package jworks.core;

import java.util.ArrayList;
import java.util.Properties;

import jworks.biz.Const;
import jworks.exception.ResultObjectException;
import jworks.util.StringUtil;

/**
 * <pre>
 * ResultObject.java
 *
 * </pre>
 */
public class ResultObject {
	public ArrayList<Object> al = null;

	public int totalCount = 0;
	public int nowPage = 1;
	public int listSize = Const.DEFAULT_PAGING_LIST_SIZE;
	public int blockSize = Const.DEFAULT_PAGING_BLOCK_SIZE;
	public int totalPage = 0;

	/**
	 * <pre>
	 * 기본 생성자
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public ResultObject(ArrayList<Object> al) {
		this.al = al;
	}

	/**
	 * <pre>
	 * Result Count
	 *
	 * @param
	 * @return
	 * @throws
	 * </pre>
	 */
	public int getRsCount() {
		return al.size();
	}

	/**
	 * <pre>
	 * getData
	 *
	 * @param
	 * @return
	 * @throws ResultObjectException
	 * </pre>
	 */
	public String getData(String n, int i) throws ResultObjectException {
		if (i >= al.size())
			throw new ResultObjectException("[" + i + "]" + Const.DEFAULT_MSG_ERROR_RECORD);

		Properties col = (Properties) al.get(i);

		if (col.getProperty(n.toUpperCase()) == null)
			throw new ResultObjectException("[" + n + "]" + Const.DEFAULT_MSG_ERROR_COLUMN);

		return col.getProperty(n.toUpperCase());
	}

	/**
	 * <pre>
	 * getValue
	 *
	 * @param
	 * @return
	 * @throws ResultObjectException
	 * </pre>
	 */
	public String getValue(String n, int i) throws ResultObjectException {
		String s = getData(n, i);

		return StringUtil.convertASCII(s);
	}

	/**
	 * <pre>
	 * getView
	 *
	 * @param
	 * @return
	 * @throws ResultObjectException
	 * </pre>
	 */
	public String getView(String n, int i) throws ResultObjectException {
		String s = getData(n, i);

		return s.replaceAll(" ", "&nbsp;").replaceAll("\n", "<br />");
	}

	/**
	 * <pre>
	 * getInt
	 *
	 * @param
	 * @return
	 * @throws ResultObjectException
	 * </pre>
	 */
	public int getInt(String n, int i) throws ResultObjectException {
		String s = getData(n, i);

		// 실수형 전달시 소수점 제거
		if (!StringUtil.isEmpty(n) && n.contains(".")) {
			n.substring(0, n.lastIndexOf("."));
		}

		return Integer.parseInt(s);
	}

	/**
	 * <pre>
	 * getLong
	 *
	 * @param
	 * @return
	 * @throws ResultObjectException
	 * </pre>
	 */
	public long getLong(String n, int i) throws ResultObjectException {
		String s = getData(n, i);

		// 실수형 전달시 소수점 제거
		if (!StringUtil.isEmpty(n) && n.contains(".")) {
			n.substring(0, n.lastIndexOf("."));
		}


		return Long.parseLong(s);
	}

	/**
	 * <pre>
	 * getFloat
	 *
	 * @param
	 * @return
	 * @throws ResultObjectException
	 * </pre>
	 */
	public float getFloat(String n, int i) throws ResultObjectException {
		String s = getData(n, i);

		return Float.parseFloat(s);
	}

	/**
	 * <pre>
	 * getDouble
	 *
	 * @param
	 * @return
	 * @throws ResultObjectException
	 * </pre>
	 */
	public double getDouble(String n, int i) throws ResultObjectException {
		String s = getData(n, i);

		return Double.parseDouble(s);
	}
}