package jworks.job;

import jworks.biz.Const;
import jworks.core.DBWorker;
import jworks.core.ResultObject;
import jworks.exception.DBWorkerException;
import jworks.exception.ResultObjectException;
import jworks.util.DateUtil;
import jworks.util.LogUtil;
import jworks.util.StringUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * HRInfoSYNC.java
 *
 * </pre>
 */
public class HRInfoSYNC extends DBWorker {
	public void job() throws DBWorkerException, ResultObjectException {
		String opt = "dpt,pos,tit,jik,emp";

		job(opt);
	}

	public void job(String opt) throws DBWorkerException, ResultObjectException {
		this.debugKey = "[JOB]\n";

		// #########################
		// 실행 여부 옵션
		// #########################
		/*
			opt_dpt: 부서 동기화
			opt_pos: 직급 동기화
			opt_tit: 직위 동기화
			opt_jik: 직책 동기화
			opt_emp: 사원 동기화`
		*/
		String opt_dpt = "";
		String opt_pos = "";
		String opt_tit = "";
		String opt_jik = "";
		String opt_emp = "";

		String[] arr = opt.split(",");
		for (int i = 0; i < arr.length; i++) {
			if (StringUtil.isEquals(arr[i], "dpt"))
				opt_dpt = "Y";
			if (StringUtil.isEquals(arr[i], "pos"))
				opt_pos = "Y";
			if (StringUtil.isEquals(arr[i], "tit"))
				opt_tit = "Y";
			if (StringUtil.isEquals(arr[i], "jik"))
				opt_jik = "Y";
			if (StringUtil.isEquals(arr[i], "emp"))
				opt_emp = "Y";
		}

		// #########################
		// 파라미터 설정
		// #########################
		/*
			daemon_st_tm: 시작시
			daemon_ed_tm: 종료시
			daemon_dm_nm: 데몬 클래스명
			daemon_status: 성공(1)/실패(0)
			daemon_dm_dspt: 상세 정보
		*/
		String daemon_st_tm = "";
		String daemon_ed_tm = "";
		String daemon_dm_nm = "HRInfoSYNC";
		String daemon_status = "1";
		String daemon_dm_dspt = "";

		// #########################
		// 데이터 처리
		// #########################
		ResultObject row = null;

		String log = "";
		StringBuffer sb = new StringBuffer();

		// ########## 부서정보 동기화 ##########
		if (StringUtil.isEquals(opt_dpt, "Y")) {
			daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			try {
				/*
					dpt_cd: 부서 코드
					dpt_nm: 부서 이름
					up_dpt_cd: 상위부서 코드
					dpt_ord: 정렬순서 (동일 계층 내)
					status: 사용여부 (0/1)
				*/
				/**
				 * Ldap 커스터 마이징 (23.06.12)
				 * 기본 부서 고정 설정
				 * - 장동욱
				 */
				String dpt_cd = "1";
				String dpt_nm = "AIA";
				String up_dpt_cd = "0";
				String dpt_ord = "1";
				String status = "1";
				String reg_empno = Const.DEFAULT_SYSTEM_CODE;
				String cancel_empno = Const.DEFAULT_SYSTEM_CODE;

				/*
					cds: 동기화 코드
					cds_aprv: 결재자 동기화 코드
				*/
				String cds = "";

//				openConn();
//
//
//				setVersion("2022.04.07.01");
//				setComment("부서정보");
//				setQuery("SELECT");
//				setQuery("	DEPT_ID, DEPT_NAME, UP_DEPT_ID , NVL(DEPT_ORDER,'A') as DEPT_ORDER, STATUS");
//				setQuery("FROM");
//				setQuery("	TBL_DEPT");
//				row = getRs();
//
//				closeConn();

//				for (int i = 0; i < row.getRsCount(); i++) {
//					dpt_cd = StringUtil.trim(row.getData("DEPT_ID", i));
//					dpt_nm = StringUtil.trim(row.getData("DEPT_NAME", i));
//					up_dpt_cd = StringUtil.trim(row.getData("UP_DEPT_ID", i));
//					dpt_ord = StringUtil.trim(row.getData("DEPT_ORDER", i));
//					status = StringUtil.trim(row.getData("STATUS", i));

					setVersion("2022.04.25.01");
					setComment("부서정보 동기화");
					// 고객사 DBMS 변경으로 주석 처리
					// oracle
//					setQuery("MERGE INTO jovt_department USING DUAL ON(dpt_cd = ?)", dpt_cd);
//					setQuery("	WHEN MATCHED THEN");
//					setQuery("		UPDATE SET ");
//					setQuery("		  	  dpt_nm = ?", dpt_nm);
//					setQuery("		    , up_dpt_cd = ?", up_dpt_cd);
//					setQuery("		    , dpt_lvl = 100");
//					setQuery("			, dpt_ord = ?", dpt_ord);
//					setQueryInt("		, status = ?", status);
//					setQuery("	WHEN NOT MATCHED THEN");
//					setQuery("		INSERT (dpt_cd, dpt_nm, up_dpt_cd, dpt_lvl ,dpt_ord, status)");
//					setQuery("      VALUES(?, ?, ?,100 ,?, ?)");
//					setParam(dpt_cd);
//					setParam(dpt_nm);
//					setParam(up_dpt_cd);
//					setParam(dpt_ord);
//					setParamInt(status);
					// postgresql
					setQuery("insert into jovt_department");
					setQuery("	(");
					setQuery("		dpt_cd");
					setQuery("		, dpt_nm");
					setQuery("		, up_dpt_cd");
					setQuery("		, dpt_lvl");
					setQuery("		, dpt_ord");
					setQuery("		, status)");
					setQuery("values(?, ?, ?, 100, ?, ?)");
					setParam(dpt_cd);
					setParam(dpt_nm);
					setParam(up_dpt_cd);
					setParamInt(dpt_ord);
					setParamInt(status);
					setQuery("on conflict (dpt_cd) do");
					setQuery("update set");
					setQuery("	dpt_nm = ?", dpt_nm);
					setQuery("	, up_dpt_cd = ?", up_dpt_cd);
					setQuery("	, dpt_lvl = 100");
					setQueryInt("	, dpt_ord = ?", dpt_ord);
					setQueryInt("	, status = ?", status);
					executeQuery();

					// ########## 알괄취소 제외 요청으로 인한 일괄취소 처리 스킵 ##########

					if (StringUtil.isEmpty(cds)) {
						cds += "(1,'" + dpt_cd + "')";
					} else {
						cds += ",(1,'" + dpt_cd + "')";
					}


					//System.out.println(" ★★★★★★★★★★★★★★★ cds : " +cds);

					/*
					if (!StringUtil.isEmpty(aprv_empno)) {
						setVersion("2018.07.09.01");
						setComment("결재자 동기화");
						setQuery("MERGE INTO jovt_add_approver");
						setQuery("	USING DUAL");
						setQuery("	ON(dpt_cd = ? ", dpt_cd);
						setQuery("		AND aprv_empno = ?)", aprv_empno);
						setQuery("	WHEN MATCHED THEN");
						setQuery("		UPDATE SET");
						setQuery("			status = 1 ");
						setQuery("			, reg_dt = SYSDATE");
						setQuery("			, reg_empno = ? ", Const.DEFAULT_SYSTEM_CODE);
						setQuery("			, cancel_dt = NULL");
						setQuery("			, cancel_empno = NULL");
						setQuery("			, auth = 1");
						setQuery("	WHEN NOT MATCHED THEN");
						setQuery("		INSERT (dpt_cd, aprv_empno, reg_dt, reg_empno, status, auth)");
						setQuery("			VALUES(?, ?, SYSDATE, ?, 1, 1)");
						setParam(dpt_cd);
						setParam(aprv_empno);
						setParam(Const.DEFAULT_SYSTEM_CODE);
						executeQuery();

						if (StringUtil.isEmpty(cds_aprv)) {
							cds_aprv += "'" + aprv_empno + "'";
						} else {
							cds_aprv += ",'" + aprv_empno + "'";
						}
					}
					*/
					int i = 0;
					// ########## 처리결과 ##########
					sb.append("\t" + (i+1) + ".dpt_cd=" + dpt_cd + "\n");
					sb.append("\t" + (i+1) + ".dpt_nm=" + dpt_nm + "\n");
					sb.append("\t" + (i+1) + ".up_dpt_cd=" + up_dpt_cd + "\n");
					sb.append("\t" + (i+1) + ".dpt_ord=" + dpt_ord + "\n");
					sb.append("\t" + (i+1) + ".status=" + status + "\n");
//				}
				if (!StringUtil.isEmpty(cds)) {
					setVersion("2022.04.07.01");
					setComment("부서정보 미사용");
					setQuery("UPDATE jovt_department SET");
					setQuery("	status = 0");
					setQuery("WHERE");
					setQuery("	status = 1");
					if (!StringUtil.isEmpty(cds)) {
						setQuery("	AND (1, dpt_cd) NOT IN (" + cds + ")");
					}
					executeQuery();
				}


				/*
				if (!StringUtil.isEmpty(cds_aprv)) {
					setVersion("2018.07.09.01");
					setComment("결재자 삭제");
					setQuery("UPDATE jovt_add_approver SET");
					setQuery("	status = 0");
					setQuery("	, cancel_empno = ?", cancel_empno);
					setQuery("	, cancel_dt = SYSDATE");
					setQuery("WHERE");
					setQuery("	status = 1 AND auth = 1");
					setQuery("	AND (reg_empno = ? AND cancel_empno IS NULL)", reg_empno);
					setQuery("	AND aprv_empno NOT IN (" + cds_aprv + ")");
					executeQuery();
				}
				 * */

				daemon_status = "1";
				daemon_dm_dspt = "성공 (부서정보 동기화 완료)";
			} catch (Exception e) {
				daemon_status = "0";
				daemon_dm_dspt = "실패 (부서정보 동기화 예외 : " + e.getMessage() + ")";
			}

			daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			// ########## 로그 정보 ##########
			log += "부서정보 동기화 데몬로그\n";
			log += "\t" + "st_tm=" + daemon_st_tm + "\n";
			log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
			log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
			log += "\t" + "status=" + daemon_status + "\n";
			log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
			log += "부서정보 동기화 처리결과\n";
			log += sb.toString();

			LogUtil.info(debugKey + "########## Job Trace ##########", log);

			Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
			if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
				Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

			log = "";
			sb = new StringBuffer();
		}

		// ########## 직급정보 동기화 ##########
		if (StringUtil.isEquals(opt_pos, "Y")) {
			daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			try {
				/*
					pos_cd: 직급 코드
					pos_nm: 직급 이름
					status: 사용여부 (0/1)
				*/
				/**
				 * Ldap 커스터 마이징 (23.06.12)
				 * 기본 직급 고정 설정
				 * - 장동욱
				 */
				String pos_cd = "1";
				String pos_nm = "기본직급";
				String status = "1";

				/*
					cds: 동기화 코드
				*/
				String cds = "";

//				openConn();
//
//				setVersion("2022.04.07.01");
//				setComment("직급정보");
//				setQuery("SELECT");
//				setQuery("	POS_CD, POS_NAME, STATUS");
//				setQuery("FROM");
//				setQuery("	TBL_Job_Position");
//				row = getRs();
//
//				closeConn();

//				for (int i = 0; i < row.getRsCount(); i++) {
//					pos_cd = StringUtil.trim(row.getData("POS_CD", i));
//					pos_nm = StringUtil.trim(row.getData("POS_NAME", i));
//					status = StringUtil.trim(row.getData("STATUS", i));

					setVersion("2022.04.25.01");
					setComment("직급정보 동기화");
					// DBMS 변경으로 인한 주석
					// oracle
//					setQuery("MERGE INTO jovt_position USING DUAL ON(pos_cd = ?)", pos_cd);
//					setQuery("	WHEN MATCHED THEN");
//					setQuery("		UPDATE SET ");
//					setQuery("		  	  pos_nm = ?", pos_nm);
//					setQuery("		  	 , pos_ord = 100");
//					setQueryInt("		, status = ?", status);
//					setQuery("	WHEN NOT MATCHED THEN");
//					setQuery("		INSERT (pos_cd, pos_nm, pos_ord, status)");
//					setQuery("      VALUES(?, ?,100 ,?)");
//					setParam(pos_cd);
//					setParam(pos_nm);
//					setParamInt(status);
					//postgresql
					setQuery("insert into jovt_position");
					setQuery("	(");
					setQuery("		pos_cd");
					setQuery("		, pos_nm");
					setQuery("		, pos_ord");
					setQuery("		, status");
					setQuery("	)");
					setQuery("values");
					setQuery("	(");
					setQuery("		?", pos_cd);
					setQuery("		, ?", pos_nm);
					setQuery("		, 100");
					setQueryInt("		, ?", status);
					setQuery("	)");
					setQuery("on conflict (pos_cd) do");
					setQuery("update set");
					setQuery("	pos_nm = ?", pos_nm);
					setQuery("	, pos_ord = 100");
					setQueryInt("	, status = ?", status);
					executeQuery();

					// ########## 알괄취소 제외 요청으로 인한 일괄취소 처리 스킵 ##########

					if (StringUtil.isEmpty(cds)) {
						cds += "'" + pos_cd + "'";
					} else {
						cds += ",'" + pos_cd + "'";
					}

					// ########## 처리결과 ##########
					int i = 0;
					sb.append("\t" + (i+1) + ".pos_cd=" + pos_cd + "\n");
					sb.append("\t" + (i+1) + ".pos_nm=" + pos_nm + "\n");
					sb.append("\t" + (i+1) + ".status=" + status + "\n");
//				}


				if (!StringUtil.isEmpty(cds)) {
					setVersion("2022.04.07.01");
					setComment("직급정보 미사용");
					setQuery("UPDATE jovt_position SET");
					setQuery("	status = 0");
					setQuery("WHERE");
					setQuery("	status = 1");
					setQuery("	AND pos_cd NOT IN (" + cds + ")");
					executeQuery();
				}

				daemon_status = "1";
				daemon_dm_dspt = "성공 (" + Const.DEFAULT_TITLE_POS + "정보 동기화 완료)";
			} catch (Exception e) {
				daemon_status = "0";
				daemon_dm_dspt = "실패 (" + Const.DEFAULT_TITLE_POS + "정보 동기화 예외 : " + e.getMessage() + ")";
			}

			daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			// ########## 로그 정보 ##########
			log += Const.DEFAULT_TITLE_POS + "정보 동기화 데몬로그\n";
			log += "\t" + "st_tm=" + daemon_st_tm + "\n";
			log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
			log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
			log += "\t" + "status=" + daemon_status + "\n";
			log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
			log += Const.DEFAULT_TITLE_POS + "정보 동기화 처리결과\n";
			log += sb.toString();

			LogUtil.info(debugKey + "########## Job Trace ##########", log);

			Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
			if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
				Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

			log = "";
			sb = new StringBuffer();
		}

		// ########## 직위정보 동기화 ##########
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_TIT, "Y")) {
			if (StringUtil.isEquals(opt_tit, "Y")) {
				daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

				try {
					/*
						tit_cd: 직위 코드
						tit_nm: 직위 이름
						status: 사용여부 (0/1)
					*/
					/**
					 * Ldap 커스터 마이징 (23.06.12)
					 * 기본 직위 고정 설정
					 * - 장동욱
					 */
					String tit_cd = "1";
					String tit_nm = "기본직위";
					String status = "1";

					/*
						cds: 동기화 코드
					*/
					String cds = "";

//					openConn();
//
//					setVersion("2022.04.07.01");
//					setComment("직위정보");
//					setQuery("SELECT");
//					setQuery("	TIT_CD, TIT_NAME, STATUS");
//					setQuery("FROM");
//					setQuery("	TBL_Title");
//					row = getRs();
//
//					closeConn();

//					for (int i = 0; i < row.getRsCount(); i++) {
//						tit_cd = StringUtil.trim(row.getData("TIT_CD", i));
//						tit_nm = StringUtil.trim(row.getData("TIT_NAME", i));
//						status = StringUtil.trim(row.getData("STATUS", i));

						setVersion("2022.04.25.01");
						setComment("직위정보 동기화");
						// DBMS 변경으로 인한 주석
						// oracle
//						setQuery("MERGE INTO jovt_title USING DUAL ON(tit_cd = ?)", tit_cd);
//						setQuery("	WHEN MATCHED THEN");
//						setQuery("		UPDATE SET ");
//						setQuery("		  	  tit_nm = ?", tit_nm);
//						setQuery("			, tit_ord = 100");
//						setQueryInt("		, status = ?", status);
//						setQuery("	WHEN NOT MATCHED THEN");
//						setQuery("		INSERT (tit_cd, tit_nm, tit_ord ,status)");
//						setQuery("      VALUES(?, ?,100, ?)");
//						setParam(tit_cd);
//						setParam(tit_nm);
//						setParamInt(status);
						// postgresql
						setQuery("insert into jovt_title");
						setQuery("	(");
						setQuery("		tit_cd");
						setQuery("		, tit_nm");
						setQuery("		, tit_ord");
						setQuery("		, status");
						setQuery("	)");
						setQuery("values");
						setQuery("	(");
						setQuery("		?", tit_cd);
						setQuery("		, ?", tit_nm);
						setQuery("		, 100");
						setQueryInt("		, ?", status);
						setQuery("	)");
						setQuery("on conflict (tit_cd) do");
						setQuery("update set");
						setQuery("	tit_nm = ?", tit_nm);
						setQuery("	, tit_ord = 100");
						setQueryInt("	, status = ?", status);
						executeQuery();

						// ########## 알괄취소 제외 요청으로 인한 일괄취소 처리 스킵 ##########

						if (StringUtil.isEmpty(cds)) {
							cds += "'" + tit_cd + "'";
						} else {
							cds += ",'" + tit_cd + "'";
						}

						// ########## 처리결과 ##########
						int i = 0;
						sb.append("\t" + (i+1) + ".tit_cd=" + tit_cd + "\n");
						sb.append("\t" + (i+1) + ".tit_nm=" + tit_nm + "\n");
						sb.append("\t" + (i+1) + ".status=" + status + "\n");
//					}


					if (!StringUtil.isEmpty(cds)) {
						setVersion("2022.04.07.01");
						setComment("직위정보 미사용");
						setQuery("UPDATE jovt_title SET");
						setQuery("	status = 0");
						setQuery("WHERE");
						setQuery("	status = 1");
						setQuery("	AND tit_cd NOT IN (" + cds + ")");
						executeQuery();
					}

					daemon_status = "1";
					daemon_dm_dspt = "성공 (" + Const.DEFAULT_TITLE_TIT + "정보 동기화 완료)";
				} catch (Exception e) {
					daemon_status = "0";
					daemon_dm_dspt = "실패 (" + Const.DEFAULT_TITLE_TIT + "정보 동기화 예외 : " + e.getMessage() + ")";
				}

				daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

				// ########## 로그 정보 ##########
				log += Const.DEFAULT_TITLE_TIT + "정보 동기화 데몬로그\n";
				log += "\t" + "st_tm=" + daemon_st_tm + "\n";
				log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
				log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
				log += "\t" + "status=" + daemon_status + "\n";
				log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
				log += Const.DEFAULT_TITLE_TIT + "정보 동기화 처리결과\n";
				log += sb.toString();

				LogUtil.info(debugKey + "########## Job Trace ##########", log);

				Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
				if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
					Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

				log = "";
				sb = new StringBuffer();
			}
		}

		// ########## 직책정보 동기화 ##########
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_JIK, "Y")) {
			if (StringUtil.isEquals(opt_jik, "Y")) {
				daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

				try {
					daemon_status = "1";
					daemon_dm_dspt = "성공 (" + Const.DEFAULT_TITLE_JIK + "정보 동기화 완료)";
				} catch (Exception e) {
					daemon_status = "0";
					daemon_dm_dspt = "실패 (" + Const.DEFAULT_TITLE_JIK + "정보 동기화 예외 : " + e.getMessage() + ")";
				}

				daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

				// ########## 로그 정보 ##########
				log += Const.DEFAULT_TITLE_JIK + "정보 동기화 데몬로그\n";
				log += "\t" + "st_tm=" + daemon_st_tm + "\n";
				log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
				log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
				log += "\t" + "status=" + daemon_status + "\n";
				log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
				log += Const.DEFAULT_TITLE_JIK + "정보 동기화 처리결과\n";
				log += sb.toString();

				LogUtil.info(debugKey + "########## Job Trace ##########", log);

				Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
				if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
					Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

				log = "";
				sb = new StringBuffer();
			}
		}

		// ########## 사원정보 동기화 ##########
		if (StringUtil.isEquals(opt_emp, "Y")) {
			daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			try {

				/*
					emp_no: 사원 코드
					emp_nm: 사원 이름
					dpt_cd: 부서 코드
					pos_cd: 직책 코드
					tit_cd: 직위 코드
					status: 퇴직(0)/재직(1)/휴직(2)/공용(3)
				*/
				String emp_no = "";
				String emp_nm = "";
				String dpt_cd = "1";
				String pos_cd = "1";
				String tit_cd = "1";
				String status = "1";
				String emp_account = "";
				String change_dt = "";
				String change_empno = Const.DEFAULT_SYSTEM_CODE;

				/*
					cds: 동기화 코드
				*/
				String cds = "";

				// ldap 사용으로 인해 주석 처리
//				openConn();
//
//				setVersion("2022.04.07.01");
//				setComment("사원정보");
//				setQuery("SELECT");
//				setQuery("	  EMP_ID, EMP_NAME_KOR, DEPT_ID, EMP_JOB_POSITION_CD, EMP_TITLE_CD, STATUS");
//				setQuery("FROM");
//				setQuery("	TBL_EMPLOYEE");
//				row = getRs();
//
//				closeConn();

				/**
				 * AIA - 커스터마이징
				 * Ldap 접속하여 사원정보 추출
				 */
				Ldap ldap = new Ldap();
				List<Map<String, Object>> employeeList = ldap.ldapEmployeeSync();
				LogUtil.info(debugKey + "[LdapDataCount: "+employeeList.size()+ "]");

				//test code
//				String testData = "131669|test1,1126|홍박사,1234|장박사,123|동기화,312321|312312,123455|12345,T18401|test4,151736|test2,181853|test3,E131445|테스트,E1314444|테스트";
//
//				String[] testDataArr = testData.split(",");
//
//				employeeList.clear();
//
//				for (String str : testDataArr) {
//
//					String[] testEmpArr = str.split("\\|");
//
//					Map<String, Object> tempMap = new HashMap<String, Object>();
//
//					tempMap.put("empNo", testEmpArr[0]);
//					tempMap.put("empNm", testEmpArr[1]);
//					tempMap.put("empAccount", testEmpArr[0]);
//
//					employeeList.add(tempMap);
//
//				}

				for (int i = 0; i < employeeList.size(); i++) {
					emp_no = String.valueOf(employeeList.get(i).get("empNo"));
					if(employeeList.get(i).get("empNm") != null){
						emp_nm = String.valueOf(employeeList.get(i).get("empNm"));
					}
					if(employeeList.get(i).get("empAccount") != null){
						emp_account = String.valueOf(employeeList.get(i).get("empAccount"));
					}
//					dpt_cd = StringUtil.trim(row.getData("DEPT_ID", i));
//					pos_cd = StringUtil.trim(row.getData("EMP_JOB_POSITION_CD", i));
//					tit_cd = StringUtil.trim(row.getData("EMP_TITLE_CD", i));
//					status = StringUtil.trim(row.getData("STATUS", i));

					setVersion("2022.04.07.01");
					setComment("사원정보 동기화");
					// 고객사 DBMS 변경으로 인한 쿼리 수정
					// 오라클 주석
//					setQuery("MERGE INTO jovt_member");
//					setQuery("	USING DUAL");
//					setQuery("	ON(emp_no = ?)", emp_no);
//					setQuery("	WHEN MATCHED THEN");
//					setQuery("		UPDATE SET");
//					setQuery("			emp_nm = ? ", emp_nm);
//					setQuery("			, dpt_cd = ? ", dpt_cd);
//					setQuery("			, pos_cd = ? ", pos_cd);
//					setQuery("			, tit_cd = ? ", tit_cd);
//					setQuery("			, emp_account = ? ", emp_account);
//					setQueryInt("		, status = ? ", status);
//					setQuery("			, change_empno = ? ", change_empno);
//					setQuery("			, change_dt = SYSDATE ");
//					setQuery("	WHEN NOT MATCHED THEN");
//					setQuery("		INSERT (emp_no, emp_nm, dpt_cd, pos_cd, tit_cd, emp_account, status, change_empno, change_dt)");
//					setQuery("			VALUES(?, ?, ?, ?, ?, ?, ?, ?,SYSDATE)");
					// postgresql
					setQuery("insert into jovt_member (emp_no, emp_nm, dpt_cd, pos_cd, tit_cd, emp_account, status, change_empno, change_dt)");
					setQuery("values(?, ?, ?, ?, ?, ?, ?, ?, now())");
					setParam(emp_no);
					setParam(emp_nm);
					setParam(dpt_cd);
					setParam(pos_cd);
					setParam(tit_cd);
					setParam(emp_account);
					setParamInt(status);
					setParam(change_empno);
					setQuery("on conflict (emp_no)");
					setQuery("do");
					setQuery("update set");
					setQuery("	dpt_cd = ?", dpt_cd);
					setQuery("	, pos_cd = ?", pos_cd);
					setQuery("	, tit_cd = ?", tit_cd);
					setQuery("	, emp_account = ?", emp_account);
					setQueryInt("	, status = ?", status);
					setQuery("	, change_empno = ?", change_empno);
					setQuery("	, change_dt = now()");
					executeQuery();

					// ########## 알괄취소 제외 요청으로 인한 일괄취소 처리 스킵 ##########

					if (StringUtil.isEmpty(cds)) {
						cds += "(1, '" + emp_no + "')";
					} else {
						cds += ",(1, '" + emp_no + "')";
					}

					System.out.println(" ★★★★★★★★★★★★★★★ cds : " +cds);

					// ########## 처리결과 ##########
					sb.append("\t" + (i+1) + ".emp_no=" + emp_no + "\n");
					sb.append("\t" + (i+1) + ".emp_nm=" + emp_nm + "\n");
					sb.append("\t" + (i+1) + ".dpt_cd=" + dpt_cd + "\n");
					sb.append("\t" + (i+1) + ".pos_cd=" + pos_cd + "\n");
					sb.append("\t" + (i+1) + ".tit_cd=" + tit_cd + "\n");
					sb.append("\t" + (i+1) + ".status=" + status + "\n");
				}

				if (!StringUtil.isEmpty(cds)) {
					setVersion("2022.04.07.01");
					setComment("사원정보 퇴직");
					setQuery("UPDATE jovt_member SET");
					setQuery("	status = 0");
					setQuery("	, change_empno = ?", change_empno);
					setQuery("	, change_dt = now()");
					setQuery("WHERE");
					setQuery("	(status = 1 OR status = 2)");
					setQuery("	AND emp_no <> '" + Const.DEFAULT_ADMIN_NO + "'");
					setQuery("	AND (1, emp_no) NOT IN (" + cds + ")");
					setQuery("	AND change_empno = ?", change_empno);
					executeQuery();
				}

				daemon_status = "1";
				daemon_dm_dspt = "성공 (사원정보 동기화 완료)";
			} catch (Exception e) {
				daemon_status = "0";
				daemon_dm_dspt = "실패 (사원정보 동기화 예외 : " + e.getMessage() + ")";
			}

			daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			// ########## 로그 정보 ##########
			log += "사원정보 동기화 데몬로그\n";
			log += "\t" + "st_tm=" + daemon_st_tm + "\n";
			log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
			log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
			log += "\t" + "status=" + daemon_status + "\n";
			log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
			log += "사원정보 동기화 처리결과\n";
			log += sb.toString();

			LogUtil.info(debugKey + "########## Job Trace ##########", log);

			Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
			if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
				Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

			log = "";
			sb = new StringBuffer();

			// ########## 사원정보 초기화 ##########
			/* ANSI SQL */
			setVersion("2022.04.07.01");
			setComment("사원정보 트리거");
			setQuery("UPDATE jovt_member SET status = status, calling_seq = -1");
			executeQuery();

			if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
				/* POSTGRESQL */
				setVersion("2022.04.07.01");
				setComment("에이전트 호출 순서");
				setQuery("UPDATE jovt_member A SET");
				setQuery("	calling_seq = B.calling_seq");
				setQuery("FROM");
				setQuery("	(SELECT");
				setQuery("		(ROW_NUMBER() OVER() - 1) AS calling_seq, emp_no");
				setQuery("	FROM");
				setQuery("		jovt_member B");
				setQuery("	WHERE");
				setQuery("		status <> 3 AND emp_no IN (SELECT emp_no FROM jovt_prg_client WHERE uninstall_flag = 0)) B");
				setQuery("WHERE");
				setQuery("	A.emp_no = B.emp_no");
				executeQuery();
			} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
				/* ORACLE */
				setVersion("2022.04.07.01");
				setComment("에이전트 호출 순서");
				setQuery("UPDATE jovt_member SET");
				setQuery("	calling_seq = (ROWNUM - 1)");
				setQuery("WHERE");
				setQuery("	status <> 3");
				setQuery("	AND emp_no IN (SELECT emp_no FROM jovt_prg_client WHERE uninstall_flag = 0)");
				executeQuery();
			}
		}
	}

	private void Log(String daemon_st_tm, String daemon_ed_tm, String daemon_dm_nm, String daemon_status, String daemon_dm_dspt) throws DBWorkerException, ResultObjectException {
		if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
			/* POSTGRESQL */
			setVersion("2015.05.27.01");
			setComment("데몬로그 저장");
			setQuery("INSERT INTO jovt_daemon_log");
			setQuery("	(st_tm, ed_tm, dm_nm, status, dm_dspt)");
			setQuery("VALUES");
			setQuery("	(TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US'), TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US'), ?, ?, ?)");
			setParam(daemon_st_tm);
			setParam(daemon_ed_tm);
			setParam(daemon_dm_nm);
			setParamInt(daemon_status);
			setParam(daemon_dm_dspt);
			executeQuery();
		} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
			/* ORACLE */
			setVersion("2015.05.27.01");
			setComment("데몬로그 저장");
			setQuery("INSERT INTO jovt_daemon_log");
			setQuery("	(st_tm, ed_tm, dm_nm, status, dm_dspt)");
			setQuery("VALUES");
			setQuery("	(TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS'), TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS'), ?, ?, ?)");
			setParam(daemon_st_tm);
			setParam(daemon_ed_tm);
			setParam(daemon_dm_nm);
			setParamInt(daemon_status);
			setParam(daemon_dm_dspt);
			executeQuery();
		}
	}

	private void Mail(String daemon_dm_nm, String daemon_status, String daemon_dm_dspt) throws DBWorkerException, ResultObjectException {
		if (StringUtil.isEquals(daemon_status, "0")) {
			String mail_title = "[" + Const.DEFAULT_SITE_NAME + "] " + Const.DEFAULT_PRODUCT_NAME + "-" + daemon_dm_nm + " 데몬에러";
			String mail_contents = daemon_dm_nm + "<br /><br />" + daemon_dm_dspt;
			String send_emp_no = Const.DEFAULT_SYSTEM_CODE;
			String send_emp_nm = Const.DEFAULT_SYSTEM_NAME;
			String send_mail = Const.DEFAULT_EMAIL_SYSTEM;
			String recv_mail = "";

			/* ANSI SQL */
			setVersion("2015.05.27.01");
			setComment("이메일 정보");
			setQuery("SELECT");
			setQuery("	daemon_email");
			setQuery("FROM");
			setQuery("	jovt_system");
			ResultObject row = getRs();

			if (row.getRsCount() > 0) {
				recv_mail = row.getData("daemon_email", 0);
			}

			String[] arr = recv_mail.split(";");
			for (int i = 0; i < arr.length; i++) {
				if (!StringUtil.isEmpty(StringUtil.trim(arr[i]))) {
					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.05.27.01");
						setComment("이메일 발송");
						setQuery("INSERT INTO jovt_mail_list");
						setQuery("	(mail_title, mail_contents, send_emp_no, send_emp_nm, send_mail, recv_emp_no, recv_emp_nm, recv_mail, reg_dt, mail_type)");
						setQuery("VALUES");
						setQuery("	(?, ?, ?, ?, ?, '', '', ?, NOW(), 1)");
						setParam(mail_title);
						setParam(mail_contents);
						setParam(send_emp_no);
						setParam(send_emp_nm);
						setParam(send_mail);
						setParam(StringUtil.trim(arr[i]));
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.05.27.01");
						setComment("이메일 발송");
						setQuery("INSERT INTO jovt_mail_list");
						setQuery("	(mail_title, mail_contents, send_emp_no, send_emp_nm, send_mail, recv_emp_no, recv_emp_nm, recv_mail, reg_dt, mail_type)");
						setQuery("VALUES");
						setQuery("	(?, ?, ?, ?, ?, NULL, NULL, ?, SYSDATE, 1)");
						setParam(mail_title);
						setParam(mail_contents);
						setParam(send_emp_no);
						setParam(send_emp_nm);
						setParam(send_mail);
						setParam(StringUtil.trim(arr[i]));
						executeQuery();
					}
				}
			}
		}
	}
}
