package jworks.job;

import jworks.biz.Const;
import jworks.core.DBWorker;
import jworks.core.ResultObject;
import jworks.exception.DBWorkerException;
import jworks.exception.ResultObjectException;
import jworks.util.DateUtil;
import jworks.util.LogUtil;
import jworks.util.StringUtil;

/**
 * <pre>
 * Statistics.java
 *
 * </pre>
 */
public class Statistics extends DBWorker {
	public void job() throws DBWorkerException, ResultObjectException {
		this.debugKey = "[JOB]\n";

		// #########################
		// 파라미터 설정
		// #########################
		/*
			daemon_st_tm: 시작시
			daemon_ed_tm: 종료시
			daemon_dm_nm: 데몬 클래스명
			daemon_status: 성공(1)/실패(0)
			daemon_dm_dspt: 상세 정보
		*/
		String daemon_st_tm = "";
		String daemon_ed_tm = "";
		String daemon_dm_nm = "Statistics";
		String daemon_status = "1";
		String daemon_dm_dspt = "";

		/*
			stat_year: 통계년
			stat_month: 통계월
			emp_no: 사원 코드
			dpt_cd: 부서 코드
			pos_cd: 직급 코드
			tit_cd: 직위 코드
			jik_cd: 직책 코드
			pc_on_avg: LOG ON 평균시각
			pc_on_emp_cnt: LOG ON 평균시각 통계 대상자수
			pc_off_avg: LOG OFF 평균시각
			pc_off_emp_cnt: LOG OFF 평균시각 통계 대상자수
			over_request_cnt: 연장사용신청
			over_request_2_cnt: 긴급사용신청
			over_request_mm: 신청시간 합계 (분)
			over_acpt_mm: 인정시간 합계 (분)
		*/
		String stat_year = "";
		String stat_month = "";
		String emp_no = "";
		String dpt_cd = "";
		String pos_cd = "";
		String tit_cd = "";
		String jik_cd = "";
		String pc_on_avg = "";
		String pc_on_emp_cnt = "";
		String pc_off_avg = "";
		String pc_off_emp_cnt = "";
		String over_request_cnt = "";
		String over_request_2_cnt = "";
		String over_request_mm = "";
		String over_acpt_mm = "";

		// #########################
		// 데이터 처리
		// #########################
		ResultObject row1 = null;
		ResultObject row2 = null;

		String log = "";
		StringBuffer sb = new StringBuffer();

		// ########## PC ON/OFF 통계처리 (개인별) ##########
		daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		try {
			openConn();
			beginTran();

			/* ANSI SQL */
			setVersion("2015.11.20.01");
			setComment("PC ON/OFF 통계처리 목록 (개인별)");
			setQuery("SELECT");
			setQuery("	stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd");
			setQuery("FROM");
			setQuery("	jovt_stat_pconoff_emp");
			setQuery("WHERE");
			setQuery("	need_recalc = 1");
			row1 = getRs();

			for (int i = 0; i < row1.getRsCount(); i++) {
				stat_year = row1.getData("stat_year", i);
				stat_month = row1.getData("stat_month", i);
				emp_no = row1.getData("emp_no", i);
				dpt_cd = row1.getData("dpt_cd", i);
				pos_cd = row1.getData("pos_cd", i);
				tit_cd = row1.getData("tit_cd", i);
				jik_cd = row1.getData("jik_cd", i);

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.11.20.01");
					setComment("PC ON/OFF 통계처리 계산 (개인별)");
					setQuery("SELECT");
					setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
					setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
					setQuery("FROM (");
					setQuery("	SELECT * FROM");
					setQuery("		-- PC ON 평균");
					setQuery("		(SELECT");
					setQuery("			S1.emp_no AS pc_on_emp_no");
					setQuery("			, AVG((DATE_PART('hour', S1.pc_on_dt) * 60) + DATE_PART('minute', S1.pc_on_dt)) AS pc_on_avg");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND DATE_PART('hour', A.pc_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					//setQuery("				AND DATE_PART('hour', A.pc_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND DATE_PART('hour', A.log_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					setQuery("				AND DATE_PART('hour', A.log_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND A.emp_no = ?", emp_no);
					setQuery("				AND A.dpt_cd = ?", dpt_cd);
					setQuery("				AND A.pos_cd = ?", pos_cd);
					setQuery("				AND A.tit_cd = ?", tit_cd);
//					setQuery("				AND A.jik_cd = ?", jik_cd);
					setQuery("			) S1");
					setQuery("		GROUP BY");
					setQuery("			S1.emp_no");
					setQuery("		) T1");
					setQuery("	FULL OUTER JOIN");
					setQuery("		-- PC OFF 평균");
					setQuery("		(SELECT");
					setQuery("			S2.emp_no AS pc_off_emp_no");
					setQuery("			, AVG((DATE_PART('hour', S2.pc_off_dt) * 60) + DATE_PART('minute', S2.pc_off_dt)) AS pc_off_avg");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND DATE_PART('hour', A.pc_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND DATE_PART('hour', A.log_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND A.emp_no = ?", emp_no);
					setQuery("				AND A.dpt_cd = ?", dpt_cd);
					setQuery("				AND A.pos_cd = ?", pos_cd);
					setQuery("				AND A.tit_cd = ?", tit_cd);
//					setQuery("				AND A.jik_cd = ?", jik_cd);
					setQuery("			) S2");
					setQuery("		GROUP BY");
					setQuery("			S2.emp_no");
					setQuery("		) T2");
					setQuery("	ON T1.pc_on_emp_no = T2.pc_off_emp_no");
					setQuery(") T");
					row2 = getRs();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.11.20.01");
					setComment("PC ON/OFF 통계처리 계산 (개인별)");
					setQuery("SELECT");
					setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
					setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
					setQuery("FROM (");
					setQuery("	SELECT * FROM");
					setQuery("		-- PC ON 평균");
					setQuery("		(SELECT");
					setQuery("			S1.emp_no AS pc_on_emp_no");
					setQuery("			, AVG((CAST(TO_CHAR(S1.pc_on_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S1.pc_on_dt, 'MI') AS INT)) AS pc_on_avg");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND A.emp_no = ?", emp_no);
					setQuery("				AND A.dpt_cd = ?", dpt_cd);
					setQuery("				AND A.pos_cd = ?", pos_cd);
					setQuery("				AND A.tit_cd = ?", tit_cd);
					setQuery("				AND A.jik_cd = ?", jik_cd);
					setQuery("			) S1");
					setQuery("		GROUP BY");
					setQuery("			S1.emp_no");
					setQuery("		) T1");
					setQuery("	FULL OUTER JOIN");
					setQuery("		-- PC OFF 평균");
					setQuery("		(SELECT");
					setQuery("			S2.emp_no AS pc_off_emp_no");
					setQuery("			, AVG((CAST(TO_CHAR(S2.pc_off_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S2.pc_off_dt, 'MI') AS INT)) AS pc_off_avg");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND CAST(TO_CHAR(A.pc_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND CAST(TO_CHAR(A.log_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND A.emp_no = ?", emp_no);
					setQuery("				AND A.dpt_cd = ?", dpt_cd);
					setQuery("				AND A.pos_cd = ?", pos_cd);
					setQuery("				AND A.tit_cd = ?", tit_cd);
					setQuery("				AND A.jik_cd = ?", jik_cd);
					setQuery("			) S2");
					setQuery("		GROUP BY");
					setQuery("			S2.emp_no");
					setQuery("		) T2");
					setQuery("	ON T1.pc_on_emp_no = T2.pc_off_emp_no");
					setQuery(") T");
					row2 = getRs();
				}

				if (row2.getRsCount() > 0) {
					pc_on_avg = row2.getData("pc_on_avg", 0);
					pc_off_avg = row2.getData("pc_off_avg", 0);
				} else {
					pc_on_avg = "0";
					pc_off_avg = "0";
				}

				if (StringUtil.isEmpty(pc_on_avg)) pc_on_avg = "0";
				if (StringUtil.isEmpty(pc_off_avg)) pc_off_avg = "0";

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.11.20.01");
					setComment("PC ON/OFF 통계처리 저장 (개인별)");
					setQuery("UPDATE jovt_stat_pconoff_emp SET");
					setQueryDouble("	pc_on_avg = ?", pc_on_avg);
					setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
					setQuery("	, change_dt = NOW()");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND emp_no = ?", emp_no);
					setQuery("	AND dpt_cd = ?", dpt_cd);
					setQuery("	AND pos_cd = ?", pos_cd);
					setQuery("	AND tit_cd = ?", tit_cd);
//					setQuery("	AND jik_cd = ?", jik_cd);
					executeQuery();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.11.20.01");
					setComment("PC ON/OFF 통계처리 저장 (개인별)");
					setQuery("UPDATE jovt_stat_pconoff_emp SET");
					setQueryDouble("	pc_on_avg = ?", pc_on_avg);
					setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
					setQuery("	, change_dt = SYSDATE");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND emp_no = ?", emp_no);
					setQuery("	AND dpt_cd = ?", dpt_cd);
					setQuery("	AND pos_cd = ?", pos_cd);
					setQuery("	AND tit_cd = ?", tit_cd);
//					setQuery("	AND jik_cd = ?", jik_cd);
					executeQuery();
				}

				// ########## 계산결과 ##########
				sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
				sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
				sb.append("\t" + (i+1) + ".emp_no=" + emp_no + "\n");
				sb.append("\t" + (i+1) + ".dpt_cd=" + dpt_cd + "\n");
				sb.append("\t" + (i+1) + ".pos_cd=" + pos_cd + "\n");
				sb.append("\t" + (i+1) + ".tit_cd=" + tit_cd + "\n");
				sb.append("\t" + (i+1) + ".jik_cd=" + jik_cd + "\n");
				sb.append("\t" + (i+1) + ".pc_on_avg=" + pc_on_avg + "\n");
				sb.append("\t" + (i+1) + ".pc_off_avg=" + pc_off_avg + "\n");
			}

			commitTran();

			daemon_status = "1";
			daemon_dm_dspt = "성공 (통계처리 PC ON/OFF (개인별) 완료)";
		} catch (Exception e) {
			rollbackTran();

			daemon_status = "0";
			daemon_dm_dspt = "실패 (통계처리 PC ON/OFF (개인별) 예외 : " + e.getMessage() + ")";
		} finally {
			closeConn();
		}

		daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		// ########## 로그 정보 ##########
		log += "통계처리 데몬로그\n";
		log += "\t" + "st_tm=" + daemon_st_tm + "\n";
		log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
		log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
		log += "\t" + "status=" + daemon_status + "\n";
		log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
		log += "통계처리 계산결과\n";
		log += sb.toString();

		LogUtil.info(debugKey + "########## Job Trace ##########", log);

		Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
			Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

		log = "";
		sb = new StringBuffer();

		// ########## PC ON/OFF 통계처리 (부서별) ##########
		daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		try {
			openConn();
			beginTran();

			/* ANSI SQL */
			setVersion("2015.05.28.01");
			setComment("PC ON/OFF 통계처리 목록 (부서별)");
			setQuery("SELECT");
			setQuery("	stat_year, stat_month, dpt_cd");
			setQuery("FROM");
			setQuery("	jovt_stat_pconoff_dpt");
			setQuery("WHERE");
			setQuery("	need_recalc = 1");
			row1 = getRs();

			for (int i = 0; i < row1.getRsCount(); i++) {
				stat_year = row1.getData("stat_year", i);
				stat_month = row1.getData("stat_month", i);
				dpt_cd = row1.getData("dpt_cd", i);

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.05.28.01");
					setComment("PC ON/OFF 통계처리 계산 (부서별)");
					setQuery("SELECT");
					setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
					setQuery("	, COALESCE(pc_on_emp_cnt, 0) AS pc_on_emp_cnt");
					setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
					setQuery("	, COALESCE(pc_off_emp_cnt, 0) AS pc_off_emp_cnt");
					setQuery("FROM (");
					setQuery("	SELECT * FROM");
					setQuery("		-- PC ON 평균");
					setQuery("		(SELECT");
					setQuery("			S1.dpt_cd AS pc_on_dpt_cd");
					setQuery("			, AVG((DATE_PART('hour', S1.pc_on_dt) * 60) + DATE_PART('minute', S1.pc_on_dt)) AS pc_on_avg");
					setQuery("			, COUNT(DISTINCT(S1.emp_no)) AS pc_on_emp_cnt");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no, A.dpt_cd");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("				LEFT OUTER JOIN jovt_member B ON A.emp_no = B.emp_no");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND DATE_PART('hour', A.pc_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					//setQuery("				AND DATE_PART('hour', A.pc_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND DATE_PART('hour', A.log_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					setQuery("				AND DATE_PART('hour', A.log_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND (A.emp_no <> '' AND A.emp_no IS NOT NULL)");
					setQuery("				AND A.dpt_cd = ?", dpt_cd);
					setQuery("			) S1");
					setQuery("		GROUP BY");
					setQuery("			S1.dpt_cd");
					setQuery("		) T1");
					setQuery("	FULL OUTER JOIN");
					setQuery("		-- PC OFF 평균");
					setQuery("		(SELECT");
					setQuery("			S2.dpt_cd AS pc_off_dpt_cd");
					setQuery("			, AVG((DATE_PART('hour', S2.pc_off_dt) * 60) + DATE_PART('minute', S2.pc_off_dt)) AS pc_off_avg");
					setQuery("			, COUNT(DISTINCT(S2.emp_no)) AS pc_off_emp_cnt");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no, A.dpt_cd");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("				LEFT OUTER JOIN jovt_member B ON A.emp_no = B.emp_no");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND DATE_PART('hour', A.pc_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND DATE_PART('hour', A.log_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND (A.emp_no <> '' AND A.emp_no IS NOT NULL)");
					setQuery("				AND A.dpt_cd = ?", dpt_cd);
					setQuery("			) S2");
					setQuery("		GROUP BY");
					setQuery("			S2.dpt_cd");
					setQuery("		) T2");
					setQuery("	ON T1.pc_on_dpt_cd = T2.pc_off_dpt_cd");
					setQuery(") T");
					row2 = getRs();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.05.28.01");
					setComment("PC ON/OFF 통계처리 계산 (부서별)");
					setQuery("SELECT");
					setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
					setQuery("	, COALESCE(pc_on_emp_cnt, 0) AS pc_on_emp_cnt");
					setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
					setQuery("	, COALESCE(pc_off_emp_cnt, 0) AS pc_off_emp_cnt");
					setQuery("FROM (");
					setQuery("	SELECT * FROM");
					setQuery("		-- PC ON 평균");
					setQuery("		(SELECT");
					setQuery("			S1.dpt_cd AS pc_on_dpt_cd");
					setQuery("			, AVG((CAST(TO_CHAR(S1.pc_on_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S1.pc_on_dt, 'MI') AS INT)) AS pc_on_avg");
					setQuery("			, COUNT(DISTINCT(S1.emp_no)) AS pc_on_emp_cnt");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no, A.dpt_cd");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("				LEFT OUTER JOIN jovt_member B ON A.emp_no = B.emp_no");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND A.emp_no IS NOT NULL");
					setQuery("				AND A.dpt_cd = ?", dpt_cd);
					setQuery("			) S1");
					setQuery("		GROUP BY");
					setQuery("			S1.dpt_cd");
					setQuery("		) T1");
					setQuery("	FULL OUTER JOIN");
					setQuery("		-- PC OFF 평균");
					setQuery("		(SELECT");
					setQuery("			S2.dpt_cd AS pc_off_dpt_cd");
					setQuery("			, AVG((CAST(TO_CHAR(S2.pc_off_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S2.pc_off_dt, 'MI') AS INT)) AS pc_off_avg");
					setQuery("			, COUNT(DISTINCT(S2.emp_no)) AS pc_off_emp_cnt");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no, A.dpt_cd");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("				LEFT OUTER JOIN jovt_member B ON A.emp_no = B.emp_no");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND CAST(TO_CHAR(A.pc_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND CAST(TO_CHAR(A.log_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND A.emp_no IS NOT NULL");
					setQuery("				AND A.dpt_cd = ?", dpt_cd);
					setQuery("			) S2");
					setQuery("		GROUP BY");
					setQuery("			S2.dpt_cd");
					setQuery("		) T2");
					setQuery("	ON T1.pc_on_dpt_cd = T2.pc_off_dpt_cd");
					setQuery(") T");
					row2 = getRs();
				}

				if (row2.getRsCount() > 0) {
					pc_on_avg = row2.getData("pc_on_avg", 0);
					pc_on_emp_cnt = row2.getData("pc_on_emp_cnt", 0);
					pc_off_avg = row2.getData("pc_off_avg", 0);
					pc_off_emp_cnt = row2.getData("pc_off_emp_cnt", 0);
				} else {
					pc_on_avg = "0";
					pc_on_emp_cnt = "0";
					pc_off_avg = "0";
					pc_off_emp_cnt = "0";
				}

				if (StringUtil.isEmpty(pc_on_avg)) pc_on_avg = "0";
				if (StringUtil.isEmpty(pc_on_emp_cnt)) pc_on_emp_cnt = "0";
				if (StringUtil.isEmpty(pc_off_avg)) pc_off_avg = "0";
				if (StringUtil.isEmpty(pc_off_emp_cnt)) pc_off_emp_cnt = "0";

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.05.28.01");
					setComment("PC ON/OFF 통계처리 저장 (부서별)");
					setQuery("UPDATE jovt_stat_pconoff_dpt SET");
					setQueryDouble("	pc_on_avg = ?", pc_on_avg);
					setQueryInt("	, pc_on_emp_cnt = ?", pc_on_emp_cnt);
					setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
					setQueryInt("	, pc_off_emp_cnt = ?", pc_off_emp_cnt);
					setQuery("	, change_dt = NOW()");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND dpt_cd = ?", dpt_cd);
					executeQuery();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.05.28.01");
					setComment("PC ON/OFF 통계처리 저장 (부서별)");
					setQuery("UPDATE jovt_stat_pconoff_dpt SET");
					setQueryDouble("	pc_on_avg = ?", pc_on_avg);
					setQueryInt("	, pc_on_emp_cnt = ?", pc_on_emp_cnt);
					setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
					setQueryInt("	, pc_off_emp_cnt = ?", pc_off_emp_cnt);
					setQuery("	, change_dt = SYSDATE");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND dpt_cd = ?", dpt_cd);
					executeQuery();
				}

				// ########## 계산결과 ##########
				sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
				sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
				sb.append("\t" + (i+1) + ".dpt_cd=" + dpt_cd + "\n");
				sb.append("\t" + (i+1) + ".pc_on_avg=" + pc_on_avg + "\n");
				sb.append("\t" + (i+1) + ".pc_on_emp_cnt=" + pc_on_emp_cnt + "\n");
				sb.append("\t" + (i+1) + ".pc_off_avg=" + pc_off_avg + "\n");
				sb.append("\t" + (i+1) + ".pc_off_emp_cnt=" + pc_off_emp_cnt + "\n");
			}

			commitTran();

			daemon_status = "1";
			daemon_dm_dspt = "성공 (통계처리 PC ON/OFF (부서별) 완료)";
		} catch (Exception e) {
			rollbackTran();

			daemon_status = "0";
			daemon_dm_dspt = "실패 (통계처리 PC ON/OFF (부서별) 예외 : " + e.getMessage() + ")";
		} finally {
			closeConn();
		}

		daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		// ########## 로그 정보 ##########
		log += "통계처리 데몬로그\n";
		log += "\t" + "st_tm=" + daemon_st_tm + "\n";
		log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
		log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
		log += "\t" + "status=" + daemon_status + "\n";
		log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
		log += "통계처리 계산결과\n";
		log += sb.toString();

		LogUtil.info(debugKey + "########## Job Trace ##########", log);

		Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
			Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

		log = "";
		sb = new StringBuffer();

		// ########## PC ON/OFF 통계처리 (직급별) ##########
		daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		try {
			openConn();
			beginTran();

			/* ANSI SQL */
			setVersion("2015.05.28.01");
			setComment("PC ON/OFF 통계처리 목록 (직급별)");
			setQuery("SELECT");
			setQuery("	stat_year, stat_month, pos_cd");
			setQuery("FROM");
			setQuery("	jovt_stat_pconoff_position");
			setQuery("WHERE");
			setQuery("	need_recalc = 1");
			row1 = getRs();

			for (int i = 0; i < row1.getRsCount(); i++) {
				stat_year = row1.getData("stat_year", i);
				stat_month = row1.getData("stat_month", i);
				pos_cd = row1.getData("pos_cd", i);

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.05.28.01");
					setComment("PC ON/OFF 통계처리 계산 (직급별)");
					setQuery("SELECT");
					setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
					setQuery("	, COALESCE(pc_on_emp_cnt, 0) AS pc_on_emp_cnt");
					setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
					setQuery("	, COALESCE(pc_off_emp_cnt, 0) AS pc_off_emp_cnt");
					setQuery("FROM (");
					setQuery("	SELECT * FROM");
					setQuery("		-- PC ON 평균");
					setQuery("		(SELECT");
					setQuery("			S1.pos_cd AS pc_on_pos_cd");
					setQuery("			, AVG((DATE_PART('hour', S1.pc_on_dt) * 60) + DATE_PART('minute', S1.pc_on_dt)) AS pc_on_avg");
					setQuery("			, COUNT(DISTINCT(S1.emp_no)) AS pc_on_emp_cnt");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no, B.pos_cd");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
					setQuery("				LEFT OUTER JOIN jovt_position C ON B.pos_cd = C.pos_cd");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND DATE_PART('hour', A.pc_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					//setQuery("				AND DATE_PART('hour', A.pc_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND DATE_PART('hour', A.log_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					setQuery("				AND DATE_PART('hour', A.log_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND B.pos_cd = ?", pos_cd);
					setQuery("			) S1");
					setQuery("		GROUP BY");
					setQuery("			S1.pos_cd");
					setQuery("		) T1");
					setQuery("	FULL OUTER JOIN");
					setQuery("		-- PC OFF 평균");
					setQuery("		(SELECT");
					setQuery("			S2.pos_cd AS pc_off_pos_cd");
					setQuery("			, AVG((DATE_PART('hour', S2.pc_off_dt) * 60) + DATE_PART('minute', S2.pc_off_dt)) AS pc_off_avg");
					setQuery("			, COUNT(DISTINCT(S2.emp_no)) AS pc_off_emp_cnt");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no, B.pos_cd");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
					setQuery("				LEFT OUTER JOIN jovt_position C ON B.pos_cd = C.pos_cd");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND DATE_PART('hour', A.pc_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND DATE_PART('hour', A.log_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND B.pos_cd = ?", pos_cd);
					setQuery("			) S2");
					setQuery("		GROUP BY");
					setQuery("			S2.pos_cd");
					setQuery("		) T2");
					setQuery("	ON T1.pc_on_pos_cd = T2.pc_off_pos_cd");
					setQuery(") T");
					row2 = getRs();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.05.28.01");
					setComment("PC ON/OFF 통계처리 계산 (직급별)");
					setQuery("SELECT");
					setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
					setQuery("	, COALESCE(pc_on_emp_cnt, 0) AS pc_on_emp_cnt");
					setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
					setQuery("	, COALESCE(pc_off_emp_cnt, 0) AS pc_off_emp_cnt");
					setQuery("FROM (");
					setQuery("	SELECT * FROM");
					setQuery("		-- PC ON 평균");
					setQuery("		(SELECT");
					setQuery("			S1.pos_cd AS pc_on_pos_cd");
					setQuery("			, AVG((CAST(TO_CHAR(S1.pc_on_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S1.pc_on_dt, 'MI') AS INT)) AS pc_on_avg");
					setQuery("			, COUNT(DISTINCT(S1.emp_no)) AS pc_on_emp_cnt");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no, B.pos_cd");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
					setQuery("				LEFT OUTER JOIN jovt_position C ON B.pos_cd = C.pos_cd");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
					setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
					setQuery("				AND B.pos_cd = ?", pos_cd);
					setQuery("			) S1");
					setQuery("		GROUP BY");
					setQuery("			S1.pos_cd");
					setQuery("		) T1");
					setQuery("	FULL OUTER JOIN");
					setQuery("		-- PC OFF 평균");
					setQuery("		(SELECT");
					setQuery("			S2.pos_cd AS pc_off_pos_cd");
					setQuery("			, AVG((CAST(TO_CHAR(S2.pc_off_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S2.pc_off_dt, 'MI') AS INT)) AS pc_off_avg");
					setQuery("			, COUNT(DISTINCT(S2.emp_no)) AS pc_off_emp_cnt");
					setQuery("		FROM");
					setQuery("			(SELECT");
					setQuery("				A.emp_no, B.pos_cd");
					//setQuery("				, A.pc_on_dt");
					//setQuery("				, A.pc_off_dt");
					setQuery("				, A.log_on_dt AS pc_on_dt");
					setQuery("				, A.log_off_dt AS pc_off_dt");
					setQuery("			FROM");
					setQuery("				jovt_otcalc A");
					setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
					setQuery("				LEFT OUTER JOIN jovt_position C ON B.pos_cd = C.pos_cd");
					setQuery("			WHERE");
					setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("				AND A.holiday_yn = 0");
					//setQuery("				AND CAST(TO_CHAR(A.pc_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND CAST(TO_CHAR(A.log_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
					setQuery("				AND B.pos_cd = ?", pos_cd);
					setQuery("			) S2");
					setQuery("		GROUP BY");
					setQuery("			S2.pos_cd");
					setQuery("		) T2");
					setQuery("	ON T1.pc_on_pos_cd = T2.pc_off_pos_cd");
					setQuery(") T");
					row2 = getRs();
				}

				if (row2.getRsCount() > 0) {
					pc_on_avg = row2.getData("pc_on_avg", 0);
					pc_on_emp_cnt = row2.getData("pc_on_emp_cnt", 0);
					pc_off_avg = row2.getData("pc_off_avg", 0);
					pc_off_emp_cnt = row2.getData("pc_off_emp_cnt", 0);
				} else {
					pc_on_avg = "0";
					pc_on_emp_cnt = "0";
					pc_off_avg = "0";
					pc_off_emp_cnt = "0";
				}

				if (StringUtil.isEmpty(pc_on_avg)) pc_on_avg = "0";
				if (StringUtil.isEmpty(pc_on_emp_cnt)) pc_on_emp_cnt = "0";
				if (StringUtil.isEmpty(pc_off_avg)) pc_off_avg = "0";
				if (StringUtil.isEmpty(pc_off_emp_cnt)) pc_off_emp_cnt = "0";

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.05.28.01");
					setComment("PC ON/OFF 통계처리 저장 (직급별)");
					setQuery("UPDATE jovt_stat_pconoff_position SET");
					setQueryDouble("	pc_on_avg = ?", pc_on_avg);
					setQueryInt("	, pc_on_emp_cnt = ?", pc_on_emp_cnt);
					setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
					setQueryInt("	, pc_off_emp_cnt = ?", pc_off_emp_cnt);
					setQuery("	, change_dt = NOW()");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND pos_cd = ?", pos_cd);
					executeQuery();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.05.28.01");
					setComment("PC ON/OFF 통계처리 저장 (직급별)");
					setQuery("UPDATE jovt_stat_pconoff_position SET");
					setQueryDouble("	pc_on_avg = ?", pc_on_avg);
					setQueryInt("	, pc_on_emp_cnt = ?", pc_on_emp_cnt);
					setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
					setQueryInt("	, pc_off_emp_cnt = ?", pc_off_emp_cnt);
					setQuery("	, change_dt = SYSDATE");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND pos_cd = ?", pos_cd);
					executeQuery();
				}

				// ########## 계산결과 ##########
				sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
				sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
				sb.append("\t" + (i+1) + ".pos_cd=" + pos_cd + "\n");
				sb.append("\t" + (i+1) + ".pc_on_avg=" + pc_on_avg + "\n");
				sb.append("\t" + (i+1) + ".pc_on_emp_cnt=" + pc_on_emp_cnt + "\n");
				sb.append("\t" + (i+1) + ".pc_off_avg=" + pc_off_avg + "\n");
				sb.append("\t" + (i+1) + ".pc_off_emp_cnt=" + pc_off_emp_cnt + "\n");
			}

			commitTran();

			daemon_status = "1";
			daemon_dm_dspt = "성공 (통계처리 PC ON/OFF (" + Const.DEFAULT_TITLE_POS + "별) 완료)";
		} catch (Exception e) {
			rollbackTran();

			daemon_status = "0";
			daemon_dm_dspt = "실패 (통계처리 PC ON/OFF (" + Const.DEFAULT_TITLE_POS + "별) 예외 : " + e.getMessage() + ")";
		} finally {
			closeConn();
		}

		daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		// ########## 로그 정보 ##########
		log += "통계처리 데몬로그\n";
		log += "\t" + "st_tm=" + daemon_st_tm + "\n";
		log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
		log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
		log += "\t" + "status=" + daemon_status + "\n";
		log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
		log += "통계처리 계산결과\n";
		log += sb.toString();

		LogUtil.info(debugKey + "########## Job Trace ##########", log);

		Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
			Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

		log = "";
		sb = new StringBuffer();

		// ########## PC ON/OFF 통계처리 (직위별) ##########
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_TIT, "Y")) {
			daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			try {
				openConn();
				beginTran();

				/* ANSI SQL */
				setVersion("2015.11.20.01");
				setComment("PC ON/OFF 통계처리 목록 (직위별)");
				setQuery("SELECT");
				setQuery("	stat_year, stat_month, tit_cd");
				setQuery("FROM");
				setQuery("	jovt_stat_pconoff_title");
				setQuery("WHERE");
				setQuery("	need_recalc = 1");
				row1 = getRs();

				for (int i = 0; i < row1.getRsCount(); i++) {
					stat_year = row1.getData("stat_year", i);
					stat_month = row1.getData("stat_month", i);
					tit_cd = row1.getData("tit_cd", i);

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 계산 (직위별)");
						setQuery("SELECT");
						setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
						setQuery("	, COALESCE(pc_on_emp_cnt, 0) AS pc_on_emp_cnt");
						setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
						setQuery("	, COALESCE(pc_off_emp_cnt, 0) AS pc_off_emp_cnt");
						setQuery("FROM (");
						setQuery("	SELECT * FROM");
						setQuery("		-- PC ON 평균");
						setQuery("		(SELECT");
						setQuery("			S1.tit_cd AS pc_on_tit_cd");
						setQuery("			, AVG((DATE_PART('hour', S1.pc_on_dt) * 60) + DATE_PART('minute', S1.pc_on_dt)) AS pc_on_avg");
						setQuery("			, COUNT(DISTINCT(S1.emp_no)) AS pc_on_emp_cnt");
						setQuery("		FROM");
						setQuery("			(SELECT");
						setQuery("				A.emp_no, B.tit_cd");
						//setQuery("				, A.pc_on_dt");
						//setQuery("				, A.pc_off_dt");
						setQuery("				, A.log_on_dt AS pc_on_dt");
						setQuery("				, A.log_off_dt AS pc_off_dt");
						setQuery("			FROM");
						setQuery("				jovt_otcalc A");
						setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
						setQuery("				LEFT OUTER JOIN jovt_title C ON B.tit_cd = C.tit_cd");
						setQuery("			WHERE");
						setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
						setQuery("				AND A.holiday_yn = 0");
						//setQuery("				AND DATE_PART('hour', A.pc_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
						//setQuery("				AND DATE_PART('hour', A.pc_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
						setQuery("				AND DATE_PART('hour', A.log_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
						setQuery("				AND DATE_PART('hour', A.log_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
						setQuery("				AND B.tit_cd = ?", tit_cd);
						setQuery("			) S1");
						setQuery("		GROUP BY");
						setQuery("			S1.tit_cd");
						setQuery("		) T1");
						setQuery("	FULL OUTER JOIN");
						setQuery("		-- PC OFF 평균");
						setQuery("		(SELECT");
						setQuery("			S2.tit_cd AS pc_off_tit_cd");
						setQuery("			, AVG((DATE_PART('hour', S2.pc_off_dt) * 60) + DATE_PART('minute', S2.pc_off_dt)) AS pc_off_avg");
						setQuery("			, COUNT(DISTINCT(S2.emp_no)) AS pc_off_emp_cnt");
						setQuery("		FROM");
						setQuery("			(SELECT");
						setQuery("				A.emp_no, B.tit_cd");
						//setQuery("				, A.pc_on_dt");
						//setQuery("				, A.pc_off_dt");
						setQuery("				, A.log_on_dt AS pc_on_dt");
						setQuery("				, A.log_off_dt AS pc_off_dt");
						setQuery("			FROM");
						setQuery("				jovt_otcalc A");
						setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
						setQuery("				LEFT OUTER JOIN jovt_title C ON B.tit_cd = C.tit_cd");
						setQuery("			WHERE");
						setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
						setQuery("				AND A.holiday_yn = 0");
						//setQuery("				AND DATE_PART('hour', A.pc_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
						setQuery("				AND DATE_PART('hour', A.log_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
						setQuery("				AND B.tit_cd = ?", tit_cd);
						setQuery("			) S2");
						setQuery("		GROUP BY");
						setQuery("			S2.tit_cd");
						setQuery("		) T2");
						setQuery("	ON T1.pc_on_tit_cd = T2.pc_off_tit_cd");
						setQuery(") T");
						row2 = getRs();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 계산 (직위별)");
						setQuery("SELECT");
						setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
						setQuery("	, COALESCE(pc_on_emp_cnt, 0) AS pc_on_emp_cnt");
						setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
						setQuery("	, COALESCE(pc_off_emp_cnt, 0) AS pc_off_emp_cnt");
						setQuery("FROM (");
						setQuery("	SELECT * FROM");
						setQuery("		-- PC ON 평균");
						setQuery("		(SELECT");
						setQuery("			S1.tit_cd AS pc_on_tit_cd");
						setQuery("			, AVG((CAST(TO_CHAR(S1.pc_on_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S1.pc_on_dt, 'MI') AS INT)) AS pc_on_avg");
						setQuery("			, COUNT(DISTINCT(S1.emp_no)) AS pc_on_emp_cnt");
						setQuery("		FROM");
						setQuery("			(SELECT");
						setQuery("				A.emp_no, B.tit_cd");
						//setQuery("				, A.pc_on_dt");
						//setQuery("				, A.pc_off_dt");
						setQuery("				, A.log_on_dt AS pc_on_dt");
						setQuery("				, A.log_off_dt AS pc_off_dt");
						setQuery("			FROM");
						setQuery("				jovt_otcalc A");
						setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
						setQuery("				LEFT OUTER JOIN jovt_title C ON B.tit_cd = C.tit_cd");
						setQuery("			WHERE");
						setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
						setQuery("				AND A.holiday_yn = 0");
						//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
						//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
						setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
						setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
						setQuery("				AND B.tit_cd = ?", tit_cd);
						setQuery("			) S1");
						setQuery("		GROUP BY");
						setQuery("			S1.tit_cd");
						setQuery("		) T1");
						setQuery("	FULL OUTER JOIN");
						setQuery("		-- PC OFF 평균");
						setQuery("		(SELECT");
						setQuery("			S2.tit_cd AS pc_off_tit_cd");
						setQuery("			, AVG((CAST(TO_CHAR(S2.pc_off_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S2.pc_off_dt, 'MI') AS INT)) AS pc_off_avg");
						setQuery("			, COUNT(DISTINCT(S2.emp_no)) AS pc_off_emp_cnt");
						setQuery("		FROM");
						setQuery("			(SELECT");
						setQuery("				A.emp_no, B.tit_cd");
						//setQuery("				, A.pc_on_dt");
						//setQuery("				, A.pc_off_dt");
						setQuery("				, A.log_on_dt AS pc_on_dt");
						setQuery("				, A.log_off_dt AS pc_off_dt");
						setQuery("			FROM");
						setQuery("				jovt_otcalc A");
						setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
						setQuery("				LEFT OUTER JOIN jovt_title C ON B.tit_cd = C.tit_cd");
						setQuery("			WHERE");
						setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
						setQuery("				AND A.holiday_yn = 0");
						//setQuery("				AND CAST(TO_CHAR(A.pc_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
						setQuery("				AND CAST(TO_CHAR(A.log_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
						setQuery("				AND B.tit_cd = ?", tit_cd);
						setQuery("			) S2");
						setQuery("		GROUP BY");
						setQuery("			S2.tit_cd");
						setQuery("		) T2");
						setQuery("	ON T1.pc_on_tit_cd = T2.pc_off_tit_cd");
						setQuery(") T");
						row2 = getRs();
					}

					if (row2.getRsCount() > 0) {
						pc_on_avg = row2.getData("pc_on_avg", 0);
						pc_on_emp_cnt = row2.getData("pc_on_emp_cnt", 0);
						pc_off_avg = row2.getData("pc_off_avg", 0);
						pc_off_emp_cnt = row2.getData("pc_off_emp_cnt", 0);
					} else {
						pc_on_avg = "0";
						pc_on_emp_cnt = "0";
						pc_off_avg = "0";
						pc_off_emp_cnt = "0";
					}

					if (StringUtil.isEmpty(pc_on_avg)) pc_on_avg = "0";
					if (StringUtil.isEmpty(pc_on_emp_cnt)) pc_on_emp_cnt = "0";
					if (StringUtil.isEmpty(pc_off_avg)) pc_off_avg = "0";
					if (StringUtil.isEmpty(pc_off_emp_cnt)) pc_off_emp_cnt = "0";

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 저장 (직위별)");
						setQuery("UPDATE jovt_stat_pconoff_title SET");
						setQueryDouble("	pc_on_avg = ?", pc_on_avg);
						setQueryInt("	, pc_on_emp_cnt = ?", pc_on_emp_cnt);
						setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
						setQueryInt("	, pc_off_emp_cnt = ?", pc_off_emp_cnt);
						setQuery("	, change_dt = NOW()");
						setQuery("	, need_recalc = 0");
						setQuery("WHERE");
						setQuery("	stat_year = ?", stat_year);
						setQuery("	AND stat_month = ?", stat_month);
						setQuery("	AND tit_cd = ?", tit_cd);
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 저장 (직위별)");
						setQuery("UPDATE jovt_stat_pconoff_title SET");
						setQueryDouble("	pc_on_avg = ?", pc_on_avg);
						setQueryInt("	, pc_on_emp_cnt = ?", pc_on_emp_cnt);
						setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
						setQueryInt("	, pc_off_emp_cnt = ?", pc_off_emp_cnt);
						setQuery("	, change_dt = SYSDATE");
						setQuery("	, need_recalc = 0");
						setQuery("WHERE");
						setQuery("	stat_year = ?", stat_year);
						setQuery("	AND stat_month = ?", stat_month);
						setQuery("	AND tit_cd = ?", tit_cd);
						executeQuery();
					}

					// ########## 계산결과 ##########
					sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
					sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
					sb.append("\t" + (i+1) + ".tit_cd=" + tit_cd + "\n");
					sb.append("\t" + (i+1) + ".pc_on_avg=" + pc_on_avg + "\n");
					sb.append("\t" + (i+1) + ".pc_on_emp_cnt=" + pc_on_emp_cnt + "\n");
					sb.append("\t" + (i+1) + ".pc_off_avg=" + pc_off_avg + "\n");
					sb.append("\t" + (i+1) + ".pc_off_emp_cnt=" + pc_off_emp_cnt + "\n");
				}

				commitTran();

				daemon_status = "1";
				daemon_dm_dspt = "성공 (통계처리 PC ON/OFF (" + Const.DEFAULT_TITLE_TIT + "별) 완료)";
			} catch (Exception e) {
				rollbackTran();

				daemon_status = "0";
				daemon_dm_dspt = "실패 (통계처리 PC ON/OFF (" + Const.DEFAULT_TITLE_TIT + "별) 예외 : " + e.getMessage() + ")";
			} finally {
				closeConn();
			}

			daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			// ########## 로그 정보 ##########
			log += "통계처리 데몬로그\n";
			log += "\t" + "st_tm=" + daemon_st_tm + "\n";
			log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
			log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
			log += "\t" + "status=" + daemon_status + "\n";
			log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
			log += "통계처리 계산결과\n";
			log += sb.toString();

			LogUtil.info(debugKey + "########## Job Trace ##########", log);

			Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
			if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
				Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

			log = "";
			sb = new StringBuffer();
		}

		// ########## PC ON/OFF 통계처리 (직책별) ##########
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_JIK, "Y")) {
			daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			try {
				openConn();
				beginTran();

				/* ANSI SQL */
				setVersion("2015.11.20.01");
				setComment("PC ON/OFF 통계처리 목록 (직책별)");
				setQuery("SELECT");
				setQuery("	stat_year, stat_month, jik_cd");
				setQuery("FROM");
				setQuery("	jovt_stat_pconoff_jikjong");
				setQuery("WHERE");
				setQuery("	need_recalc = 1");
				row1 = getRs();

				for (int i = 0; i < row1.getRsCount(); i++) {
					stat_year = row1.getData("stat_year", i);
					stat_month = row1.getData("stat_month", i);
					jik_cd = row1.getData("jik_cd", i);

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 계산 (직책별)");
						setQuery("SELECT");
						setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
						setQuery("	, COALESCE(pc_on_emp_cnt, 0) AS pc_on_emp_cnt");
						setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
						setQuery("	, COALESCE(pc_off_emp_cnt, 0) AS pc_off_emp_cnt");
						setQuery("FROM (");
						setQuery("	SELECT * FROM");
						setQuery("		-- PC ON 평균");
						setQuery("		(SELECT");
						setQuery("			S1.jik_cd AS pc_on_jik_cd");
						setQuery("			, AVG((DATE_PART('hour', S1.pc_on_dt) * 60) + DATE_PART('minute', S1.pc_on_dt)) AS pc_on_avg");
						setQuery("			, COUNT(DISTINCT(S1.emp_no)) AS pc_on_emp_cnt");
						setQuery("		FROM");
						setQuery("			(SELECT");
						setQuery("				A.emp_no, B.jik_cd");
						//setQuery("				, A.pc_on_dt");
						//setQuery("				, A.pc_off_dt");
						setQuery("				, A.log_on_dt AS pc_on_dt");
						setQuery("				, A.log_off_dt AS pc_off_dt");
						setQuery("			FROM");
						setQuery("				jovt_otcalc A");
						setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
						setQuery("				LEFT OUTER JOIN jovt_jikjong C ON B.jik_cd = C.jik_cd");
						setQuery("			WHERE");
						setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
						setQuery("				AND A.holiday_yn = 0");
						//setQuery("				AND DATE_PART('hour', A.pc_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
						//setQuery("				AND DATE_PART('hour', A.pc_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
						setQuery("				AND DATE_PART('hour', A.log_on_dt) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
						setQuery("				AND DATE_PART('hour', A.log_on_dt) < " + Const.DEFAULT_VALUE_PC_ON_ET);
						setQuery("				AND B.jik_cd = ?", jik_cd);
						setQuery("			) S1");
						setQuery("		GROUP BY");
						setQuery("			S1.jik_cd");
						setQuery("		) T1");
						setQuery("	FULL OUTER JOIN");
						setQuery("		-- PC OFF 평균");
						setQuery("		(SELECT");
						setQuery("			S2.jik_cd AS pc_off_jik_cd");
						setQuery("			, AVG((DATE_PART('hour', S2.pc_off_dt) * 60) + DATE_PART('minute', S2.pc_off_dt)) AS pc_off_avg");
						setQuery("			, COUNT(DISTINCT(S2.emp_no)) AS pc_off_emp_cnt");
						setQuery("		FROM");
						setQuery("			(SELECT");
						setQuery("				A.emp_no, B.jik_cd");
						//setQuery("				, A.pc_on_dt");
						//setQuery("				, A.pc_off_dt");
						setQuery("				, A.log_on_dt AS pc_on_dt");
						setQuery("				, A.log_off_dt AS pc_off_dt");
						setQuery("			FROM");
						setQuery("				jovt_otcalc A");
						setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
						setQuery("				LEFT OUTER JOIN jovt_jikjong C ON B.jik_cd = C.jik_cd");
						setQuery("			WHERE");
						setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
						setQuery("				AND A.holiday_yn = 0");
						//setQuery("				AND DATE_PART('hour', A.pc_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
						setQuery("				AND DATE_PART('hour', A.log_off_dt) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
						setQuery("				AND B.jik_cd = ?", jik_cd);
						setQuery("			) S2");
						setQuery("		GROUP BY");
						setQuery("			S2.jik_cd");
						setQuery("		) T2");
						setQuery("	ON T1.pc_on_jik_cd = T2.pc_off_jik_cd");
						setQuery(") T");
						row2 = getRs();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 계산 (직책별)");
						setQuery("SELECT");
						setQuery("	COALESCE(pc_on_avg, 0) AS pc_on_avg");
						setQuery("	, COALESCE(pc_on_emp_cnt, 0) AS pc_on_emp_cnt");
						setQuery("	, COALESCE(pc_off_avg, 0) AS pc_off_avg");
						setQuery("	, COALESCE(pc_off_emp_cnt, 0) AS pc_off_emp_cnt");
						setQuery("FROM (");
						setQuery("	SELECT * FROM");
						setQuery("		-- PC ON 평균");
						setQuery("		(SELECT");
						setQuery("			S1.jik_cd AS pc_on_jik_cd");
						setQuery("			, AVG((CAST(TO_CHAR(S1.pc_on_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S1.pc_on_dt, 'MI') AS INT)) AS pc_on_avg");
						setQuery("			, COUNT(DISTINCT(S1.emp_no)) AS pc_on_emp_cnt");
						setQuery("		FROM");
						setQuery("			(SELECT");
						setQuery("				A.emp_no, B.jik_cd");
						//setQuery("				, A.pc_on_dt");
						//setQuery("				, A.pc_off_dt");
						setQuery("				, A.log_on_dt AS pc_on_dt");
						setQuery("				, A.log_off_dt AS pc_off_dt");
						setQuery("			FROM");
						setQuery("				jovt_otcalc A");
						setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
						setQuery("				LEFT OUTER JOIN jovt_jikjong C ON B.jik_cd = C.jik_cd");
						setQuery("			WHERE");
						setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
						setQuery("				AND A.holiday_yn = 0");
						//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
						//setQuery("				AND CAST(TO_CHAR(A.pc_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
						setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_ON_ST);
						setQuery("				AND CAST(TO_CHAR(A.log_on_dt, 'HH24') AS INT) < " + Const.DEFAULT_VALUE_PC_ON_ET);
						setQuery("				AND B.jik_cd = ?", jik_cd);
						setQuery("			) S1");
						setQuery("		GROUP BY");
						setQuery("			S1.jik_cd");
						setQuery("		) T1");
						setQuery("	FULL OUTER JOIN");
						setQuery("		-- PC OFF 평균");
						setQuery("		(SELECT");
						setQuery("			S2.jik_cd AS pc_off_jik_cd");
						setQuery("			, AVG((CAST(TO_CHAR(S2.pc_off_dt, 'HH24') AS INT) * 60) + CAST(TO_CHAR(S2.pc_off_dt, 'MI') AS INT)) AS pc_off_avg");
						setQuery("			, COUNT(DISTINCT(S2.emp_no)) AS pc_off_emp_cnt");
						setQuery("		FROM");
						setQuery("			(SELECT");
						setQuery("				A.emp_no, B.jik_cd");
						//setQuery("				, A.pc_on_dt");
						//setQuery("				, A.pc_off_dt");
						setQuery("				, A.log_on_dt AS pc_on_dt");
						setQuery("				, A.log_off_dt AS pc_off_dt");
						setQuery("			FROM");
						setQuery("				jovt_otcalc A");
						setQuery("				LEFT OUTER JOIN jovt_member_history B ON A.cal_ymd = B.his_ymd AND A.emp_no = B.emp_no");
						setQuery("				LEFT OUTER JOIN jovt_jikjong C ON B.jik_cd = C.jik_cd");
						setQuery("			WHERE");
						setQuery("				SUBSTR(A.cal_ymd, 1, 6) = ?", stat_year + stat_month);
						setQuery("				AND A.holiday_yn = 0");
						//setQuery("				AND CAST(TO_CHAR(A.pc_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
						setQuery("				AND CAST(TO_CHAR(A.log_off_dt, 'HH24') AS INT) >= " + Const.DEFAULT_VALUE_PC_OFF_ST);
						setQuery("				AND B.jik_cd = ?", jik_cd);
						setQuery("			) S2");
						setQuery("		GROUP BY");
						setQuery("			S2.jik_cd");
						setQuery("		) T2");
						setQuery("	ON T1.pc_on_jik_cd = T2.pc_off_jik_cd");
						setQuery(") T");
						row2 = getRs();
					}

					if (row2.getRsCount() > 0) {
						pc_on_avg = row2.getData("pc_on_avg", 0);
						pc_on_emp_cnt = row2.getData("pc_on_emp_cnt", 0);
						pc_off_avg = row2.getData("pc_off_avg", 0);
						pc_off_emp_cnt = row2.getData("pc_off_emp_cnt", 0);
					} else {
						pc_on_avg = "0";
						pc_on_emp_cnt = "0";
						pc_off_avg = "0";
						pc_off_emp_cnt = "0";
					}

					if (StringUtil.isEmpty(pc_on_avg)) pc_on_avg = "0";
					if (StringUtil.isEmpty(pc_on_emp_cnt)) pc_on_emp_cnt = "0";
					if (StringUtil.isEmpty(pc_off_avg)) pc_off_avg = "0";
					if (StringUtil.isEmpty(pc_off_emp_cnt)) pc_off_emp_cnt = "0";

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 저장 (직책별)");
						setQuery("UPDATE jovt_stat_pconoff_jikjong SET");
						setQueryDouble("	pc_on_avg = ?", pc_on_avg);
						setQueryInt("	, pc_on_emp_cnt = ?", pc_on_emp_cnt);
						setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
						setQueryInt("	, pc_off_emp_cnt = ?", pc_off_emp_cnt);
						setQuery("	, change_dt = NOW()");
						setQuery("	, need_recalc = 0");
						setQuery("WHERE");
						setQuery("	stat_year = ?", stat_year);
						setQuery("	AND stat_month = ?", stat_month);
						setQuery("	AND jik_cd = ?", jik_cd);
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.11.20.01");
						setComment("PC ON/OFF 통계처리 저장 (직책별)");
						setQuery("UPDATE jovt_stat_pconoff_jikjong SET");
						setQueryDouble("	pc_on_avg = ?", pc_on_avg);
						setQueryInt("	, pc_on_emp_cnt = ?", pc_on_emp_cnt);
						setQueryDouble("	, pc_off_avg = ?", pc_off_avg);
						setQueryInt("	, pc_off_emp_cnt = ?", pc_off_emp_cnt);
						setQuery("	, change_dt = SYSDATE");
						setQuery("	, need_recalc = 0");
						setQuery("WHERE");
						setQuery("	stat_year = ?", stat_year);
						setQuery("	AND stat_month = ?", stat_month);
						setQuery("	AND jik_cd = ?", jik_cd);
						executeQuery();
					}

					// ########## 계산결과 ##########
					sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
					sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
					sb.append("\t" + (i+1) + ".jik_cd=" + jik_cd + "\n");
					sb.append("\t" + (i+1) + ".pc_on_avg=" + pc_on_avg + "\n");
					sb.append("\t" + (i+1) + ".pc_on_emp_cnt=" + pc_on_emp_cnt + "\n");
					sb.append("\t" + (i+1) + ".pc_off_avg=" + pc_off_avg + "\n");
					sb.append("\t" + (i+1) + ".pc_off_emp_cnt=" + pc_off_emp_cnt + "\n");
				}

				commitTran();

				daemon_status = "1";
				daemon_dm_dspt = "성공 (통계처리 PC ON/OFF (" + Const.DEFAULT_TITLE_JIK + "별) 완료)";
			} catch (Exception e) {
				rollbackTran();

				daemon_status = "0";
				daemon_dm_dspt = "실패 (통계처리 PC ON/OFF (" + Const.DEFAULT_TITLE_JIK + "별) 예외 : " + e.getMessage() + ")";
			} finally {
				closeConn();
			}

			daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			// ########## 로그 정보 ##########
			log += "통계처리 데몬로그\n";
			log += "\t" + "st_tm=" + daemon_st_tm + "\n";
			log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
			log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
			log += "\t" + "status=" + daemon_status + "\n";
			log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
			log += "통계처리 계산결과\n";
			log += sb.toString();

			LogUtil.info(debugKey + "########## Job Trace ##########", log);

			Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
			if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
				Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

			log = "";
			sb = new StringBuffer();
		}

		// ########## PC 연장사용 통계처리 (개인별) ##########
		daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		try {
			openConn();
			beginTran();

			/* ANSI SQL */
			setVersion("2015.11.20.01");
			setComment("PC 연장사용 통계처리 목록 (개인별)");
			setQuery("SELECT");
			setQuery("	stat_year, stat_month, emp_no, dpt_cd, pos_cd, tit_cd, jik_cd");
			setQuery("FROM");
			setQuery("	jovt_stat_otcalc_emp");
			setQuery("WHERE");
			setQuery("	need_recalc = 1");
			row1 = getRs();

			for (int i = 0; i < row1.getRsCount(); i++) {
				stat_year = row1.getData("stat_year", i);
				stat_month = row1.getData("stat_month", i);
				emp_no = row1.getData("emp_no", i);
				dpt_cd = row1.getData("dpt_cd", i);
				pos_cd = row1.getData("pos_cd", i);
				tit_cd = row1.getData("tit_cd", i);
				jik_cd = row1.getData("jik_cd", i);

				/* ANSI SQL */
				setVersion("2017.01.19.01");
				setComment("PC 연장사용 통계처리 계산 (개인별)");
				setQuery("SELECT");
				setQuery("	SUM(ot_type_1) AS over_request_cnt");
				setQuery("	, SUM(ot_type_2) AS over_request_2_cnt");
				setQuery("	, SUM(over_work_mm) AS over_request_mm");
				setQuery("	, SUM(over_acpt_mm) AS over_acpt_mm");
				setQuery("FROM");
				setQuery("	jovt_otcalc");
				setQuery("WHERE");
				setQuery("	SUBSTR(cal_ymd, 1, 6) = ?", stat_year + stat_month);
				setQuery("	AND emp_no = ?", emp_no);
				setQuery("	AND dpt_cd = ?", dpt_cd);
				setQuery("	AND pos_cd = ?", pos_cd);
				setQuery("	AND tit_cd = ?", tit_cd);
//				setQuery("	AND jik_cd = ?", jik_cd);
				setQuery("GROUP BY");
				setQuery("	emp_no");
				row2 = getRs();

				if (row2.getRsCount() > 0) {
					over_request_cnt = row2.getData("over_request_cnt", 0);
					over_request_2_cnt = row2.getData("over_request_2_cnt", 0);
					over_request_mm = row2.getData("over_request_mm", 0);
					over_acpt_mm = row2.getData("over_acpt_mm", 0);
				} else {
					over_request_cnt = "0";
					over_request_2_cnt = "0";
					over_request_mm = "0";
					over_acpt_mm = "0";
				}

				if (StringUtil.isEmpty(over_request_cnt)) over_request_cnt = "0";
				if (StringUtil.isEmpty(over_request_2_cnt)) over_request_2_cnt = "0";
				if (StringUtil.isEmpty(over_request_mm)) over_request_mm = "0";
				if (StringUtil.isEmpty(over_acpt_mm)) over_acpt_mm = "0";

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.11.20.01");
					setComment("PC 연장사용 통계처리 저장 (개인별)");
					setQuery("UPDATE jovt_stat_otcalc_emp SET");
					setQueryInt("	over_request_cnt = ?", over_request_cnt);
					setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
					setQueryInt("	, over_request_mm = ?", over_request_mm);
					setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
					setQuery("	, change_dt = NOW()");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND emp_no = ?", emp_no);
					setQuery("	AND dpt_cd = ?", dpt_cd);
					setQuery("	AND pos_cd = ?", pos_cd);
					setQuery("	AND tit_cd = ?", tit_cd);
//					setQuery("	AND jik_cd = ?", jik_cd);
					executeQuery();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.11.20.01");
					setComment("PC 연장사용 통계처리 저장 (개인별)");
					setQuery("UPDATE jovt_stat_otcalc_emp SET");
					setQueryInt("	over_request_cnt = ?", over_request_cnt);
					setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
					setQueryInt("	, over_request_mm = ?", over_request_mm);
					setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
					setQuery("	, change_dt = SYSDATE");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND emp_no = ?", emp_no);
					setQuery("	AND dpt_cd = ?", dpt_cd);
					setQuery("	AND pos_cd = ?", pos_cd);
					setQuery("	AND tit_cd = ?", tit_cd);
//					setQuery("	AND jik_cd = ?", jik_cd);
					executeQuery();
				}

				// ########## 계산결과 ##########
				sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
				sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
				sb.append("\t" + (i+1) + ".emp_no=" + emp_no + "\n");
				sb.append("\t" + (i+1) + ".dpt_cd=" + dpt_cd + "\n");
				sb.append("\t" + (i+1) + ".pos_cd=" + pos_cd + "\n");
				sb.append("\t" + (i+1) + ".tit_cd=" + tit_cd + "\n");
				sb.append("\t" + (i+1) + ".jik_cd=" + jik_cd + "\n");
				sb.append("\t" + (i+1) + ".over_request_cnt=" + over_request_cnt + "\n");
				sb.append("\t" + (i+1) + ".over_request_2_cnt=" + over_request_2_cnt + "\n");
				sb.append("\t" + (i+1) + ".over_request_mm=" + over_request_mm + "\n");
				sb.append("\t" + (i+1) + ".over_acpt_mm=" + over_acpt_mm + "\n");
			}

			commitTran();

			daemon_status = "1";
			daemon_dm_dspt = "성공 (통계처리 PC 연장사용 (개인별) 완료)";
		} catch (Exception e) {
			rollbackTran();

			daemon_status = "0";
			daemon_dm_dspt = "실패 (통계처리 PC 연장사용 (개인별) 예외 : " + e.getMessage() + ")";
		} finally {
			closeConn();
		}

		daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		// ########## 로그 정보 ##########
		log += "통계처리 데몬로그\n";
		log += "\t" + "st_tm=" + daemon_st_tm + "\n";
		log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
		log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
		log += "\t" + "status=" + daemon_status + "\n";
		log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
		log += "통계처리 계산결과\n";
		log += sb.toString();

		LogUtil.info(debugKey + "########## Job Trace ##########", log);

		Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
			Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

		log = "";
		sb = new StringBuffer();

		// ########## PC 연장사용 통계처리 (부서별) ##########
		daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		try {
			openConn();
			beginTran();

			/* ANSI SQL */
			setVersion("2015.05.28.01");
			setComment("PC 연장사용 통계처리 목록 (부서별)");
			setQuery("SELECT");
			setQuery("	stat_year, stat_month, dpt_cd");
			setQuery("FROM");
			setQuery("	jovt_stat_otcalc_dpt");
			setQuery("WHERE");
			setQuery("	need_recalc = 1");
			row1 = getRs();

			for (int i = 0; i < row1.getRsCount(); i++) {
				stat_year = row1.getData("stat_year", i);
				stat_month = row1.getData("stat_month", i);
				dpt_cd = row1.getData("dpt_cd", i);

				/* ANSI SQL */
				setVersion("2017.01.19.01");
				setComment("PC 연장사용 통계처리 계산 (부서별)");
				setQuery("SELECT");
				setQuery("	SUM(ot_type_1) AS over_request_cnt");
				setQuery("	, SUM(ot_type_2) AS over_request_2_cnt");
				setQuery("	, SUM(over_work_mm) AS over_request_mm");
				setQuery("	, SUM(over_acpt_mm) AS over_acpt_mm");
				setQuery("FROM");
				setQuery("	jovt_otcalc");
				setQuery("WHERE");
				setQuery("	SUBSTR(cal_ymd, 1, 6) = ?", stat_year + stat_month);
				setQuery("	AND dpt_cd = ?", dpt_cd);
				setQuery("GROUP BY");
				setQuery("	dpt_cd");
				row2 = getRs();

				if (row2.getRsCount() > 0) {
					over_request_cnt = row2.getData("over_request_cnt", 0);
					over_request_2_cnt = row2.getData("over_request_2_cnt", 0);
					over_request_mm = row2.getData("over_request_mm", 0);
					over_acpt_mm = row2.getData("over_acpt_mm", 0);
				} else {
					over_request_cnt = "0";
					over_request_2_cnt = "0";
					over_request_mm = "0";
					over_acpt_mm = "0";
				}

				if (StringUtil.isEmpty(over_request_cnt)) over_request_cnt = "0";
				if (StringUtil.isEmpty(over_request_2_cnt)) over_request_2_cnt = "0";
				if (StringUtil.isEmpty(over_request_mm)) over_request_mm = "0";
				if (StringUtil.isEmpty(over_acpt_mm)) over_acpt_mm = "0";

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.05.28.01");
					setComment("PC 연장사용 통계처리 저장 (부서별)");
					setQuery("UPDATE jovt_stat_otcalc_dpt SET");
					setQueryInt("	over_request_cnt = ?", over_request_cnt);
					setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
					setQueryInt("	, over_request_mm = ?", over_request_mm);
					setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
					setQuery("	, change_dt = NOW()");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND dpt_cd = ?", dpt_cd);
					executeQuery();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.05.28.01");
					setComment("PC 연장사용 통계처리 저장 (부서별)");
					setQuery("UPDATE jovt_stat_otcalc_dpt SET");
					setQueryInt("	over_request_cnt = ?", over_request_cnt);
					setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
					setQueryInt("	, over_request_mm = ?", over_request_mm);
					setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
					setQuery("	, change_dt = SYSDATE");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND dpt_cd = ?", dpt_cd);
					executeQuery();
				}

				// ########## 계산결과 ##########
				sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
				sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
				sb.append("\t" + (i+1) + ".dpt_cd=" + dpt_cd + "\n");
				sb.append("\t" + (i+1) + ".over_request_cnt=" + over_request_cnt + "\n");
				sb.append("\t" + (i+1) + ".over_request_2_cnt=" + over_request_2_cnt + "\n");
				sb.append("\t" + (i+1) + ".over_request_mm=" + over_request_mm + "\n");
				sb.append("\t" + (i+1) + ".over_acpt_mm=" + over_acpt_mm + "\n");
			}

			commitTran();

			daemon_status = "1";
			daemon_dm_dspt = "성공 (통계처리 PC 연장사용 (부서별) 완료)";
		} catch (Exception e) {
			rollbackTran();

			daemon_status = "0";
			daemon_dm_dspt = "실패 (통계처리 PC 연장사용 (부서별) 예외 : " + e.getMessage() + ")";
		} finally {
			closeConn();
		}

		daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		// ########## 로그 정보 ##########
		log += "통계처리 데몬로그\n";
		log += "\t" + "st_tm=" + daemon_st_tm + "\n";
		log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
		log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
		log += "\t" + "status=" + daemon_status + "\n";
		log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
		log += "통계처리 계산결과\n";
		log += sb.toString();

		LogUtil.info(debugKey + "########## Job Trace ##########", log);

		Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
			Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

		log = "";
		sb = new StringBuffer();

		// ########## PC 연장사용 통계처리 (직급별) ##########
		daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		try {
			openConn();
			beginTran();

			/* ANSI SQL */
			setVersion("2015.05.28.01");
			setComment("PC 연장사용 통계처리 목록 (직급별)");
			setQuery("SELECT");
			setQuery("	stat_year, stat_month, pos_cd");
			setQuery("FROM");
			setQuery("	jovt_stat_otcalc_position");
			setQuery("WHERE");
			setQuery("	need_recalc = 1");
			row1 = getRs();

			for (int i = 0; i < row1.getRsCount(); i++) {
				stat_year = row1.getData("stat_year", i);
				stat_month = row1.getData("stat_month", i);
				pos_cd = row1.getData("pos_cd", i);

				/* ANSI SQL */
				setVersion("2017.01.19.01");
				setComment("PC 연장사용 통계처리 계산 (직급별)");
				setQuery("SELECT");
				setQuery("	SUM(ot_type_1) AS over_request_cnt");
				setQuery("	, SUM(ot_type_2) AS over_request_2_cnt");
				setQuery("	, SUM(over_work_mm) AS over_request_mm");
				setQuery("	, SUM(over_acpt_mm) AS over_acpt_mm");
				setQuery("FROM");
				setQuery("	jovt_otcalc");
				setQuery("WHERE");
				setQuery("	SUBSTR(cal_ymd, 1, 6) = ?", stat_year + stat_month);
				setQuery("	AND pos_cd = ?", pos_cd);
				setQuery("GROUP BY");
				setQuery("	pos_cd");
				row2 = getRs();

				if (row2.getRsCount() > 0) {
					over_request_cnt = row2.getData("over_request_cnt", 0);
					over_request_2_cnt = row2.getData("over_request_2_cnt", 0);
					over_request_mm = row2.getData("over_request_mm", 0);
					over_acpt_mm = row2.getData("over_acpt_mm", 0);
				} else {
					over_request_cnt = "0";
					over_request_2_cnt = "0";
					over_request_mm = "0";
					over_acpt_mm = "0";
				}

				if (StringUtil.isEmpty(over_request_cnt)) over_request_cnt = "0";
				if (StringUtil.isEmpty(over_request_2_cnt)) over_request_2_cnt = "0";
				if (StringUtil.isEmpty(over_request_mm)) over_request_mm = "0";
				if (StringUtil.isEmpty(over_acpt_mm)) over_acpt_mm = "0";

				if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
					/* POSTGRESQL */
					setVersion("2015.05.28.01");
					setComment("PC 연장사용 통계처리 저장 (직급별)");
					setQuery("UPDATE jovt_stat_otcalc_position SET");
					setQueryInt("	over_request_cnt = ?", over_request_cnt);
					setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
					setQueryInt("	, over_request_mm = ?", over_request_mm);
					setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
					setQuery("	, change_dt = NOW()");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND pos_cd = ?", pos_cd);
					executeQuery();
				} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
					/* ORACLE */
					setVersion("2015.05.28.01");
					setComment("PC 연장사용 통계처리 저장 (직급별)");
					setQuery("UPDATE jovt_stat_otcalc_position SET");
					setQueryInt("	over_request_cnt = ?", over_request_cnt);
					setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
					setQueryInt("	, over_request_mm = ?", over_request_mm);
					setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
					setQuery("	, change_dt = SYSDATE");
					setQuery("	, need_recalc = 0");
					setQuery("WHERE");
					setQuery("	stat_year = ?", stat_year);
					setQuery("	AND stat_month = ?", stat_month);
					setQuery("	AND pos_cd = ?", pos_cd);
					executeQuery();
				}

				// ########## 계산결과 ##########
				sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
				sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
				sb.append("\t" + (i+1) + ".pos_cd=" + pos_cd + "\n");
				sb.append("\t" + (i+1) + ".over_request_cnt=" + over_request_cnt + "\n");
				sb.append("\t" + (i+1) + ".over_request_2_cnt=" + over_request_2_cnt + "\n");
				sb.append("\t" + (i+1) + ".over_request_mm=" + over_request_mm + "\n");
				sb.append("\t" + (i+1) + ".over_acpt_mm=" + over_acpt_mm + "\n");
			}

			commitTran();

			daemon_status = "1";
			daemon_dm_dspt = "성공 (통계처리 PC 연장사용 (" + Const.DEFAULT_TITLE_POS + "별) 완료)";
		} catch (Exception e) {
			rollbackTran();

			daemon_status = "0";
			daemon_dm_dspt = "실패 (통계처리 PC 연장사용 (" + Const.DEFAULT_TITLE_POS + "별) 예외 : " + e.getMessage() + ")";
		} finally {
			closeConn();
		}

		daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		// ########## 로그 정보 ##########
		log += "통계처리 데몬로그\n";
		log += "\t" + "st_tm=" + daemon_st_tm + "\n";
		log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
		log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
		log += "\t" + "status=" + daemon_status + "\n";
		log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
		log += "통계처리 계산결과\n";
		log += sb.toString();

		LogUtil.info(debugKey + "########## Job Trace ##########", log);

		Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
			Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

		log = "";
		sb = new StringBuffer();

		// ########## PC 연장사용 통계처리 (직위별) ##########
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_TIT, "Y")) {
			daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			try {
				openConn();
				beginTran();

				/* ANSI SQL */
				setVersion("2015.11.20.01");
				setComment("PC 연장사용 통계처리 목록 (직위별)");
				setQuery("SELECT");
				setQuery("	stat_year, stat_month, tit_cd");
				setQuery("FROM");
				setQuery("	jovt_stat_otcalc_title");
				setQuery("WHERE");
				setQuery("	need_recalc = 1");
				row1 = getRs();

				for (int i = 0; i < row1.getRsCount(); i++) {
					stat_year = row1.getData("stat_year", i);
					stat_month = row1.getData("stat_month", i);
					tit_cd = row1.getData("tit_cd", i);

					/* ANSI SQL */
					setVersion("2017.01.19.01");
					setComment("PC 연장사용 통계처리 계산 (직위별)");
					setQuery("SELECT");
					setQuery("	SUM(ot_type_1) AS over_request_cnt");
					setQuery("	, SUM(ot_type_2) AS over_request_2_cnt");
					setQuery("	, SUM(over_work_mm) AS over_request_mm");
					setQuery("	, SUM(over_acpt_mm) AS over_acpt_mm");
					setQuery("FROM");
					setQuery("	jovt_otcalc");
					setQuery("WHERE");
					setQuery("	SUBSTR(cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("	AND tit_cd = ?", tit_cd);
					setQuery("GROUP BY");
					setQuery("	tit_cd");
					row2 = getRs();

					if (row2.getRsCount() > 0) {
						over_request_cnt = row2.getData("over_request_cnt", 0);
						over_request_2_cnt = row2.getData("over_request_2_cnt", 0);
						over_request_mm = row2.getData("over_request_mm", 0);
						over_acpt_mm = row2.getData("over_acpt_mm", 0);
					} else {
						over_request_cnt = "0";
						over_request_2_cnt = "0";
						over_request_mm = "0";
						over_acpt_mm = "0";
					}

					if (StringUtil.isEmpty(over_request_cnt)) over_request_cnt = "0";
					if (StringUtil.isEmpty(over_request_2_cnt)) over_request_2_cnt = "0";
					if (StringUtil.isEmpty(over_request_mm)) over_request_mm = "0";
					if (StringUtil.isEmpty(over_acpt_mm)) over_acpt_mm = "0";

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.11.20.01");
						setComment("PC 연장사용 통계처리 저장 (직위별)");
						setQuery("UPDATE jovt_stat_otcalc_title SET");
						setQueryInt("	over_request_cnt = ?", over_request_cnt);
						setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
						setQueryInt("	, over_request_mm = ?", over_request_mm);
						setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
						setQuery("	, change_dt = NOW()");
						setQuery("	, need_recalc = 0");
						setQuery("WHERE");
						setQuery("	stat_year = ?", stat_year);
						setQuery("	AND stat_month = ?", stat_month);
						setQuery("	AND tit_cd = ?", tit_cd);
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.11.20.01");
						setComment("PC 연장사용 통계처리 저장 (직위별)");
						setQuery("UPDATE jovt_stat_otcalc_title SET");
						setQueryInt("	over_request_cnt = ?", over_request_cnt);
						setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
						setQueryInt("	, over_request_mm = ?", over_request_mm);
						setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
						setQuery("	, change_dt = SYSDATE");
						setQuery("	, need_recalc = 0");
						setQuery("WHERE");
						setQuery("	stat_year = ?", stat_year);
						setQuery("	AND stat_month = ?", stat_month);
						setQuery("	AND tit_cd = ?", tit_cd);
						executeQuery();
					}

					// ########## 계산결과 ##########
					sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
					sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
					sb.append("\t" + (i+1) + ".tit_cd=" + tit_cd + "\n");
					sb.append("\t" + (i+1) + ".over_request_cnt=" + over_request_cnt + "\n");
					sb.append("\t" + (i+1) + ".over_request_2_cnt=" + over_request_2_cnt + "\n");
					sb.append("\t" + (i+1) + ".over_request_mm=" + over_request_mm + "\n");
					sb.append("\t" + (i+1) + ".over_acpt_mm=" + over_acpt_mm + "\n");
				}

				commitTran();

				daemon_status = "1";
				daemon_dm_dspt = "성공 (통계처리 PC 연장사용 (" + Const.DEFAULT_TITLE_TIT + "별) 완료)";
			} catch (Exception e) {
				rollbackTran();

				daemon_status = "0";
				daemon_dm_dspt = "실패 (통계처리 PC 연장사용 (" + Const.DEFAULT_TITLE_TIT + "별) 예외 : " + e.getMessage() + ")";
			} finally {
				closeConn();
			}

			daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			// ########## 로그 정보 ##########
			log += "통계처리 데몬로그\n";
			log += "\t" + "st_tm=" + daemon_st_tm + "\n";
			log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
			log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
			log += "\t" + "status=" + daemon_status + "\n";
			log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
			log += "통계처리 계산결과\n";
			log += sb.toString();

			LogUtil.info(debugKey + "########## Job Trace ##########", log);

			Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
			if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
				Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

			log = "";
			sb = new StringBuffer();
		}

		// ########## PC 연장사용 통계처리 (직책별) ##########
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_JIK, "Y")) {
			daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			try {
				openConn();
				beginTran();

				/* ANSI SQL */
				setVersion("2015.11.20.01");
				setComment("PC 연장사용 통계처리 목록 (직책별)");
				setQuery("SELECT");
				setQuery("	stat_year, stat_month, jik_cd");
				setQuery("FROM");
				setQuery("	jovt_stat_otcalc_jikjong");
				setQuery("WHERE");
				setQuery("	need_recalc = 1");
				row1 = getRs();

				for (int i = 0; i < row1.getRsCount(); i++) {
					stat_year = row1.getData("stat_year", i);
					stat_month = row1.getData("stat_month", i);
					jik_cd = row1.getData("jik_cd", i);

					/* ANSI SQL */
					setVersion("2017.01.19.01");
					setComment("PC 연장사용 통계처리 계산 (직책별)");
					setQuery("SELECT");
					setQuery("	SUM(ot_type_1) AS over_request_cnt");
					setQuery("	, SUM(ot_type_2) AS over_request_2_cnt");
					setQuery("	, SUM(over_work_mm) AS over_request_mm");
					setQuery("	, SUM(over_acpt_mm) AS over_acpt_mm");
					setQuery("FROM");
					setQuery("	jovt_otcalc");
					setQuery("WHERE");
					setQuery("	SUBSTR(cal_ymd, 1, 6) = ?", stat_year + stat_month);
					setQuery("	AND jik_cd = ?", jik_cd);
					setQuery("GROUP BY");
					setQuery("	jik_cd");
					row2 = getRs();

					if (row2.getRsCount() > 0) {
						over_request_cnt = row2.getData("over_request_cnt", 0);
						over_request_2_cnt = row2.getData("over_request_2_cnt", 0);
						over_request_mm = row2.getData("over_request_mm", 0);
						over_acpt_mm = row2.getData("over_acpt_mm", 0);
					} else {
						over_request_cnt = "0";
						over_request_2_cnt = "0";
						over_request_mm = "0";
						over_acpt_mm = "0";
					}

					if (StringUtil.isEmpty(over_request_cnt)) over_request_cnt = "0";
					if (StringUtil.isEmpty(over_request_2_cnt)) over_request_2_cnt = "0";
					if (StringUtil.isEmpty(over_request_mm)) over_request_mm = "0";
					if (StringUtil.isEmpty(over_acpt_mm)) over_acpt_mm = "0";

					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.11.20.01");
						setComment("PC 연장사용 통계처리 저장 (직책별)");
						setQuery("UPDATE jovt_stat_otcalc_jikjong SET");
						setQueryInt("	over_request_cnt = ?", over_request_cnt);
						setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
						setQueryInt("	, over_request_mm = ?", over_request_mm);
						setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
						setQuery("	, change_dt = NOW()");
						setQuery("	, need_recalc = 0");
						setQuery("WHERE");
						setQuery("	stat_year = ?", stat_year);
						setQuery("	AND stat_month = ?", stat_month);
						setQuery("	AND jik_cd = ?", jik_cd);
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.11.20.01");
						setComment("PC 연장사용 통계처리 저장 (직책별)");
						setQuery("UPDATE jovt_stat_otcalc_jikjong SET");
						setQueryInt("	over_request_cnt = ?", over_request_cnt);
						setQueryInt("	, over_request_2_cnt = ?", over_request_2_cnt);
						setQueryInt("	, over_request_mm = ?", over_request_mm);
						setQueryInt("	, over_acpt_mm = ?", over_acpt_mm);
						setQuery("	, change_dt = SYSDATE");
						setQuery("	, need_recalc = 0");
						setQuery("WHERE");
						setQuery("	stat_year = ?", stat_year);
						setQuery("	AND stat_month = ?", stat_month);
						setQuery("	AND jik_cd = ?", jik_cd);
						executeQuery();
					}

					// ########## 계산결과 ##########
					sb.append("\t" + (i+1) + ".stat_year=" + stat_year + "\n");
					sb.append("\t" + (i+1) + ".stat_month=" + stat_month + "\n");
					sb.append("\t" + (i+1) + ".jik_cd=" + jik_cd + "\n");
					sb.append("\t" + (i+1) + ".over_request_cnt=" + over_request_cnt + "\n");
					sb.append("\t" + (i+1) + ".over_request_2_cnt=" + over_request_2_cnt + "\n");
					sb.append("\t" + (i+1) + ".over_request_mm=" + over_request_mm + "\n");
					sb.append("\t" + (i+1) + ".over_acpt_mm=" + over_acpt_mm + "\n");
				}

				commitTran();

				daemon_status = "1";
				daemon_dm_dspt = "성공 (통계처리 PC 연장사용 (" + Const.DEFAULT_TITLE_JIK + "별) 완료)";
			} catch (Exception e) {
				rollbackTran();

				daemon_status = "0";
				daemon_dm_dspt = "실패 (통계처리 PC 연장사용 (" + Const.DEFAULT_TITLE_JIK + "별) 예외 : " + e.getMessage() + ")";
			} finally {
				closeConn();
			}

			daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

			// ########## 로그 정보 ##########
			log += "통계처리 데몬로그\n";
			log += "\t" + "st_tm=" + daemon_st_tm + "\n";
			log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
			log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
			log += "\t" + "status=" + daemon_status + "\n";
			log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
			log += "통계처리 계산결과\n";
			log += sb.toString();

			LogUtil.info(debugKey + "########## Job Trace ##########", log);

			Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
			if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
				Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);

			log = "";
			sb = new StringBuffer();
		}

		// ########## 일시사용 통계처리 ##########
		daemon_st_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		try {
			openConn();
			beginTran();

			if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
				/* POSTGRESQL */
				setVersion("2015.11.19.01");
				setComment("일시사용 통계처리 목록");
				setQuery("SELECT");
				setQuery("	seqno");
				setQuery("	, CASE");
				setQuery("		WHEN sta_hm > end_hm THEN");
				setQuery("			(DATE_PART('day', (end_hm + INTERVAL '1' day) - sta_hm) * 24 * 60)");
				setQuery("			+ (DATE_PART('hour', (end_hm + INTERVAL '1' day) - sta_hm) * 60)");
				setQuery("			+ DATE_PART('minute', (end_hm + INTERVAL '1' day) - sta_hm)");
				setQuery("		ELSE");
				setQuery("			(DATE_PART('day', end_hm - sta_hm) * 24 * 60)");
				setQuery("			+ (DATE_PART('hour', end_hm - sta_hm) * 60)");
				setQuery("			+ DATE_PART('minute', end_hm - sta_hm)");
				setQuery("		END AS sum_mm");
				setQuery("FROM");
				setQuery("	(SELECT");
				setQuery("		seqno");
				setQuery("		, TO_TIMESTAMP(SUBSTR(work_ymd, 1, 4) || '-' ||");
				setQuery("		SUBSTR(work_ymd, 5, 2) || '-' ||");
				setQuery("		SUBSTR(work_ymd, 7, 2) || ' ' ||");
				setQuery("		SUBSTR(sta_hm, 1, 2) || ':' ||");
				setQuery("		SUBSTR(sta_hm, 3, 2) || ':00', 'YYYY-MM-DD HH24:MI:SS.US') AS sta_hm");
				setQuery("		, TO_TIMESTAMP(SUBSTR(work_ymd, 1, 4) || '-' ||");
				setQuery("		SUBSTR(work_ymd, 5, 2) || '-' ||");
				setQuery("		SUBSTR(work_ymd, 7, 2) || ' ' ||");
				setQuery("		SUBSTR(end_hm, 1, 2) || ':' ||");
				setQuery("		SUBSTR(end_hm, 3, 2) || ':00', 'YYYY-MM-DD HH24:MI:SS.US') AS end_hm");
				setQuery("	FROM");
				setQuery("		jovt_onetime_use");
				setQuery("	WHERE");
				setQuery("		need_recalc = 1");
				setQuery("	) T");
				row1 = getRs();
			} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
				/* ORACLE */
				setVersion("2015.11.19.01");
				setComment("일시사용 통계처리 목록");
				setQuery("SELECT");
				setQuery("	seqno");
				setQuery("	, CASE");
				setQuery("		WHEN sta_hm > end_hm THEN");
				setQuery("			TRUNC(ROUND(((end_hm + INTERVAL '1' day) - sta_hm) * 24 * 60 * 60) / 60)");
				setQuery("		ELSE");
				setQuery("			TRUNC(ROUND((end_hm - sta_hm) * 24 * 60 * 60) / 60)");
				setQuery("		END AS sum_mm");
				setQuery("FROM");
				setQuery("	(SELECT");
				setQuery("		seqno");
				setQuery("		, TO_DATE(SUBSTR(work_ymd, 1, 4) || '-' ||");
				setQuery("		SUBSTR(work_ymd, 5, 2) || '-' ||");
				setQuery("		SUBSTR(work_ymd, 7, 2) || ' ' ||");
				setQuery("		SUBSTR(sta_hm, 1, 2) || ':' ||");
				setQuery("		SUBSTR(sta_hm, 3, 2) || ':00', 'YYYY-MM-DD HH24:MI:SS') AS sta_hm");
				setQuery("		, TO_DATE(SUBSTR(work_ymd, 1, 4) || '-' ||");
				setQuery("		SUBSTR(work_ymd, 5, 2) || '-' ||");
				setQuery("		SUBSTR(work_ymd, 7, 2) || ' ' ||");
				setQuery("		SUBSTR(end_hm, 1, 2) || ':' ||");
				setQuery("		SUBSTR(end_hm, 3, 2) || ':00', 'YYYY-MM-DD HH24:MI:SS') AS end_hm");
				setQuery("	FROM");
				setQuery("		jovt_onetime_use");
				setQuery("	WHERE");
				setQuery("		need_recalc = 1");
				setQuery("	) T");
				row1 = getRs();
			}

			for (int i = 0; i < row1.getRsCount(); i++) {
				String seqno = row1.getData("seqno", i);
				String sum_mm = row1.getData("sum_mm", i);

				/* ANSI SQL */
				setVersion("2015.11.19.01");
				setComment("일시사용 통계처리 저장");
				setQuery("UPDATE jovt_onetime_use SET");
				setQuery("	sum_mm = ?");
				setQuery("	, need_recalc = 0");
				setQuery("WHERE");
				setQuery("	seqno = ?");
				setParamInt(sum_mm);
				setParamInt(seqno);
				executeQuery();
			}

			commitTran();

			daemon_status = "1";
			daemon_dm_dspt = "성공 (통계처리 일시사용 완료)";
		} catch (Exception e) {
			rollbackTran();

			daemon_status = "0";
			daemon_dm_dspt = "실패 (통계처리 일시사용 예외 : " + e.getMessage() + ")";
		} finally {
			closeConn();
		}

		daemon_ed_tm = DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS");

		// ########## 로그 정보 ##########
		log += "통계처리 데몬로그\n";
		log += "\t" + "st_tm=" + daemon_st_tm + "\n";
		log += "\t" + "ed_tm=" + daemon_ed_tm + "\n";
		log += "\t" + "dm_nm=" + daemon_dm_nm + "\n";
		log += "\t" + "status=" + daemon_status + "\n";
		log += "\t" + "dm_dspt=" + daemon_dm_dspt + "\n";
		log += "통계처리 계산결과\n";
		log += sb.toString();

		LogUtil.info(debugKey + "########## Job Trace ##########", log);

		/*
		Log(daemon_st_tm, daemon_ed_tm, daemon_dm_nm, daemon_status, daemon_dm_dspt);
		if (StringUtil.isEquals(Const.DEFAULT_OPTION_SMTP, "Y"))
			Mail(daemon_dm_nm, daemon_status, daemon_dm_dspt);
		*/

		log = "";
		sb = new StringBuffer();
	}

	private void Log(String daemon_st_tm, String daemon_ed_tm, String daemon_dm_nm, String daemon_status, String daemon_dm_dspt) throws DBWorkerException, ResultObjectException {
		if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
			/* POSTGRESQL */
			setVersion("2015.05.27.01");
			setComment("데몬로그 저장");
			setQuery("INSERT INTO jovt_daemon_log");
			setQuery("	(st_tm, ed_tm, dm_nm, status, dm_dspt)");
			setQuery("VALUES");
			setQuery("	(TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US'), TO_TIMESTAMP(?, 'YYYY-MM-DD HH24:MI:SS.US'), ?, ?, ?)");
			setParam(daemon_st_tm);
			setParam(daemon_ed_tm);
			setParam(daemon_dm_nm);
			setParamInt(daemon_status);
			setParam(daemon_dm_dspt);
			executeQuery();
		} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
			/* ORACLE */
			setVersion("2015.05.27.01");
			setComment("데몬로그 저장");
			setQuery("INSERT INTO jovt_daemon_log");
			setQuery("	(st_tm, ed_tm, dm_nm, status, dm_dspt)");
			setQuery("VALUES");
			setQuery("	(TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS'), TO_DATE(SUBSTR(?, 1, 19), 'YYYY-MM-DD HH24:MI:SS'), ?, ?, ?)");
			setParam(daemon_st_tm);
			setParam(daemon_ed_tm);
			setParam(daemon_dm_nm);
			setParamInt(daemon_status);
			setParam(daemon_dm_dspt);
			executeQuery();
		}
	}

	private void Mail(String daemon_dm_nm, String daemon_status, String daemon_dm_dspt) throws DBWorkerException, ResultObjectException {
		if (StringUtil.isEquals(daemon_status, "0")) {
			String mail_title = "[" + Const.DEFAULT_SITE_NAME + "] " + Const.DEFAULT_PRODUCT_NAME + "-" + daemon_dm_nm + " 데몬에러";
			String mail_contents = daemon_dm_nm + "<br /><br />" + daemon_dm_dspt;
			String send_emp_no = Const.DEFAULT_SYSTEM_CODE;
			String send_emp_nm = Const.DEFAULT_SYSTEM_NAME;
			String send_mail = Const.DEFAULT_EMAIL_SYSTEM;
			String recv_mail = "";

			/* ANSI SQL */
			setVersion("2015.05.27.01");
			setComment("이메일 정보");
			setQuery("SELECT");
			setQuery("	daemon_email");
			setQuery("FROM");
			setQuery("	jovt_system");
			ResultObject row = getRs();

			if (row.getRsCount() > 0) {
				recv_mail = row.getData("daemon_email", 0);
			}

			String[] arr = recv_mail.split(";");
			for (int i = 0; i < arr.length; i++) {
				if (!StringUtil.isEmpty(StringUtil.trim(arr[i]))) {
					if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "postgresql")) {
						/* POSTGRESQL */
						setVersion("2015.05.27.01");
						setComment("이메일 발송");
						setQuery("INSERT INTO jovt_mail_list");
						setQuery("	(mail_title, mail_contents, send_emp_no, send_emp_nm, send_mail, recv_emp_no, recv_emp_nm, recv_mail, reg_dt, mail_type)");
						setQuery("VALUES");
						setQuery("	(?, ?, ?, ?, ?, '', '', ?, NOW(), 1)");
						setParam(mail_title);
						setParam(mail_contents);
						setParam(send_emp_no);
						setParam(send_emp_nm);
						setParam(send_mail);
						setParam(StringUtil.trim(arr[i]));
						executeQuery();
					} else if (StringUtil.isEquals(Const.DEFAULT_DATABASE_TYPE, "oracle")) {
						/* ORACLE */
						setVersion("2015.05.27.01");
						setComment("이메일 발송");
						setQuery("INSERT INTO jovt_mail_list");
						setQuery("	(mail_title, mail_contents, send_emp_no, send_emp_nm, send_mail, recv_emp_no, recv_emp_nm, recv_mail, reg_dt, mail_type)");
						setQuery("VALUES");
						setQuery("	(?, ?, ?, ?, ?, NULL, NULL, ?, SYSDATE, 1)");
						setParam(mail_title);
						setParam(mail_contents);
						setParam(send_emp_no);
						setParam(send_emp_nm);
						setParam(send_mail);
						setParam(StringUtil.trim(arr[i]));
						executeQuery();
					}
				}
			}
		}
	}
}