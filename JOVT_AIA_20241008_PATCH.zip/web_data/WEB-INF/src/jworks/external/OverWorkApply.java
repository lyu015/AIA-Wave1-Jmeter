package jworks.external;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jworks.util.DateUtil;
import jworks.util.LogUtil;
import jworks.util.StringUtil;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

@WebServlet("/external/overwork/V1/owapply")
public class OverWorkApply extends HttpServlet {

	/**
	 * 디폴트 시리얼
	 */
	private static final long serialVersionUID = 1L;

	// 해당 요청은 POST로만 받음
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		LogUtil.error("OverWorkApply Start =====> "+DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS"));

		Map<String, Object> map = new HashMap<String, Object>();
		JSONParser jsonparser = new JSONParser();

		response.setContentType("application/json; charset=UTF-8");

		String requestContentType = request.getContentType();

		//Request ContentType Validation -> application/json이 아닐 경우 에러 리턴
		if (!requestContentType.contains("application/json")) {
			response.setStatus(400);
			map.put("httpStatus", "400");
			map.put("reasonCode", "001");
			map.put("reason", "Validation Error");
			map.put("message", "Not Support ContentType!!");

			setResponse(response, map);
			return;
		}


		try {

			StringBuffer bfStr = new StringBuffer();

			String line = null;

			// 리퀘스트 바디에서 데이터를 읽어 오는 부분
			BufferedReader reader = request.getReader();
			Map<String, Object> param = new HashMap<String, Object>();

			// 읽어온 값을 버퍼에 저장
			while ((line = reader.readLine()) != null) {
				bfStr.append(line);
			}

			JSONObject jsobj = (JSONObject) jsonparser.parse(bfStr.toString());

			// JSONObject Key 값을 받아옴
			@SuppressWarnings("unchecked")
			Set<String> keySet = jsobj.keySet();

			// 해당 key 값으로 돌며 value 값을 찾아서 map에 저장
			for (String key : keySet) {
				Object value = jsobj.get(key);
				param.put(key, value);
			}


			if (!param.isEmpty()) {
				String empNo = String.valueOf(param.get("empNo")).replace("null", "");
				String workYmd = String.valueOf(param.get("workYmd")).replace("null", "");
				Integer otType = Integer.parseInt(String.valueOf(param.get("otType")).replace("null", "-1"));
				String staYmd = String.valueOf(param.get("staYmd")).replace("null", "");
				String staHm = String.valueOf(param.get("staHm")).replace("null", "");
				String endYmd = String.valueOf(param.get("endYmd")).replace("null", "");
				String endHm = String.valueOf(param.get("endHm")).replace("null", "");
				String otDesc = String.valueOf(param.get("otDesc")).replace("null", "");
				Integer aprvStatus = Integer.parseInt(String.valueOf(param.get("aprvStatus")).replace("null", "-1"));
				String aprvEmpno = String.valueOf(param.get("aprvEmpno")).replace("null", "");

				// 요청 온 값 체크 -> 아래 조건에 해당하면 장애 리턴
				if (StringUtil.isEmpty(empNo) || !StringUtil.checkDate(workYmd) || (otType != 1 && otType != 2)
						|| !StringUtil.checkDate(staYmd) || !StringUtil.checkTime(staHm)
						|| !StringUtil.checkDate(endYmd) || !StringUtil.checkTime(endHm)
						|| (aprvStatus != 2 && aprvStatus != 3 && aprvStatus != 6)
						|| StringUtil.isEmpty(aprvEmpno) || checkReversalTime(param)
						) {
					response.setStatus(400);
					map.put("httpStatus", "400");
					map.put("reasonCode", "001");
					map.put("reason", "Validation Error");
					map.put("message", "Request Param Error");

					setResponse(response, map);

					//AIA생명 요청 사항
					//연장근무 현재기준 과거 데이터 API 호출시 DB Sync 대신 성공값만 리턴
				} else if(DateUtil.getDateDiff(DateUtil.getDate("yyyyMMdd"), workYmd) < 0) {
					Map<String, Object> returnMap = new HashMap<String, Object>();
					Map<String, Object> dataMap = new HashMap<String, Object>();


					dataMap.put("EMP_NO", empNo);
					dataMap.put("WORK_YMD", workYmd);
					dataMap.put("OT_TYPE", otType);
					dataMap.put("STA_YMD", staYmd);
					dataMap.put("STA_HM", staHm);
					dataMap.put("END_YMD", endYmd);
					dataMap.put("END_HM", endHm);
					dataMap.put("OT_DESC", otDesc);
					dataMap.put("APRV_STATUS", aprvStatus);
					dataMap.put("APRV_EMPNO", aprvEmpno);

					returnMap.put("data", dataMap);

					// AIA 생명 공식 API 규약 성공시 강제 200 리턴
					response.setStatus(200);
					map.put("httpStatus", "200");
					map.put("reasonCode", "000");
					map.put("reason", "");
					map.put("message", "Historical Data");
					map.put("data", returnMap.get("data"));

					setResponse(response, map);


				} else {

					Map<String, Object> retMap = new HashMap<String, Object>();

					ApiDBConnector overWorkRequest = new ApiDBConnector();

					HashMap<String, Object> employeeCheckMap = new HashMap<String, Object>();

					employeeCheckMap = overWorkRequest.checkEmployeeState(String.valueOf(param.get("empNo")));

					Boolean checkEmployeeState = Boolean.FALSE;

					if (StringUtil.isEquals(String.valueOf(employeeCheckMap.get("result_cd")), "000")) {
						checkEmployeeState = (Boolean) employeeCheckMap.get("checkState");
					} else {
						response.setStatus(400);
						map.put("httpStatus", "400");
						map.put("reasonCode", "001");
						map.put("reason", "Employee Error");
						map.put("message", "Employee Check Error");
						setResponse(response, map);
						return;
					}


					if (checkEmployeeState) {

						retMap = overWorkRequest.OverWorkSYNC(param);

						if (!retMap.isEmpty() && retMap.get("errorMsg") == null) {

							// AIA 생명 공식 API 규약 성공시 강제 200 리턴
							response.setStatus(200);
							map.put("httpStatus", "200");
							map.put("reasonCode", "000");
							map.put("reason", "");
							map.put("message", "");
							map.put("data", retMap.get("data"));
							setResponse(response, map);

						} else  {
							// 실패시 에러에 상관없이 강제 400 리턴
							response.setStatus(400);
							map.put("httpStatus", "400");
							map.put("reasonCode", "001");
							map.put("reason", "Data Error");
							map.put("message", "Data Sync Error");
							setResponse(response, map);
						}
					} else {
						// 실패시 에러에 상관없이 강제 400 리턴
						response.setStatus(400);
						map.put("httpStatus", "400");
						map.put("reasonCode", "001");
						map.put("reason", "Employee Error");
						map.put("message", "Not Exists Employee");
						setResponse(response, map);
					}
				}
			}

		} catch (Exception e) {
			response.setStatus(400);
			map.put("httpStatus", "400");
			map.put("reasonCode", "001");
			map.put("reason", "Validation Error");
			map.put("message", "API Processing Error");
			setResponse(response, map);
		}
	}

	// GET 요청 시 RESPONSE 처리를 위해
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		response.setStatus(400);
		response.setContentType("application/json; charset=UTF-8");
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("httpStatus", "400");
		map.put("reasonCode", "001");
		map.put("reason", "Bad Request");
		map.put("message", "Not Support Get Method");
		setResponse(response, map);

	}

	private void setResponse(HttpServletResponse response, Map<String, Object> param) {

		if (!param.isEmpty()) {
			try {
				PrintWriter pw = response.getWriter();

				JSONObject jsonObj = new JSONObject(param);

				pw.print(jsonObj);
				pw.flush();
				pw.close();

//				LogUtil.error("OverWorkApply End =====> "+DateUtil.getDate("yyyy-MM-dd HH:mm:ss.SSS"));
			} catch (IOException e) {
				LogUtil.debug("외부 API RESPONSE 데이터 처리 에러", e.getMessage(), e.getStackTrace());

				response.setStatus(400);
				param.clear();
				param.put("httpStatus", "400");
				param.put("reasonCode", "001");
				param.put("reason", "Response Error");
				param.put("message", "Response Processing Error");

				setResponse(response, param);
				return;
			}
		}
	}

	//고객사 하루 기준시가 익일 6시라 시간 값이 역전 되었을때 날짜까지 비교 TRUE 리턴시 장애
	private Boolean checkReversalTime (Map<String, Object> param) {

		Boolean checkFlag = Boolean.FALSE;

		int staMm = 0;
		int endMm = 0;

		//전달 받은 Param이 비어 있지 않으면 검증 로직 시작
		if (param != null) {
			staMm = (Integer.parseInt(String.valueOf(param.get("staHm")).substring(0, 2)) * 60)
					+ Integer.parseInt(String.valueOf(param.get("staHm")).substring(2, 4));

			endMm = (Integer.parseInt(String.valueOf(param.get("endHm")).substring(0, 2)) * 60)
					+ Integer.parseInt(String.valueOf(param.get("endHm")).substring(2, 4));

			// 시간이 반전되어 있으면 추가 검즘
			if (staMm > endMm) {
				String staYmd = "";
				String endYmd = "";

				staYmd = String.valueOf(param.get("staYmd"));
				endYmd = String.valueOf(param.get("endYmd"));

				if (DateUtil.getDateDiff(staYmd, endYmd) <= 0) {
					checkFlag = Boolean.TRUE;
				} else {
					checkFlag = Boolean.FALSE;
				}
			} else {
				checkFlag = Boolean.FALSE;
			}
		} else { // 전달 받은 Param이 비어 있으면 장애
			checkFlag = Boolean.TRUE;
		}

		return checkFlag;
	}

}