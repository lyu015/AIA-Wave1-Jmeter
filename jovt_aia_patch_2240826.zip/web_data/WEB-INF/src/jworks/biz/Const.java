package jworks.biz;

/**
 * <pre>
 * Const.java
 *
 * </pre>
 */
public class Const {
	/*
		데이터베이스 이름
			- 로컬/개발 서버: jdbc/moffice

		데이터베이스 종류
			- postgresql (9.3.x 이상)
			- oracle (9i 이상)
			- mssql (2005 이상)
	*/
	// 데이터베이스 이름/종류
	public static final String DEFAULT_DATABASE_NAME = "jdbc/aia";
	public static final String DEFAULT_DATABASE_TYPE = "postgresql";

	/*
		시스템 모드
			- 개발계: DEV
			- 운영계: REAL

		업로드 폴더
			- 로컬 서버: V:/kepler/workspace/moffice2.0/htdocs/WEB-INF/upload
			- 개발 서버: /home/jovt_dev/web_data/WEB-INF/upload
			- 데모 서버: /home/jovt_demo/web_data/WEB-INF/upload
			- AIA생명: /home/jovt_aia/web_data/WEB-INF/upload

		파일 사이즈
			- 10MB = 1024 * 1024 * 10

		WEB 로그
			- 개발 서버: /home/jovt_dev/log_data/apache
			- 데모 서버: /home/jovt_demo/log_data/apache
			- AIA생명: /home/jovt_aia/log_data/apache

		WAS 로그
			- 개발 서버: /home/jovt_dev/log_data/tomcat
			- 데모 서버: /home/jovt_demo/log_data/tomcat
			- AIA생명: /home/jovt_aia/log_data/tomcat
	*/
	// 시스템 모드/업로드 폴더/파일 사이즈/확장자 제한/WEB 로그/WAS 로그
	public static final String DEFAULT_SYSTEM_MODE = "DEV";
	public static final String DEFAULT_UPLOAD_FOLDER_PATH = "/home/jovt_aia/web_data/WEB-INF/upload";
	public static final int DEFAULT_UPLOAD_FILE_SIZE = 1024 * 1024 * 10;
	public static final String DEFAULT_UPLOAD_FILE_EXT_BLACK = "asp|aspx|jsp|java|jns|php|js|exe|bat|sh|cgi|perl";
	public static final String DEFAULT_LOG_FOLDER_PATH_APACHE = "/home/jovt_aia/log_data/apache";
	public static final String DEFAULT_LOG_FOLDER_PATH_TOMCAT = "/home/jovt_aia/log_data/tomcat";

	/*
		SMTP IP, 포트
			- 로컬/개발/데모 서버: 127.0.0.1, 25
	*/
	// SMTP IP/포트/계정/암호
	public static final String DEFAULT_SMTP_IP = "127.0.0.1";
	public static final String DEFAULT_SMTP_PORT = "25";
	public static final String DEFAULT_SMTP_ID = "";
	public static final String DEFAULT_SMTP_PW = "";

	// 페이징 목록/블록 사이즈
	public static final int DEFAULT_PAGING_LIST_SIZE = 20;
	public static final int DEFAULT_PAGING_BLOCK_SIZE = 10;

	// 공통/파일/폴더 에러
	public static final String DEFAULT_MSG_ERROR_COMMON = "알 수 없는 오류가 발생했습니다.";
	public static final String DEFAULT_MSG_ERROR_FILE = "파일이 존재하지 않습니다.";
	public static final String DEFAULT_MSG_ERROR_FOLDER = "폴더가 존재하지 않습니다.";

	// 데이터베이스 접속/연결/해제/트랜잭션 에러
	public static final String DEFAULT_MSG_ERROR_CONN = "서버에 접속할 수 없습니다.";
	public static final String DEFAULT_MSG_ERROR_OPEN = "연결된 서버가 있습니다.";
	public static final String DEFAULT_MSG_ERROR_CLOSE = "연결해제 오류가 발생했습니다.";
	public static final String DEFAULT_MSG_ERROR_TRAN = "트랜잭션 오류가 발생했습니다.";

	// 쿼리 실패/변수 바인드/레코드 범위/컬럼명 에러
	public static final String DEFAULT_MSG_ERROR_QUERY = "쿼리 실행이 실패했습니다.";
	public static final String DEFAULT_MSG_ERROR_BIND = "일부 변수가 바인드되지 않았습니다.";
	public static final String DEFAULT_MSG_ERROR_RECORD = "존재하지 않는 레코드 범위입니다.";
	public static final String DEFAULT_MSG_ERROR_COLUMN = "은 존재하지 않는 컬럼명입니다.";

	/*
		사이트ID/사이트명/제품명/로고 이미지
			- 로컬/개발 서버: DEV/제이니스/PC-OFF 시스템/company_logo.png
			- 데모 서버: DEMO/제이니스/PC-OFF 시스템/company_logo.png
			- AIA생명: AIA/AIA생명/A.H.A System/aia_logo.png
	*/
	// 사이트ID/사이트명/제품명/로고 이미지
	public static final String DEFAULT_SITE_ID = "AIA";
	public static final String DEFAULT_SITE_NAME = "AIA생명";
	public static final String DEFAULT_PRODUCT_NAME = "A.H.A. System";
	public static final String DEFAULT_LOGO_IMG = "aia_logo.png";
	public static final String DEFAULT_TREE_NAME = "조직도";

	/*
		시스템 메일
			- 로컬/개발/데모 서버: staff@jness.co.kr

		메일 도메인
			- 로컬/개발/데모 서버: @jenss.co.kr
	*/
	// 시스템 메일/메일 도메인
	public static final String DEFAULT_EMAIL_SYSTEM = "staff@jness.co.kr";
	public static final String DEFAULT_EMAIL_DOMAIN = "@jenss.co.kr";

	/*
		내부망 설치파일
			- 개발 서버: http://dev.moffice.kr/Download/DEV_Install.exe
			- 데모 서버: http://demo.moffice.kr/Download/DEMO_Install.exe
			- AIA생명: https://aha.aia.biz/Download/AIA_Install.exe
	*/
	// 내부망 설치파일/외부망 설치파일/이미지 경로
	public static final String DEFAULT_PATH_INSTALL_IN = "https://aha.aia.biz/Download/AIA_Install.exe";
	public static final String DEFAULT_PATH_INSTALL_OUT = "";
	public static final String DEFAULT_PATH_IMGAGE = "/UpgradePRG/ImgUpdateList";

	/*
		로그 암호화 (LOG_ENCRYPTION)
			- 개발계: FALSE
			- 운영계: TRUE

		로그 모드 (MAX_LOGMODE)
			- 개발계: DEBUG
			- 운영계: INFO
	*/
	// 프로그램 설정값
	public static final String DEFAULT_PROGRAM_SYNC_TIME = "0";
	public static final String DEFAULT_PROGRAM_SYNC_INTERVAL = "60";
	public static final String DEFAULT_PROGRAM_DAYAXIS_TM = "0000";
	public static final String DEFAULT_PROGRAM_AM_BLOCKOUT_TM = "06:00";
	public static final String DEFAULT_PROGRAM_HOL_BLOCK_TM = "0900";
	public static final String DEFAULT_PROGRAM_ONLINE_URL = "";
	public static final String DEFAULT_PROGRAM_ONLINE_CHECK = "0";
	public static final String DEFAULT_PROGRAM_ONLINE_CHECK_MM = "5";
	public static final String DEFAULT_PROGRAM_PCOFF_WAIT_MM = "5";
	public static final String DEFAULT_PROGRAM_LOG_ENCRYPTION = "FALSE";
	public static final String DEFAULT_PROGRAM_MAX_LOGMODE = "DEBUG";
	public static final int DEFAULT_PROGRAM_WEEK_START_NUM = 2;// 1:일 2:월 ... 7:토

	// 프로그램 옵션값
	public static final String DEFAULT_PROGRAM_BIRTHDAY_BLOCK = "0";
	public static final String DEFAULT_PROGRAM_VACATION_BLOCK = "0";
	public static final String DEFAULT_PROGRAM_VACATION_AM = "13:00";
	public static final String DEFAULT_PROGRAM_VACATION_PM = "13:00";

	/*
		DeleteLog: 로그 삭제
		HRInfoSYNC: 인사정보 동기화
		JobAgent: 잡 에이전트
		PCLogCalc: PC 사용기록 계산
		Statistics: 통계처리
		SvrMonitor: 서버 모니터링
	*/
	// 데몬로그 표시
	public static final String DEFAULT_DAEMON_LOG_DISPLAY = "";

	// 시스템 사번/이름
	public static final String DEFAULT_SYSTEM_CODE = "00000";
	public static final String DEFAULT_SYSTEM_NAME = "SYSTEM";

	// 설치관리자 사번/이름
	public static final String DEFAULT_ADMIN_NO = "admin";
	public static final String DEFAULT_ADMIN_NM = "설치관리자";

	// 공용사번/공용PC명/공용PC사용/부서별 운영자 권한/기본 근무표 코드(0/1)/기본 근무표 이름
	public static final String DEFAULT_PUBLIC_CODE = "9999999";
	public static final String DEFAULT_PUBLIC_NAME = "공용PC";
	public static final String DEFAULT_PUBLIC_USE = "N";
	public static final String DEFAULT_DEPARTMENT_AUTH = "99";
	public static final int DEFAULT_BASIC_WORK_NO = 1;
	public static final String DEFAULT_BASIC_WORK_NM = "기본 근무표";

	// 사원/직급/직위/직책/계정명(AD인증)/이메일/생일/스마트 워킹데이/PC 사용한도/SMTP 사용여부
	public static final String DEFAULT_OPTION_EMP = "N";
	//public static final String DEFAULT_OPTION_POS = "Y";
	public static final String DEFAULT_OPTION_TIT = "Y";
	public static final String DEFAULT_OPTION_JIK = "N";
	public static final String DEFAULT_OPTION_ACCOUNT = "Y";
	public static final String DEFAULT_OPTION_EMAIL = "N";
	public static final String DEFAULT_OPTION_BIRTH = "N";
	public static final String DEFAULT_OPTION_SMART = "N";
	public static final String DEFAULT_OPTION_LIMIT = "Y";
	public static final String DEFAULT_OPTION_SMTP = "N";

	// 용어사전/부서별 운영자/그룹/PC사용 제한자/휴가자/실시간 모니터링/사용자 초기화/설치 초기화/사용자 초기화(통합)
	public static final String DEFAULT_OPTION_DIC = "N";
	public static final String DEFAULT_OPTION_OPER_DPT = "N";
	public static final String DEFAULT_OPTION_GRP = "Y";
	public static final String DEFAULT_OPTION_BLACKLIST = "Y";
	public static final String DEFAULT_OPTION_VACATION = "Y";
	public static final String DEFAULT_OPTION_ONLINEMONITOR = "N";
	public static final String DEFAULT_OPTION_REAUTH = "N";
	public static final String DEFAULT_OPTION_USERCHANGE = "N";
	public static final String DEFAULT_OPTION_USERCHANGE_NEW = "N";

	// 대시보드 기능 사용여부
	public static final String DEFAULT_OPTION_SEARCH = "N";

	// 부서장 메뉴 사용여부
	public static final String DEFAULT_MENU_OTREQUEST = "Y";
	public static final String DEFAULT_MENU_PCONOFFVIEW = "Y";
	public static final String DEFAULT_MENU_EXCEPTION = "N";
	public static final String DEFAULT_MENU_BLACKLIST = "N";
	public static final String DEFAULT_MENU_REAUTH = "N";
	public static final String DEFAULT_MENU_USERCHANGE = "N";
	public static final String DEFAULT_MENU_LOGPCONOFFVIEW = "Y";
	public static final String DEFAULT_MENU_LOGPCUSEVIEW = "Y";
	public static final String DEFAULT_MENU_APPROVERMANAGE = "N";

	// 업무시작시간/종료시간/PC차단시간
	public static final String DEFAULT_VALUE_WORKSET_ST = "09:00";
	public static final String DEFAULT_VALUE_WORKSET_ET = "18:00";
	public static final String DEFAULT_VALUE_WORKSET_BT = "19:00";

	// 통계처리용 PC ON시작시간/ON종료시간/OFF시작시간
	public static final int DEFAULT_VALUE_PC_ON_ST = 6;
	public static final int DEFAULT_VALUE_PC_ON_ET = 10;
	public static final int DEFAULT_VALUE_PC_OFF_ST = 17;

	/*
		사번/직급/직위/직책 표기명
			- 로컬/개발/데모 서버: 사번/부서/직급/직위/직책
			- AIA생명: 사번/부서/직급/직위/직종
	*/
	// 사번/부서/직급/직위/직책 표기명
	public static final String DEFAULT_TITLE_EMP = "사번";
	public static final String DEFAULT_TITLE_DPT = "부서";
	public static final String DEFAULT_TITLE_POS = "직급";
	public static final String DEFAULT_TITLE_TIT = "직위";
	public static final String DEFAULT_TITLE_JIK = "직종";

	// 기본 근무표 삭제/사용 근무표 삭제/설정값 여부 안내 메시지
	public static final String DEFAULT_MSG_FAIL_BASIC_WORK = "기본 근무표는 삭제할 수 없습니다.";
	public static final String DEFAULT_MSG_FAIL_CNT_WORK = "사용 중인 근무표는 삭제할 수 없습니다.";
	public static final String DEFAULT_MSG_FAIL_NOT_SETTING = "프로그램 설정값이 존재하지 않습니다.";
	public static final String DEFAULT_MSG_FAIL_BASIC_SETTING = "\n프로그램 설정값 확인 후 적용해주세요.";

	// 사번/계정명/휴일/그룹/근무표/사이트 중복 메시지
	public static final String DEFAULT_MSG_FAIL_USE_EMP = "이미 사용 중인 " + DEFAULT_TITLE_EMP + "입니다.";
	public static final String DEFAULT_MSG_FAIL_USE_ACCOUNT = "이미 사용 중인 계정명입니다.";
	public static final String DEFAULT_MSG_FAIL_USE_DAY = "이미 사용 중인 휴일입니다.";
	public static final String DEFAULT_MSG_FAIL_USE_GRP = "이미 사용 중인 그룹명입니다.";
	public static final String DEFAULT_MSG_FAIL_USE_WORK = "이미 사용 중인 근무표명입니다.";
	public static final String DEFAULT_MSG_FAIL_USE_DOMAIN = "이미 등록되어 있는 제외사이트입니다.";

	// 사원/그룹/부서등록 안내 메시지
	public static final String DEFAULT_MSG_INFO_USE_EMP = "기간 내에 이미 등록되어 있는 사원목록";
	public static final String DEFAULT_MSG_INFO_USE_GRP = "기간 내에 이미 등록되어 있는 그룹목록";
	public static final String DEFAULT_MSG_INFO_USE_DPT = "기간 내에 이미 등록되어 있는 " + DEFAULT_TITLE_DPT + "목록";

	// 알림창/차단창 중복 메시지
	public static final String DEFAULT_MSG_FAIL_USE_NOTICE = "동일한 사용용도/대상자/대상 요일/팝업시간으로\n등록된 알림창 메시지가 있습니다.";
	public static final String DEFAULT_MSG_FAIL_USE_BLOCK = "동일한 사용용도로\n등록된 차단창 메시지가 있습니다.";
	public static final String DEFAULT_MSG_FAIL_DEL_MODE_0 = "공통 메시지는 삭제할 수 없습니다.";
	public static final String DEFAULT_MSG_FAIL_NOT_MODE_1 = "평일 차단전 알림창이 존재하지 않습니다.\n메시지 설정에서 등록 후 사용해주세요.";
	public static final String DEFAULT_MSG_FAIL_NOT_MODE_2 = "특정일 차단전 알림창이 존재하지 않습니다.\n메시지 설정에서 등록 후 사용해주세요.";
	public static final String DEFAULT_MSG_FAIL_NOT_MODE_3 = "차단요일 차단전 알림창이 존재하지 않습니다.\n메시지 설정에서 등록 후 사용해주세요.";
	public static final String DEFAULT_MSG_FAIL_NOT_MODE_4 = "휴일 차단전 알림창이 존재하지 않습니다.\n메시지 설정에서 등록 후 사용해주세요.";
	public static final String DEFAULT_MSG_FAIL_NOT_MODE_5 = "스마트 워킹데이 차단전 알림창이 존재하지 않습니다.\n메시지 설정에서 등록 후 사용해주세요.";

	// PC 사용 신청 관련 메시지
	public static final String DEFAULT_MSG_FAIL_OT_APPROVER = "해당 " + DEFAULT_TITLE_DPT + "에 결재자가 존재하지 않습니다.\n운영자에게 문의해주세요.";
	public static final String DEFAULT_MSG_FAIL_OT_EXCLUSION = "비대상자는 PC 사용 신청이 제한되어 있습니다.";
	public static final String DEFAULT_MSG_FAIL_OT_EXCEPTION = "차단 예외자와 예외기간에는 PC 사용 신청이 제한되어 있습니다.";
	public static final String DEFAULT_MSG_FAIL_OT_VACATION = "휴가일에는 PC 사용 신청이 제한되어 있습니다.";
	public static final String DEFAULT_MSG_FAIL_OT_TYPE_1 = "사전 PC 사용 신청이 제한되어 있습니다.";
	public static final String DEFAULT_MSG_FAIL_OT_TYPE_2 = "긴급 PC 사용 신청이 제한되어 있습니다.";
	public static final String DEFAULT_MSG_FAIL_OT_ALERT_0 = "신청일자의 주 사용한도를 초과하여 신청했습니다.";
	public static final String DEFAULT_MSG_FAIL_OT_ALERT_1 = "신청일시에 결재중인 신청건이 있습니다.\n기존 신청건을 취소 후 신청해주세요.";
	public static final String DEFAULT_MSG_FAIL_OT_ALERT_2 = "신청일시에 승인완료된 신청건이 있습니다.";
	public static final String DEFAULT_MSG_FAIL_OT_ALERT_3 = "결재완료된 신청건은 취소할 수 없습니다.";
	public static final String DEFAULT_MSG_FAIL_OT_ALERT_4 = "취소처리된 신청건은 취소할 수 없습니다.";

	// 파라미터/사용권한/사원정보/세션만료/암호화 경고 메시지
	public static final String DEFAULT_MSG_WARN_PARAM = "비정상적으로 접속하셨습니다.";
	public static final String DEFAULT_MSG_WARN_AUTH = "사용 권한이 없습니다.";
	public static final String DEFAULT_MSG_WARN_EMP = "사원정보가 존재하지 않습니다.";
	public static final String DEFAULT_MSG_WARN_SESSION = "세션이 만료되었습니다.";
	public static final String DEFAULT_MSG_WARN_DECRYPT = "암호화 오류가 발생했습니다.\n시스템 관리자에게 문의해주세요.";

	// 데이터 없음
	public static final String DEFAULT_MSG_INFO_NODATA = "검색된 데이터가 없습니다.";
	public static final String DEFAULT_MSG_INFO_NOADD = "추가된 데이터가 없습니다.";

	// 체크박스/셀렉트박스 경고 메시지
	public static final String DEFAULT_MSG_WARN_CHECKED = "처리할 대상를 체크해주세요.";
	public static final String DEFAULT_MSG_WARN_SELECTED = "처리할 상태를 선택해주세요.";

	// 저장/삭제/발송/업데이트/변경/취소/실행/엑셀 컨펌 메시지
	public static final String DEFAULT_MSG_CONFIRM_SAVE = "저장 하시겠습니까?";
	public static final String DEFAULT_MSG_CONFIRM_DEL = "삭제 하시겠습니까?";
	public static final String DEFAULT_MSG_CONFIRM_SEND = "발송 하시겠습니까?";
	public static final String DEFAULT_MSG_CONFIRM_UPDATE = "업데이트 하시겠습니까?";
	public static final String DEFAULT_MSG_CONFIRM_CHANGE = "변경 하시겠습니까?";
	public static final String DEFAULT_MSG_CONFIRM_CANCEL = "취소 하시겠습니까?";
	public static final String DEFAULT_MSG_CONFIRM_ACTION = "실행 하시겠습니까?";
	public static final String DEFAULT_MSG_CONFIRM_EXCEL = "현재 데이터를 엑셀로 저장하시겠습니까?";

	// 저장/삭제/발송/업데이트/변경/취소/정상/실패 처리 메시지
	public static final String DEFAULT_MSG_PROC_SAVE = "성공적으로 저장되었습니다.";
	public static final String DEFAULT_MSG_PROC_DEL = "성공적으로 삭제되었습니다.";
	public static final String DEFAULT_MSG_PROC_SEND = "성공적으로 발송되었습니다.";
	public static final String DEFAULT_MSG_PROC_UPDATE = "성공적으로 업데이트되었습니다.";
	public static final String DEFAULT_MSG_PROC_CHANGE = "성공적으로 변경되었습니다.";
	public static final String DEFAULT_MSG_PROC_CANCEL = "성공적으로 취소되었습니다.";
	public static final String DEFAULT_MSG_PROC_SUCCESS = "정상적으로 처리되었습니다.";
	public static final String DEFAULT_MSG_PROC_FAIL = "비정상적으로 종료되었습니다.";

	// 로그인/로그아웃 메시지
	public static final String DEFAULT_MSG_LOGIN_FAIL = "로그인 정보가 일치하지 않습니다.";
	public static final String DEFAULT_MSG_LOGOUT_CONFIRM = "로그아웃 하시겠습니까?";
}